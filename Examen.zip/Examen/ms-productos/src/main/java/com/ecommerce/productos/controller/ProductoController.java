package com.ecommerce.productos.controller;

import com.ecommerce.productos.dto.ProductoDTO;
import com.ecommerce.productos.service.ProductoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Controller REST - Productos
 * Patrón CSR: solo manejo HTTP, delega lógica al Service
 */
@RestController
@RequestMapping("/api/productos")
@RequiredArgsConstructor
public class ProductoController {

    private static final Logger log = LoggerFactory.getLogger(ProductoController.class);
    private final ProductoService productoService;

    @GetMapping
    public ResponseEntity<List<ProductoDTO.Response>> listarProductos() {
        log.info("GET /api/productos");
        return ResponseEntity.ok(productoService.listarProductos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductoDTO.Response> obtenerProducto(@PathVariable Long id) {
        log.info("GET /api/productos/{}", id);
        return ResponseEntity.ok(productoService.obtenerPorId(id));
    }

    @PostMapping
    public ResponseEntity<ProductoDTO.Response> crearProducto(@Valid @RequestBody ProductoDTO.Request request) {
        log.info("POST /api/productos - SKU: {}", request.getSku());
        return ResponseEntity.status(HttpStatus.CREATED).body(productoService.crearProducto(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductoDTO.Response> actualizarProducto(
            @PathVariable Long id, @Valid @RequestBody ProductoDTO.UpdateRequest request) {
        log.info("PUT /api/productos/{}", id);
        return ResponseEntity.ok(productoService.actualizarProducto(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> eliminarProducto(@PathVariable Long id) {
        log.info("DELETE /api/productos/{}", id);
        productoService.eliminarProducto(id);
        return ResponseEntity.ok(Map.of("mensaje", "Producto desactivado exitosamente"));
    }

    @GetMapping("/buscar")
    public ResponseEntity<List<ProductoDTO.Response>> buscar(@RequestParam String termino) {
        log.info("GET /api/productos/buscar?termino={}", termino);
        return ResponseEntity.ok(productoService.buscarPorNombre(termino));
    }

    @GetMapping("/precio")
    public ResponseEntity<List<ProductoDTO.Response>> buscarPorPrecio(
            @RequestParam BigDecimal min, @RequestParam BigDecimal max) {
        log.info("GET /api/productos/precio?min={}&max={}", min, max);
        return ResponseEntity.ok(productoService.buscarPorRangoPrecio(min, max));
    }

    @GetMapping("/{id}/existe")
    public ResponseEntity<Map<String, Boolean>> verificarExistencia(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("existe", productoService.existeProducto(id)));
    }
}
