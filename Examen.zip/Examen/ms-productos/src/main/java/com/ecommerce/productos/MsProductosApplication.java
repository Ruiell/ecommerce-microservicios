package com.ecommerce.productos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Microservicio de Gestión de Productos
 * Puerto: 8082
 * Responsabilidad: CRUD de productos, precios y disponibilidad
 * Comunicación: Feign Client hacia ms-categorias
 */
@SpringBootApplication
@EnableFeignClients
public class MsProductosApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsProductosApplication.class, args);
    }
}
