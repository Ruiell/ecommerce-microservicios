package com.ecommerce.productos.dto;

import com.ecommerce.productos.model.Producto.EstadoProducto;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class ProductoDTO {

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Request {
        @NotBlank(message = "El nombre es obligatorio")
        @Size(min = 2, max = 150, message = "El nombre debe tener entre 2 y 150 caracteres")
        private String nombre;

        private String descripcion;

        @NotNull(message = "El precio es obligatorio")
        @DecimalMin(value = "0.0", inclusive = false, message = "El precio debe ser mayor a 0")
        private BigDecimal precio;

        @DecimalMin(value = "0.0", inclusive = false, message = "El precio con descuento debe ser mayor a 0")
        private BigDecimal precioDescuento;

        @NotBlank(message = "El SKU es obligatorio")
        private String sku;

        private String imagenUrl;

        private String marca;

        @NotNull(message = "La categoría es obligatoria")
        private Long categoriaId;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class UpdateRequest {
        @Size(min = 2, max = 150)
        private String nombre;
        private String descripcion;
        @DecimalMin(value = "0.0", inclusive = false)
        private BigDecimal precio;
        @DecimalMin(value = "0.0", inclusive = false)
        private BigDecimal precioDescuento;
        private String imagenUrl;
        private String marca;
        private EstadoProducto estado;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id;
        private String nombre;
        private String descripcion;
        private BigDecimal precio;
        private BigDecimal precioDescuento;
        private String sku;
        private String imagenUrl;
        private String marca;
        private Long categoriaId;
        private EstadoProducto estado;
        private LocalDateTime createdAt;
    }
}
