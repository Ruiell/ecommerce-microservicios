package com.ecommerce.productos.config;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.Map;

/**
 * Feign Client - Comunicación declarativa hacia ms-categorias
 * Permite validar que la categoría existe antes de crear un producto
 */
@FeignClient(name = "ms-categorias", url = "${microservices.categorias.url}")
public interface CategoriaFeignClient {

    @GetMapping("/api/categorias/{id}/existe")
    Map<String, Boolean> verificarExistencia(@PathVariable Long id);

    @GetMapping("/api/categorias/{id}")
    Map<String, Object> obtenerCategoria(@PathVariable Long id);
}
