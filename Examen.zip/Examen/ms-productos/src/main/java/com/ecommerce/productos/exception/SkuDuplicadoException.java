package com.ecommerce.productos.exception;
public class SkuDuplicadoException extends RuntimeException {
    public SkuDuplicadoException(String mensaje) { super(mensaje); }
}
