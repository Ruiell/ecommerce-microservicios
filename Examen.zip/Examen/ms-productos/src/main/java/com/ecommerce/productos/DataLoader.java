package com.ecommerce.productos;

import com.ecommerce.productos.model.Producto;
import com.ecommerce.productos.model.Producto.EstadoProducto;
import com.ecommerce.productos.repository.ProductoRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;

/**
 * Carga de datos falsos para ms-productos.
 * Se ejecuta solo cuando el perfil activo es "dev" (spring.profiles.active=dev).
 * Genera productos de ejemplo usando DataFaker para poder probar la API
 * sin tener que ingresar datos manualmente.
 */
@Profile({"dev", "render", "aiven"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private ProductoRepository productoRepository;

    @Override
    public void run(String... args) throws Exception {
        // Evita duplicar datos si ya existen productos cargados
        if (productoRepository.count() > 0) {
            return;
        }

        Faker faker = new Faker();
        Random random = new Random();

        for (int i = 0; i < 30; i++) {
            Producto producto = new Producto();
            producto.setNombre(faker.commerce().productName());
            producto.setDescripcion(faker.lorem().sentence(12));

            BigDecimal precio = BigDecimal.valueOf(faker.number().randomDouble(2, 5000, 500000))
                    .setScale(2, RoundingMode.HALF_UP);
            producto.setPrecio(precio);

            // 40% de los productos tiene precio con descuento (menor al precio normal)
            if (random.nextInt(10) < 4) {
                BigDecimal descuento = precio.multiply(BigDecimal.valueOf(0.5 + random.nextDouble() * 0.4))
                        .setScale(2, RoundingMode.HALF_UP);
                producto.setPrecioDescuento(descuento);
            }

            producto.setSku(faker.code().ean13());
            producto.setImagenUrl("https://picsum.photos/seed/" + faker.number().digits(6) + "/400/400");
            producto.setMarca(faker.company().name());
            producto.setCategoriaId((long) faker.number().numberBetween(1, 6));

            EstadoProducto[] estados = EstadoProducto.values();
            producto.setEstado(estados[random.nextInt(estados.length)]);

            productoRepository.save(producto);
        }

        System.out.println(">> DataLoader: 30 productos de prueba cargados en ms-productos (perfil dev).");
    }
}
