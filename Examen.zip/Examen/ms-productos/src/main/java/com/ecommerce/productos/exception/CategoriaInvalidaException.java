package com.ecommerce.productos.exception;
public class CategoriaInvalidaException extends RuntimeException {
    public CategoriaInvalidaException(String mensaje) { super(mensaje); }
}
