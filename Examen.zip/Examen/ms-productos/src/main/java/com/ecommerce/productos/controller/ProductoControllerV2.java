package com.ecommerce.productos.controller;

import com.ecommerce.productos.assemblers.ProductoModelAssembler;
import com.ecommerce.productos.dto.ProductoDTO;
import com.ecommerce.productos.model.Producto;
import com.ecommerce.productos.service.ProductoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de productos.
 * Las respuestas incluyen enlaces de navegación (self, productosDeLaCategoria).
 * Para la versión sin HATEOAS usar /api/productos (ProductoController).
 */
@RestController
@RequestMapping("/api/v2/productos")
@Tag(name = "Productos (HATEOAS)", description = "Operaciones sobre productos con enlaces HATEOAS")
public class ProductoControllerV2 {

    @Autowired
    private ProductoService productoService;

    @Autowired
    private ProductoModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar todos los productos (HATEOAS)")
    public CollectionModel<EntityModel<ProductoDTO.Response>> listar() {
        List<EntityModel<ProductoDTO.Response>> productos = productoService.listarProductos().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(productos, linkTo(methodOn(ProductoControllerV2.class).listar()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un producto por id (HATEOAS)")
    public EntityModel<ProductoDTO.Response> obtener(@PathVariable Long id) {
        return assembler.toModel(productoService.obtenerPorId(id));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear un producto (HATEOAS)")
    public ResponseEntity<EntityModel<ProductoDTO.Response>> crear(@Valid @RequestBody ProductoDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(productoService.crearProducto(request)));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar un producto (HATEOAS)")
    public EntityModel<ProductoDTO.Response> actualizar(@PathVariable Long id, @Valid @RequestBody ProductoDTO.UpdateRequest request) {
        return assembler.toModel(productoService.actualizarProducto(id, request));
    }

    // ===== Reportes con HATEOAS (ver ProductoService) =====

    // 1. Obtener todos los productos en un estado específico
    @GetMapping(value = "/estado/{estado}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar productos por estado (HATEOAS)",
            description = "Estados válidos: ACTIVO, INACTIVO, AGOTADO")
    public CollectionModel<EntityModel<ProductoDTO.Response>> listarPorEstado(@PathVariable Producto.EstadoProducto estado) {
        List<EntityModel<ProductoDTO.Response>> productos = productoService.listarPorEstado(estado).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(productos, linkTo(methodOn(ProductoControllerV2.class).listarPorEstado(estado)).withSelfRel());
    }

    // 2. Obtener todos los productos creados en una fecha específica (ej: /api/v2/productos/fecha/2026-06-26)
    @GetMapping(value = "/fecha/{fecha}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar productos creados en una fecha específica (HATEOAS)")
    public CollectionModel<EntityModel<ProductoDTO.Response>> listarPorFecha(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        List<EntityModel<ProductoDTO.Response>> productos = productoService.listarPorFecha(fecha).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(productos, linkTo(methodOn(ProductoControllerV2.class).listarPorFecha(fecha)).withSelfRel());
    }

    // 3. Obtener todos los productos creados entre dos fechas
    @GetMapping(value = "/rango", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar productos creados entre dos fechas (HATEOAS)")
    public CollectionModel<EntityModel<ProductoDTO.Response>> listarEntreFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        List<EntityModel<ProductoDTO.Response>> productos = productoService.listarEntreFechas(inicio, fin).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(productos, linkTo(methodOn(ProductoControllerV2.class).listarEntreFechas(inicio, fin)).withSelfRel());
    }

    // 4. Obtener todos los productos de una categoría
    @GetMapping(value = "/categoria/{categoriaId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar productos de una categoría (HATEOAS)")
    public CollectionModel<EntityModel<ProductoDTO.Response>> listarPorCategoria(@PathVariable Long categoriaId) {
        List<EntityModel<ProductoDTO.Response>> productos = productoService.buscarPorCategoria(categoriaId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(productos, linkTo(methodOn(ProductoControllerV2.class).listarPorCategoria(categoriaId)).withSelfRel());
    }

    // 5. Obtener el total de productos de una categoría
    @GetMapping(value = "/categoria/{categoriaId}/total", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el total de productos de una categoría (HATEOAS)")
    public EntityModel<Map<String, Object>> contarPorCategoria(@PathVariable Long categoriaId) {
        long total = productoService.contarPorCategoria(categoriaId);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("categoriaId", categoriaId);
        body.put("totalProductos", total);

        return EntityModel.of(body,
                linkTo(methodOn(ProductoControllerV2.class).contarPorCategoria(categoriaId)).withSelfRel(),
                linkTo(methodOn(ProductoControllerV2.class).listarPorCategoria(categoriaId)).withRel("productosDeLaCategoria"));
    }
}
