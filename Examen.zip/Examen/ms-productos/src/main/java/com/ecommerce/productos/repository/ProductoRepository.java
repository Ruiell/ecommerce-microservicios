package com.ecommerce.productos.repository;

import com.ecommerce.productos.model.Producto;
import com.ecommerce.productos.model.Producto.EstadoProducto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Repository de Producto - operaciones CRUD con JpaRepository
 */
@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    Optional<Producto> findBySku(String sku);
    boolean existsBySku(String sku);
    boolean existsByNombreIgnoreCaseAndCategoriaId(String nombre, Long categoriaId);
    List<Producto> findByEstado(EstadoProducto estado);
    List<Producto> findByCategoriaId(Long categoriaId);
    List<Producto> findByCreatedAtBetween(java.time.LocalDateTime inicio, java.time.LocalDateTime fin);
    long countByCategoriaId(Long categoriaId);

    @Query("SELECT p FROM Producto p WHERE LOWER(p.nombre) LIKE LOWER(CONCAT('%', :termino, '%'))")
    List<Producto> buscarPorNombre(String termino);

    @Query("SELECT p FROM Producto p WHERE p.precio BETWEEN :min AND :max AND p.estado = 'ACTIVO'")
    List<Producto> findByRangoPrecio(BigDecimal min, BigDecimal max);
}
