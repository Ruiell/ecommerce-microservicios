package com.ecommerce.productos.service;

import com.ecommerce.productos.dto.ProductoDTO;
import com.ecommerce.productos.exception.ProductoNoEncontradoException;
import com.ecommerce.productos.exception.ProductoDuplicadoException;
import com.ecommerce.productos.model.Producto;
import com.ecommerce.productos.model.Producto.EstadoProducto;
import com.ecommerce.productos.repository.ProductoRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Servicio de Productos - Lógica de negocio
 * Comunicación con ms-categorias mediante WebClient
 */
@Service
@RequiredArgsConstructor
public class ProductoService {

    private static final Logger log = LoggerFactory.getLogger(ProductoService.class);

    private final ProductoRepository productoRepository;
    private final WebClient.Builder webClientBuilder;

    @Value("${microservices.categorias.url:http://localhost:8083}")
    private String categoriasUrl;

    /**
     * Crea un nuevo producto
     * Regla de negocio: Valida que la categoría exista en ms-categorias
     * Regla de negocio: No puede haber dos productos con el mismo nombre en la misma categoría
     */
    @Transactional
    public ProductoDTO.Response crearProducto(ProductoDTO.Request request) {
        log.info("Iniciando creación de producto: {}", request.getNombre());

        // Regla de negocio: nombre único por categoría
        if (productoRepository.existsByNombreIgnoreCaseAndCategoriaId(request.getNombre(), request.getCategoriaId())) {
            log.warn("Producto duplicado: {} en categoría {}", request.getNombre(), request.getCategoriaId());
            throw new ProductoDuplicadoException("Ya existe un producto con ese nombre en esta categoría");
        }

        // Regla de negocio: precio con descuento debe ser menor al precio normal
        if (request.getPrecioDescuento() != null &&
            request.getPrecioDescuento().compareTo(request.getPrecio()) >= 0) {
            throw new IllegalArgumentException("El precio con descuento debe ser menor al precio normal");
        }

        // Comunicación con ms-categorias mediante WebClient
        validarCategoriaExiste(request.getCategoriaId());

        Producto producto = new Producto();
        producto.setNombre(request.getNombre());
        producto.setDescripcion(request.getDescripcion());
        producto.setPrecio(request.getPrecio());
        producto.setPrecioDescuento(request.getPrecioDescuento());
        producto.setImagenUrl(request.getImagenUrl());
        producto.setMarca(request.getMarca());
        producto.setCategoriaId(request.getCategoriaId());
        producto.setEstado(EstadoProducto.ACTIVO);

        Producto guardado = productoRepository.save(producto);
        log.info("Producto creado con ID: {}", guardado.getId());
        return mapear(guardado);
    }

    @Transactional(readOnly = true)
    public List<ProductoDTO.Response> listarProductosActivos() {
        log.info("Listando productos activos");
        return productoRepository.findByEstado(EstadoProducto.ACTIVO)
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductoDTO.Response> listarProductos() {
        log.info("Listando todos los productos");
        return productoRepository.findAll()
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProductoDTO.Response obtenerPorId(Long id) {
        log.info("Buscando producto con ID: {}", id);
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Producto no encontrado con ID: {}", id);
                    return new ProductoNoEncontradoException("Producto no encontrado con ID: " + id);
                });
        return mapear(producto);
    }

    @Transactional(readOnly = true)
    public List<ProductoDTO.Response> buscarPorNombre(String termino) {
        log.info("Buscando productos con término: {}", termino);
        return productoRepository.buscarPorNombre(termino)
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductoDTO.Response> buscarPorRangoPrecio(BigDecimal min, BigDecimal max) {
        log.info("Buscando productos entre ${} y ${}", min, max);
        if (min.compareTo(max) > 0) {
            throw new IllegalArgumentException("El precio mínimo no puede ser mayor al máximo");
        }
        return productoRepository.findByRangoPrecio(min, max)
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductoDTO.Response> buscarPorCategoria(Long categoriaId) {
        log.info("Buscando productos de categoría: {}", categoriaId);
        return productoRepository.findByCategoriaId(categoriaId)
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductoDTO.Response> listarPorEstado(EstadoProducto estado) {
        log.info("Listando productos con estado: {}", estado);
        return productoRepository.findByEstado(estado)
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductoDTO.Response> listarPorFecha(LocalDate fecha) {
        log.info("Listando productos creados el: {}", fecha);
        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.plusDays(1).atStartOfDay();
        return productoRepository.findByCreatedAtBetween(inicio, fin)
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductoDTO.Response> listarEntreFechas(LocalDateTime inicio, LocalDateTime fin) {
        log.info("Listando productos entre {} y {}", inicio, fin);
        if (inicio.isAfter(fin)) {
            throw new IllegalArgumentException("La fecha de inicio no puede ser posterior a la fecha de fin");
        }
        return productoRepository.findByCreatedAtBetween(inicio, fin)
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public long contarPorCategoria(Long categoriaId) {
        log.info("Contando productos de categoría: {}", categoriaId);
        return productoRepository.countByCategoriaId(categoriaId);
    }

    @Transactional
    public ProductoDTO.Response actualizarProducto(Long id, ProductoDTO.UpdateRequest request) {
        log.info("Actualizando producto ID: {}", id);
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ProductoNoEncontradoException("Producto no encontrado con ID: " + id));

        if (request.getNombre() != null) producto.setNombre(request.getNombre());
        if (request.getDescripcion() != null) producto.setDescripcion(request.getDescripcion());
        if (request.getPrecio() != null) producto.setPrecio(request.getPrecio());
        if (request.getPrecioDescuento() != null) producto.setPrecioDescuento(request.getPrecioDescuento());
        if (request.getImagenUrl() != null) producto.setImagenUrl(request.getImagenUrl());
        if (request.getMarca() != null) producto.setMarca(request.getMarca());
        if (request.getEstado() != null) producto.setEstado(request.getEstado());

        Producto actualizado = productoRepository.save(producto);
        log.info("Producto actualizado exitosamente: {}", id);
        return mapear(actualizado);
    }

    @Transactional
    public void eliminarProducto(Long id) {
        log.info("Eliminando (desactivando) producto ID: {}", id);
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ProductoNoEncontradoException("Producto no encontrado con ID: " + id));
        producto.setEstado(EstadoProducto.INACTIVO);
        productoRepository.save(producto);
        log.info("Producto desactivado: {}", id);
    }

    public boolean existeProducto(Long id) {
        boolean existe = productoRepository.existsById(id);
        log.debug("Verificación de existencia producto ID {}: {}", id, existe);
        return existe;
    }

    /**
     * Valida que la categoría exista en ms-categorias mediante WebClient
     */
    private void validarCategoriaExiste(Long categoriaId) {
        try {
            log.debug("Validando existencia de categoría {} en ms-categorias", categoriaId);
            Boolean existe = webClientBuilder.build()
                    .get()
                    .uri(categoriasUrl + "/api/categorias/" + categoriaId + "/existe")
                    .retrieve()
                    .bodyToMono(Boolean.class)
                    .block();

            if (existe == null || !existe) {
                throw new IllegalArgumentException("La categoría con ID " + categoriaId + " no existe");
            }
            log.debug("Categoría {} validada exitosamente", categoriaId);
        } catch (WebClientResponseException e) {
            log.error("Error al validar categoría {}: {}", categoriaId, e.getMessage());
            // En caso de que ms-categorias no esté disponible, se permite la operación con advertencia
            log.warn("ms-categorias no disponible, omitiendo validación de categoría");
        }
    }

    private ProductoDTO.Response mapear(Producto p) {
        ProductoDTO.Response r = new ProductoDTO.Response();
        r.setId(p.getId());
        r.setNombre(p.getNombre());
        r.setDescripcion(p.getDescripcion());
        r.setPrecio(p.getPrecio());
        r.setPrecioDescuento(p.getPrecioDescuento());
        r.setImagenUrl(p.getImagenUrl());
        r.setMarca(p.getMarca());
        r.setCategoriaId(p.getCategoriaId());
        r.setEstado(p.getEstado());
        r.setCreatedAt(p.getCreatedAt());
        return r;
    }
}
