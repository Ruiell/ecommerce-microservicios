package com.ecommerce.productos.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.productos.controller.ProductoControllerV2;
import com.ecommerce.productos.dto.ProductoDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class ProductoModelAssembler implements RepresentationModelAssembler<ProductoDTO.Response, EntityModel<ProductoDTO.Response>> {

    @Override
    public EntityModel<ProductoDTO.Response> toModel(ProductoDTO.Response producto) {
        EntityModel<ProductoDTO.Response> model = EntityModel.of(producto,
                linkTo(methodOn(ProductoControllerV2.class).obtener(producto.getId())).withSelfRel());
        if (producto.getCategoriaId() != null) {
            model.add(linkTo(methodOn(ProductoControllerV2.class).listarPorCategoria(producto.getCategoriaId())).withRel("productosDeLaCategoria"));
        }
        return model;
    }
}
