package com.ecommerce.productos.service;

import com.ecommerce.productos.dto.ProductoDTO;
import com.ecommerce.productos.exception.ProductoNoEncontradoException;
import com.ecommerce.productos.model.Producto;
import com.ecommerce.productos.model.Producto.EstadoProducto;
import com.ecommerce.productos.repository.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Tests unitarios de ProductoService usando Mockito puro (@ExtendWith(MockitoExtension.class)).
 * No requiere levantar el contexto de Spring ni una base de datos real, a diferencia de
 * @SpringBootTest + @MockBean: se instancia el servicio a mano con mocks del repositorio
 * y del WebClient.Builder (usado para validar la categoría contra ms-categorias).
 */
@ExtendWith(MockitoExtension.class)
class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private WebClient.Builder webClientBuilder;

    private ProductoService productoService;

    @BeforeEach
    void setUp() {
        productoService = new ProductoService(productoRepository, webClientBuilder);
    }

    private Producto crearProductoDePrueba() {
        Producto producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Peluche Squishy Oso");
        producto.setDescripcion("Peluche antiestrés");
        producto.setPrecio(new BigDecimal("9990.00"));
        producto.setSku("SKU-0001");
        producto.setImagenUrl("https://picsum.photos/seed/1/400/400");
        producto.setMarca("SquishyLand");
        producto.setCategoriaId(2L);
        producto.setEstado(EstadoProducto.ACTIVO);
        return producto;
    }

    @Test
    void testListarProductos() {
        when(productoRepository.findAll()).thenReturn(List.of(crearProductoDePrueba()));

        List<ProductoDTO.Response> productos = productoService.listarProductos();

        assertNotNull(productos);
        assertEquals(1, productos.size());
        assertEquals("Peluche Squishy Oso", productos.get(0).getNombre());
    }

    @Test
    void testObtenerPorId() {
        Producto producto = crearProductoDePrueba();
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));

        ProductoDTO.Response encontrado = productoService.obtenerPorId(1L);

        assertNotNull(encontrado);
        assertEquals(producto.getSku(), encontrado.getSku());
    }

    @Test
    void testObtenerPorId_NoEncontrado() {
        when(productoRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ProductoNoEncontradoException.class, () -> productoService.obtenerPorId(99L));
    }

    @Test
    void testCrearProducto() {
        // Simula la respuesta de ms-categorias confirmando que la categoría existe
        when(webClientBuilder.build().get().uri(anyString())
                .retrieve().bodyToMono(Boolean.class).block()).thenReturn(Boolean.TRUE);

        when(productoRepository.existsByNombreIgnoreCaseAndCategoriaId(anyString(), eq(2L)))
                .thenReturn(false);

        ProductoDTO.Request request = new ProductoDTO.Request();
        request.setNombre("Peluche Squishy Oso");
        request.setDescripcion("Peluche antiestrés");
        request.setPrecio(new BigDecimal("9990.00"));
        request.setSku("SKU-0001");
        request.setImagenUrl("https://picsum.photos/seed/1/400/400");
        request.setMarca("SquishyLand");
        request.setCategoriaId(2L);

        when(productoRepository.save(any(Producto.class))).thenReturn(crearProductoDePrueba());

        ProductoDTO.Response creado = productoService.crearProducto(request);

        assertNotNull(creado);
        assertEquals("Peluche Squishy Oso", creado.getNombre());
        verify(productoRepository, times(1)).save(any(Producto.class));
    }

    @Test
    void testEliminarProducto() {
        Producto producto = crearProductoDePrueba();
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        when(productoRepository.save(any(Producto.class))).thenReturn(producto);

        productoService.eliminarProducto(1L);

        assertEquals(EstadoProducto.INACTIVO, producto.getEstado());
        verify(productoRepository, times(1)).save(producto);
    }
}
