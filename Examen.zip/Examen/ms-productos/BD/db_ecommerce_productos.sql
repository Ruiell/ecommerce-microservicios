/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_productos
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_productos;

/* ============================================================
   2. Tabla productos
   ============================================================ */
CREATE TABLE productos (
    id                  BIGINT        NOT NULL AUTO_INCREMENT,
    nombre              VARCHAR(150)  NOT NULL,
    descripcion         TEXT          NULL,
    precio              DECIMAL(10,2) NOT NULL,
    precio_descuento    DECIMAL(10,2) NULL,
    sku                 VARCHAR(50)   NOT NULL,
    imagen_url          VARCHAR(255)  NULL,
    marca               VARCHAR(100)  NULL,
    categoria_id        BIGINT        NULL,
    estado              VARCHAR(20)   NOT NULL DEFAULT 'ACTIVO',
    created_at          DATETIME      NOT NULL,
    updated_at          DATETIME      NULL,
    CONSTRAINT productos_PK PRIMARY KEY (id),
    CONSTRAINT productos_sku_UN UNIQUE (sku),
    CONSTRAINT chk_productos_estado CHECK (estado IN ('ACTIVO','INACTIVO','AGOTADO')),
    CONSTRAINT chk_productos_precio CHECK (precio > 0)
) ENGINE = InnoDB;

/* ============================================================
   ¡Todo listo!
   ============================================================ */
