/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_usuarios
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_usuarios;

/* ============================================================
   2. Tabla usuarios
   ============================================================ */
CREATE TABLE usuarios (
    id                     BIGINT       NOT NULL AUTO_INCREMENT,
    nombre                 VARCHAR(100) NOT NULL,
    apellido               VARCHAR(100) NOT NULL,
    email                  VARCHAR(150) NOT NULL,
    password               VARCHAR(255) NOT NULL,
    telefono               VARCHAR(20)  NULL,
    rol                    VARCHAR(20)  NOT NULL DEFAULT 'CLIENTE',
    activo                 TINYINT(1)   NOT NULL DEFAULT 1,
    fecha_registro         DATETIME     NOT NULL,
    fecha_actualizacion    DATETIME     NULL,
    CONSTRAINT usuarios_PK PRIMARY KEY (id),
    CONSTRAINT usuarios_email_UN UNIQUE (email),
    CONSTRAINT chk_usuarios_rol CHECK (rol IN ('CLIENTE','ADMIN','VENDEDOR'))
) ENGINE = InnoDB;

/* ============================================================
   3. Tabla direcciones_usuario
   ============================================================ */
CREATE TABLE direcciones_usuario (
    id              BIGINT       NOT NULL AUTO_INCREMENT,
    usuario_id      BIGINT       NOT NULL,
    calle           VARCHAR(200) NOT NULL,
    ciudad          VARCHAR(100) NOT NULL,
    region          VARCHAR(100) NULL,
    codigo_postal   VARCHAR(20)  NULL,
    principal       TINYINT(1)   NOT NULL DEFAULT 0,
    CONSTRAINT direcciones_usuario_PK PRIMARY KEY (id),
    CONSTRAINT direcciones_usuario_FK FOREIGN KEY (usuario_id)
        REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE = InnoDB;

/* ============================================================
   ¡Todo listo!
   ============================================================ */
