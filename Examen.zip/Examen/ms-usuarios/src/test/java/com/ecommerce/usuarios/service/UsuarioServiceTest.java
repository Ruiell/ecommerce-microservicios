package com.ecommerce.usuarios.service;

import com.ecommerce.usuarios.dto.UsuarioDTO;
import com.ecommerce.usuarios.exception.EmailDuplicadoException;
import com.ecommerce.usuarios.exception.RecursoNoEncontradoException;
import com.ecommerce.usuarios.model.Usuario;
import com.ecommerce.usuarios.repository.UsuarioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioService usuarioService;

    private Usuario crearUsuarioDePrueba() {
        Usuario u = new Usuario();
        u.setId(1L);
        u.setNombre("Javier");
        u.setApellido("Barrios");
        u.setEmail("ja.barriose@duocuc.cl");
        u.setPassword("123456");
        u.setRol(Usuario.RolUsuario.CLIENTE);
        u.setActivo(true);
        return u;
    }

    @Test
    void testCrearUsuario() {
        when(usuarioRepository.existsByEmail("ja.barriose@duocuc.cl")).thenReturn(false);
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(crearUsuarioDePrueba());

        UsuarioDTO.Request request = new UsuarioDTO.Request();
        request.setNombre("Javier");
        request.setApellido("Barrios");
        request.setEmail("ja.barriose@duocuc.cl");
        request.setPassword("123456");

        UsuarioDTO.Response respuesta = usuarioService.crearUsuario(request);

        assertNotNull(respuesta);
        assertEquals("Javier", respuesta.getNombre());
        assertEquals(Usuario.RolUsuario.CLIENTE, respuesta.getRol());
    }

    @Test
    void testCrearUsuario_EmailDuplicado() {
        when(usuarioRepository.existsByEmail("ja.barriose@duocuc.cl")).thenReturn(true);

        UsuarioDTO.Request request = new UsuarioDTO.Request();
        request.setNombre("Javier");
        request.setApellido("Barrios");
        request.setEmail("ja.barriose@duocuc.cl");
        request.setPassword("123456");

        assertThrows(EmailDuplicadoException.class, () -> usuarioService.crearUsuario(request));
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    void testListarUsuarios() {
        when(usuarioRepository.findByActivoTrue()).thenReturn(List.of(crearUsuarioDePrueba()));

        List<UsuarioDTO.Response> usuarios = usuarioService.listarUsuarios();

        assertEquals(1, usuarios.size());
    }

    @Test
    void testObtenerPorId_NoEncontrado() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> usuarioService.obtenerPorId(99L));
    }

    @Test
    void testDesactivarUsuario() {
        Usuario usuario = crearUsuarioDePrueba();
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);

        usuarioService.desactivarUsuario(1L);

        assertFalse(usuario.getActivo());
        verify(usuarioRepository, times(1)).save(usuario);
    }

    @Test
    void testActualizarUsuario() {
        Usuario usuario = crearUsuarioDePrueba();
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);

        UsuarioDTO.UpdateRequest request = new UsuarioDTO.UpdateRequest();
        request.setTelefono("+56912345678");

        UsuarioDTO.Response resultado = usuarioService.actualizarUsuario(1L, request);

        assertEquals("+56912345678", usuario.getTelefono());
        assertNotNull(resultado);
    }

    @Test
    void testExisteUsuario() {
        when(usuarioRepository.existsById(1L)).thenReturn(true);

        assertTrue(usuarioService.existeUsuario(1L));
    }

    @Test
    void testListarPorRol() {
        when(usuarioRepository.findByRol(Usuario.RolUsuario.CLIENTE))
                .thenReturn(List.of(crearUsuarioDePrueba()));

        List<UsuarioDTO.Response> usuarios = usuarioService.listarPorRol(Usuario.RolUsuario.CLIENTE);

        assertEquals(1, usuarios.size());
    }

    @Test
    void testContarPorRol() {
        when(usuarioRepository.countByRol(Usuario.RolUsuario.ADMIN)).thenReturn(2L);

        long total = usuarioService.contarPorRol(Usuario.RolUsuario.ADMIN);

        assertEquals(2L, total);
    }
}
