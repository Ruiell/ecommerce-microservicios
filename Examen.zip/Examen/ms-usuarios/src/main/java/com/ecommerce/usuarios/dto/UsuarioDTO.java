package com.ecommerce.usuarios.dto;

import com.ecommerce.usuarios.model.Usuario.RolUsuario;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DTOs del microservicio de Usuarios
 * Separación limpia entre entidades JPA y datos de entrada/salida
 */
public class UsuarioDTO {

    // DTO para crear usuario
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Request {

        @NotBlank(message = "El nombre es obligatorio")
        @Size(min = 2, max = 100, message = "El nombre debe tener entre 2 y 100 caracteres")
        private String nombre;

        @NotBlank(message = "El apellido es obligatorio")
        @Size(min = 2, max = 100, message = "El apellido debe tener entre 2 y 100 caracteres")
        private String apellido;

        @NotBlank(message = "El email es obligatorio")
        @Email(message = "Formato de email inválido")
        private String email;

        @NotBlank(message = "La contraseña es obligatoria")
        @Size(min = 6, max = 100, message = "La contraseña debe tener al menos 6 caracteres")
        private String password;

        @Pattern(regexp = "^[0-9+\\-() ]{7,20}$", message = "Formato de teléfono inválido")
        private String telefono;
    }

    // DTO para actualizar usuario
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class UpdateRequest {

        @Size(min = 2, max = 100, message = "El nombre debe tener entre 2 y 100 caracteres")
        private String nombre;

        @Size(min = 2, max = 100, message = "El apellido debe tener entre 2 y 100 caracteres")
        private String apellido;

        @Pattern(regexp = "^[0-9+\\-() ]{7,20}$", message = "Formato de teléfono inválido")
        private String telefono;
    }

    // DTO de respuesta (sin contraseña)
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Response {
        private Long id;
        private String nombre;
        private String apellido;
        private String email;
        private String telefono;
        private RolUsuario rol;
        private Boolean activo;
        private LocalDateTime fechaRegistro;
    }
}
