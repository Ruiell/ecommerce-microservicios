package com.ecommerce.usuarios;

import com.ecommerce.usuarios.model.Usuario;
import com.ecommerce.usuarios.repository.UsuarioRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Random;

@Profile({"dev", "render"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

        Usuario.RolUsuario[] roles = Usuario.RolUsuario.values();

        for (int i = 0; i < 20; i++) {
            Usuario usuario = new Usuario();
            usuario.setNombre(faker.name().firstName());
            usuario.setApellido(faker.name().lastName());
            usuario.setEmail(faker.internet().emailAddress());
            usuario.setPassword(faker.internet().password(8, 16));
            usuario.setTelefono(faker.phoneNumber().phoneNumber());
            // La mayoría de usuarios de prueba son CLIENTE, con algunos ADMIN/VENDEDOR
            usuario.setRol(i < 17 ? Usuario.RolUsuario.CLIENTE : roles[random.nextInt(roles.length)]);
            usuario.setActivo(true);
            usuarioRepository.save(usuario);
        }

        List<Usuario> usuarios = usuarioRepository.findAll();
        System.out.println("DataLoader: se generaron " + usuarios.size() + " usuarios de ejemplo.");
    }
}
