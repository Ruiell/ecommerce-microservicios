package com.ecommerce.usuarios.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entidad JPA - Dirección asociada a un Usuario (relación ManyToOne)
 */
@Entity
@Table(name = "direcciones_usuario")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DireccionUsuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false, length = 200)
    private String calle;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String ciudad;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String region;

    @Column(name = "codigo_postal", length = 10)
    private String codigoPostal;

    @Column(name = "es_principal")
    private Boolean esPrincipal = false;

    // Clave foránea hacia Usuario
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;
}
