package com.ecommerce.usuarios.repository;

import com.ecommerce.usuarios.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository de Usuario - acceso a datos mediante JpaRepository
 */
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // Buscar por email (para login/validación de unicidad)
    Optional<Usuario> findByEmail(String email);

    // Verificar si existe email registrado
    boolean existsByEmail(String email);

    // Listar usuarios activos
    List<Usuario> findByActivoTrue();

    // Buscar por rol
    List<Usuario> findByRol(Usuario.RolUsuario rol);

    // Buscar por nombre o apellido (búsqueda parcial)
    @Query("SELECT u FROM Usuario u WHERE LOWER(u.nombre) LIKE LOWER(CONCAT('%', :termino, '%')) " +
           "OR LOWER(u.apellido) LIKE LOWER(CONCAT('%', :termino, '%'))")
    List<Usuario> buscarPorNombreOApellido(String termino);

    // Métodos personalizados para los reportes con HATEOAS (UsuarioControllerV2)
    List<Usuario> findByFechaRegistroBetween(java.time.LocalDateTime inicio, java.time.LocalDateTime fin);
    long countByRol(Usuario.RolUsuario rol);
}
