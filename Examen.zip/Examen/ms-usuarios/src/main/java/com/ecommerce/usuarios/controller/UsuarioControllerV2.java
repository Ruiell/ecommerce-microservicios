package com.ecommerce.usuarios.controller;

import com.ecommerce.usuarios.assemblers.UsuarioModelAssembler;
import com.ecommerce.usuarios.dto.UsuarioDTO;
import com.ecommerce.usuarios.model.Usuario;
import com.ecommerce.usuarios.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de usuarios.
 * Las respuestas incluyen enlaces de navegación (self, usuariosConEseRol).
 * Para la versión sin HATEOAS usar /api/usuarios (UsuarioController).
 */
@RestController
@RequestMapping("/api/v2/usuarios")
@Tag(name = "Usuarios (HATEOAS)", description = "Operaciones sobre usuarios con enlaces HATEOAS")
public class UsuarioControllerV2 {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private UsuarioModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar usuarios activos (HATEOAS)")
    public CollectionModel<EntityModel<UsuarioDTO.Response>> listar() {
        List<EntityModel<UsuarioDTO.Response>> usuarios = usuarioService.listarUsuarios().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(usuarios, linkTo(methodOn(UsuarioControllerV2.class).listar()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un usuario por id (HATEOAS)")
    public EntityModel<UsuarioDTO.Response> obtener(@PathVariable Long id) {
        return assembler.toModel(usuarioService.obtenerPorId(id));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Registrar un usuario (HATEOAS)")
    public ResponseEntity<EntityModel<UsuarioDTO.Response>> crear(@Valid @RequestBody UsuarioDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(usuarioService.crearUsuario(request)));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar un usuario (HATEOAS)")
    public EntityModel<UsuarioDTO.Response> actualizar(@PathVariable Long id, @Valid @RequestBody UsuarioDTO.UpdateRequest request) {
        return assembler.toModel(usuarioService.actualizarUsuario(id, request));
    }

    // ===== Reportes con HATEOAS (ver UsuarioService) =====

    // 1. Obtener todos los usuarios con un rol específico
    @GetMapping(value = "/rol/{rol}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar usuarios por rol (HATEOAS)", description = "Roles válidos: CLIENTE, ADMIN, VENDEDOR")
    public CollectionModel<EntityModel<UsuarioDTO.Response>> listarPorRol(@PathVariable Usuario.RolUsuario rol) {
        List<EntityModel<UsuarioDTO.Response>> usuarios = usuarioService.listarPorRol(rol).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(usuarios, linkTo(methodOn(UsuarioControllerV2.class).listarPorRol(rol)).withSelfRel());
    }

    // 2. Obtener todos los usuarios registrados en una fecha específica (ej: /api/v2/usuarios/fecha/2026-06-26)
    @GetMapping(value = "/fecha/{fecha}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar usuarios registrados en una fecha específica (HATEOAS)")
    public CollectionModel<EntityModel<UsuarioDTO.Response>> listarPorFecha(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        List<EntityModel<UsuarioDTO.Response>> usuarios = usuarioService.listarPorFecha(fecha).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(usuarios, linkTo(methodOn(UsuarioControllerV2.class).listarPorFecha(fecha)).withSelfRel());
    }

    // 3. Obtener todos los usuarios registrados entre dos fechas
    @GetMapping(value = "/rango", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar usuarios registrados entre dos fechas (HATEOAS)")
    public CollectionModel<EntityModel<UsuarioDTO.Response>> listarEntreFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        List<EntityModel<UsuarioDTO.Response>> usuarios = usuarioService.listarEntreFechas(inicio, fin).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(usuarios, linkTo(methodOn(UsuarioControllerV2.class).listarEntreFechas(inicio, fin)).withSelfRel());
    }

    // 4. Obtener el total de usuarios con un rol específico
    @GetMapping(value = "/rol/{rol}/total", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el total de usuarios con un rol específico (HATEOAS)")
    public EntityModel<Map<String, Object>> contarPorRol(@PathVariable Usuario.RolUsuario rol) {
        long total = usuarioService.contarPorRol(rol);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("rol", rol);
        body.put("totalUsuarios", total);

        return EntityModel.of(body,
                linkTo(methodOn(UsuarioControllerV2.class).contarPorRol(rol)).withSelfRel(),
                linkTo(methodOn(UsuarioControllerV2.class).listarPorRol(rol)).withRel("usuariosConEseRol"));
    }
}
