package com.ecommerce.usuarios.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.usuarios.controller.UsuarioControllerV2;
import com.ecommerce.usuarios.dto.UsuarioDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class UsuarioModelAssembler implements RepresentationModelAssembler<UsuarioDTO.Response, EntityModel<UsuarioDTO.Response>> {

    @Override
    public EntityModel<UsuarioDTO.Response> toModel(UsuarioDTO.Response usuario) {
        return EntityModel.of(usuario,
                linkTo(methodOn(UsuarioControllerV2.class).obtener(usuario.getId())).withSelfRel(),
                linkTo(methodOn(UsuarioControllerV2.class).listarPorRol(usuario.getRol())).withRel("usuariosConEseRol"));
    }
}
