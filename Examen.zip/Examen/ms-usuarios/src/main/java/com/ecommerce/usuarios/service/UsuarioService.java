package com.ecommerce.usuarios.service;

import com.ecommerce.usuarios.dto.UsuarioDTO;
import com.ecommerce.usuarios.exception.RecursoNoEncontradoException;
import com.ecommerce.usuarios.exception.EmailDuplicadoException;
import com.ecommerce.usuarios.model.Usuario;
import com.ecommerce.usuarios.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Servicio de Usuarios - Capa de lógica de negocio
 * Patrón CSR: Solo lógica de negocio, sin manejo de HTTP
 */
@Service
@RequiredArgsConstructor
public class UsuarioService {

    private static final Logger log = LoggerFactory.getLogger(UsuarioService.class);

    private final UsuarioRepository usuarioRepository;

    /**
     * Registra un nuevo usuario en el sistema
     * Regla de negocio: El email debe ser único
     */
    @Transactional
    public UsuarioDTO.Response crearUsuario(UsuarioDTO.Request request) {
        log.info("Iniciando registro de usuario con email: {}", request.getEmail());

        // Regla de negocio: validar email único
        if (usuarioRepository.existsByEmail(request.getEmail())) {
            log.warn("Intento de registro con email duplicado: {}", request.getEmail());
            throw new EmailDuplicadoException("Ya existe un usuario registrado con el email: " + request.getEmail());
        }

        Usuario usuario = new Usuario();
        usuario.setNombre(request.getNombre());
        usuario.setApellido(request.getApellido());
        usuario.setEmail(request.getEmail());
        // En producción se usaría BCrypt - simplificado para el proyecto
        usuario.setPassword(request.getPassword());
        usuario.setTelefono(request.getTelefono());
        usuario.setRol(Usuario.RolUsuario.CLIENTE);
        usuario.setActivo(true);

        Usuario guardado = usuarioRepository.save(usuario);
        log.info("Usuario creado exitosamente con ID: {}", guardado.getId());

        return mapearAResponse(guardado);
    }

    /**
     * Obtiene todos los usuarios activos
     */
    @Transactional(readOnly = true)
    public List<UsuarioDTO.Response> listarUsuarios() {
        log.info("Listando todos los usuarios activos");
        List<Usuario> usuarios = usuarioRepository.findByActivoTrue();
        log.debug("Total de usuarios activos encontrados: {}", usuarios.size());
        return usuarios.stream().map(this::mapearAResponse).collect(Collectors.toList());
    }

    /**
     * Obtiene un usuario por su ID
     */
    @Transactional(readOnly = true)
    public UsuarioDTO.Response obtenerPorId(Long id) {
        log.info("Buscando usuario con ID: {}", id);
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Usuario no encontrado con ID: {}", id);
                    return new RecursoNoEncontradoException("Usuario no encontrado con ID: " + id);
                });
        return mapearAResponse(usuario);
    }

    /**
     * Actualiza datos de un usuario existente
     */
    @Transactional
    public UsuarioDTO.Response actualizarUsuario(Long id, UsuarioDTO.UpdateRequest request) {
        log.info("Actualizando usuario con ID: {}", id);

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con ID: " + id));

        if (request.getNombre() != null) usuario.setNombre(request.getNombre());
        if (request.getApellido() != null) usuario.setApellido(request.getApellido());
        if (request.getTelefono() != null) usuario.setTelefono(request.getTelefono());

        Usuario actualizado = usuarioRepository.save(usuario);
        log.info("Usuario actualizado exitosamente: {}", id);
        return mapearAResponse(actualizado);
    }

    /**
     * Desactiva un usuario (borrado lógico)
     * Regla de negocio: No se elimina físicamente para mantener integridad referencial
     */
    @Transactional
    public void desactivarUsuario(Long id) {
        log.info("Desactivando usuario con ID: {}", id);
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con ID: " + id));

        usuario.setActivo(false);
        usuarioRepository.save(usuario);
        log.info("Usuario desactivado exitosamente: {}", id);
    }

    /**
     * Busca usuarios por término de búsqueda
     */
    @Transactional(readOnly = true)
    public List<UsuarioDTO.Response> buscarUsuarios(String termino) {
        log.info("Buscando usuarios con término: {}", termino);
        return usuarioRepository.buscarPorNombreOApellido(termino)
                .stream().map(this::mapearAResponse).collect(Collectors.toList());
    }

    /**
     * Valida si un usuario existe (usado por otros microservicios)
     */
    @Transactional(readOnly = true)
    public boolean existeUsuario(Long id) {
        boolean existe = usuarioRepository.existsById(id);
        log.debug("Verificación de existencia para usuario ID {}: {}", id, existe);
        return existe;
    }

    // ========================
    // Método privado de mapeo
    // ========================
    private UsuarioDTO.Response mapearAResponse(Usuario usuario) {
        UsuarioDTO.Response response = new UsuarioDTO.Response();
        response.setId(usuario.getId());
        response.setNombre(usuario.getNombre());
        response.setApellido(usuario.getApellido());
        response.setEmail(usuario.getEmail());
        response.setTelefono(usuario.getTelefono());
        response.setRol(usuario.getRol());
        response.setActivo(usuario.getActivo());
        response.setFechaRegistro(usuario.getFechaRegistro());
        return response;
    }

    // ===== Reportes con HATEOAS (mismo patrón que PagoService/PedidoService) =====

    // 1. Obtener todos los usuarios con un rol específico
    @Transactional(readOnly = true)
    public List<UsuarioDTO.Response> listarPorRol(Usuario.RolUsuario rol) {
        return usuarioRepository.findByRol(rol).stream().map(this::mapearAResponse).collect(Collectors.toList());
    }

    // 2. Obtener todos los usuarios registrados en una fecha específica (entre el inicio y el fin de ese día)
    @Transactional(readOnly = true)
    public List<UsuarioDTO.Response> listarPorFecha(java.time.LocalDate fecha) {
        java.time.LocalDateTime inicio = fecha.atStartOfDay();
        java.time.LocalDateTime fin = fecha.atTime(java.time.LocalTime.MAX);
        return usuarioRepository.findByFechaRegistroBetween(inicio, fin).stream().map(this::mapearAResponse).collect(Collectors.toList());
    }

    // 3. Obtener todos los usuarios registrados entre dos fechas
    @Transactional(readOnly = true)
    public List<UsuarioDTO.Response> listarEntreFechas(java.time.LocalDateTime inicio, java.time.LocalDateTime fin) {
        return usuarioRepository.findByFechaRegistroBetween(inicio, fin).stream().map(this::mapearAResponse).collect(Collectors.toList());
    }

    // 4. Obtener el total de usuarios con un rol específico
    @Transactional(readOnly = true)
    public long contarPorRol(Usuario.RolUsuario rol) {
        return usuarioRepository.countByRol(rol);
    }
}
