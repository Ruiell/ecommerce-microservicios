package com.ecommerce.usuarios.exception;

/**
 * Excepción para email duplicado - HTTP 409 Conflict
 */
public class EmailDuplicadoException extends RuntimeException {
    public EmailDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
