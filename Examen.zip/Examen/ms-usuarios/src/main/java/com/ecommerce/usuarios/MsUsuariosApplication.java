package com.ecommerce.usuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Microservicio de Gestión de Usuarios
 * Puerto: 8081
 * Responsabilidad: Registro, autenticación y gestión de perfiles de usuario
 */
@SpringBootApplication
@EnableFeignClients
public class MsUsuariosApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsUsuariosApplication.class, args);
    }
}
