package com.ecommerce.usuarios.controller;

import com.ecommerce.usuarios.dto.UsuarioDTO;
import com.ecommerce.usuarios.service.UsuarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controller REST - Gestión de Usuarios
 * Patrón CSR: Solo manejo de solicitudes HTTP, delega lógica al Service
 */
@RestController
@RequestMapping("/api/usuarios")
@RequiredArgsConstructor
public class UsuarioController {

    private static final Logger log = LoggerFactory.getLogger(UsuarioController.class);

    private final UsuarioService usuarioService;

    /**
     * GET /api/usuarios
     * Lista todos los usuarios activos
     */
    @GetMapping
    public ResponseEntity<List<UsuarioDTO.Response>> listarUsuarios() {
        log.info("GET /api/usuarios - Listando usuarios");
        List<UsuarioDTO.Response> usuarios = usuarioService.listarUsuarios();
        return ResponseEntity.ok(usuarios);
    }

    /**
     * GET /api/usuarios/{id}
     * Obtiene un usuario por ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDTO.Response> obtenerUsuario(@PathVariable Long id) {
        log.info("GET /api/usuarios/{} - Obteniendo usuario", id);
        return ResponseEntity.ok(usuarioService.obtenerPorId(id));
    }

    /**
     * POST /api/usuarios
     * Registra un nuevo usuario
     */
    @PostMapping
    public ResponseEntity<UsuarioDTO.Response> crearUsuario(@Valid @RequestBody UsuarioDTO.Request request) {
        log.info("POST /api/usuarios - Creando nuevo usuario");
        UsuarioDTO.Response creado = usuarioService.crearUsuario(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    /**
     * PUT /api/usuarios/{id}
     * Actualiza datos de un usuario
     */
    @PutMapping("/{id}")
    public ResponseEntity<UsuarioDTO.Response> actualizarUsuario(
            @PathVariable Long id,
            @Valid @RequestBody UsuarioDTO.UpdateRequest request) {
        log.info("PUT /api/usuarios/{} - Actualizando usuario", id);
        return ResponseEntity.ok(usuarioService.actualizarUsuario(id, request));
    }

    /**
     * DELETE /api/usuarios/{id}
     * Desactiva un usuario (borrado lógico)
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> desactivarUsuario(@PathVariable Long id) {
        log.info("DELETE /api/usuarios/{} - Desactivando usuario", id);
        usuarioService.desactivarUsuario(id);
        return ResponseEntity.ok(Map.of("mensaje", "Usuario desactivado exitosamente"));
    }

    /**
     * GET /api/usuarios/buscar?termino=
     * Busca usuarios por nombre o apellido
     */
    @GetMapping("/buscar")
    public ResponseEntity<List<UsuarioDTO.Response>> buscarUsuarios(@RequestParam String termino) {
        log.info("GET /api/usuarios/buscar?termino={}", termino);
        return ResponseEntity.ok(usuarioService.buscarUsuarios(termino));
    }

    /**
     * GET /api/usuarios/{id}/existe
     * Endpoint interno para que otros microservicios validen existencia de usuario
     */
    @GetMapping("/{id}/existe")
    public ResponseEntity<Map<String, Boolean>> verificarExistencia(@PathVariable Long id) {
        log.info("GET /api/usuarios/{}/existe - Verificando existencia", id);
        boolean existe = usuarioService.existeUsuario(id);
        return ResponseEntity.ok(Map.of("existe", existe));
    }
}
