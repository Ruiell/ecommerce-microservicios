/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_inventario_dev
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_inventario_dev;

/* ============================================================
   2. Tabla inventario
   ============================================================ */
CREATE TABLE inventario (
    id                      BIGINT   NOT NULL AUTO_INCREMENT,
    producto_id             BIGINT   NOT NULL,
    stock                   INT      NOT NULL DEFAULT 0,
    stock_minimo            INT      NOT NULL DEFAULT 5,
    ultima_actualizacion    DATETIME NULL,
    CONSTRAINT inventario_PK PRIMARY KEY (id),
    CONSTRAINT inventario_producto_UN UNIQUE (producto_id),
    CONSTRAINT chk_inventario_stock CHECK (stock >= 0),
    CONSTRAINT chk_inventario_stock_minimo CHECK (stock_minimo >= 0)
) ENGINE = InnoDB;

/* ============================================================
   3. Tabla movimientos_inventario
   ============================================================ */
CREATE TABLE movimientos_inventario (
    id                  BIGINT       NOT NULL AUTO_INCREMENT,
    inventario_id       BIGINT       NOT NULL,
    producto_id         BIGINT       NOT NULL,
    tipo                VARCHAR(20)  NOT NULL,
    cantidad            INT          NOT NULL,
    stock_anterior      INT          NULL,
    stock_resultante    INT          NULL,
    motivo              VARCHAR(255) NULL,
    fecha_movimiento    DATETIME     NOT NULL,
    CONSTRAINT movimientos_inventario_PK PRIMARY KEY (id),
    CONSTRAINT movimientos_inventario_FK FOREIGN KEY (inventario_id)
        REFERENCES inventario (id) ON DELETE CASCADE,
    CONSTRAINT chk_movimientos_tipo CHECK (tipo IN ('ENTRADA','SALIDA','AJUSTE'))
) ENGINE = InnoDB;

/* ============================================================
   ¡Todo listo!
   ============================================================ */
