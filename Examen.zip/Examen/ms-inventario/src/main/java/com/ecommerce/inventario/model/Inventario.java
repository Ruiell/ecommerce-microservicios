package com.ecommerce.inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entidad JPA - Stock de un producto en inventario
 */
@Entity
@Table(name = "inventario")
@Data @NoArgsConstructor @AllArgsConstructor
public class Inventario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Column(name = "producto_id", nullable = false, unique = true)
    private Long productoId;

    @NotNull
    @Min(value = 0, message = "El stock no puede ser negativo")
    @Column(nullable = false)
    private Integer stock = 0;

    @Min(0)
    @Column(name = "stock_minimo")
    private Integer stockMinimo = 5;

    @Column(name = "ultima_actualizacion")
    private LocalDateTime ultimaActualizacion;

    @PrePersist @PreUpdate
    protected void onUpdate() { ultimaActualizacion = LocalDateTime.now(); }
}
