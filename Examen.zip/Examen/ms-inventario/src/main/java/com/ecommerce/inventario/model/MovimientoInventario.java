package com.ecommerce.inventario.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entidad JPA - Historial de movimientos de stock
 */
@Entity
@Table(name = "movimientos_inventario")
@Data @NoArgsConstructor @AllArgsConstructor
public class MovimientoInventario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "inventario_id", nullable = false)
    private Long inventarioId;

    @Column(name = "producto_id", nullable = false)
    private Long productoId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipoMovimiento tipo;

    @Column(nullable = false)
    private Integer cantidad;

    @Column(name = "stock_anterior")
    private Integer stockAnterior;

    @Column(name = "stock_resultante")
    private Integer stockResultante;

    @Column(length = 255)
    private String motivo;

    @Column(name = "fecha_movimiento", updatable = false)
    private LocalDateTime fechaMovimiento;

    @PrePersist
    protected void onCreate() { fechaMovimiento = LocalDateTime.now(); }

    public enum TipoMovimiento { ENTRADA, SALIDA, AJUSTE }
}
