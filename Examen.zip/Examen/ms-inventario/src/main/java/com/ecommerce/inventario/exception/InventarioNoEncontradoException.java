package com.ecommerce.inventario.exception;
public class InventarioNoEncontradoException extends RuntimeException {
    public InventarioNoEncontradoException(String msg) { super(msg); }
}
