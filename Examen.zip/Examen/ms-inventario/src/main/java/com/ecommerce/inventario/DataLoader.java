package com.ecommerce.inventario;

import com.ecommerce.inventario.model.Inventario;
import com.ecommerce.inventario.model.MovimientoInventario;
import com.ecommerce.inventario.model.MovimientoInventario.TipoMovimiento;
import com.ecommerce.inventario.repository.InventarioRepository;
import com.ecommerce.inventario.repository.MovimientoInventarioRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Random;

@Profile({"dev", "render", "aiven"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private InventarioRepository inventarioRepository;

    @Autowired
    private MovimientoInventarioRepository movimientoInventarioRepository;

    @Override
    public void run(String... args) throws Exception {
        if (inventarioRepository.count() > 0) {
            return;
        }

        Faker faker = new Faker();
        Random random = new Random();

        for (long productoId = 1; productoId <= 30; productoId++) {
            Inventario inventario = new Inventario();
            inventario.setProductoId(productoId);
            int stockInicial = faker.number().numberBetween(0, 200);
            inventario.setStock(stockInicial);
            inventario.setStockMinimo(faker.number().numberBetween(3, 15));
            inventario = inventarioRepository.save(inventario);

            MovimientoInventario movimiento = new MovimientoInventario();
            movimiento.setInventarioId(inventario.getId());
            movimiento.setProductoId(productoId);
            movimiento.setTipo(TipoMovimiento.ENTRADA);
            movimiento.setCantidad(stockInicial);
            movimiento.setStockAnterior(0);
            movimiento.setStockResultante(stockInicial);
            movimiento.setMotivo("Carga inicial de stock");
            movimientoInventarioRepository.save(movimiento);

            if (random.nextInt(10) < 4) {
                TipoMovimiento[] tipos = {TipoMovimiento.SALIDA, TipoMovimiento.AJUSTE};
                TipoMovimiento tipo = tipos[random.nextInt(tipos.length)];
                int cantidad = faker.number().numberBetween(1, 20);
                int nuevoStock = tipo == TipoMovimiento.SALIDA
                        ? Math.max(0, stockInicial - cantidad)
                        : stockInicial + cantidad;

                MovimientoInventario movimientoExtra = new MovimientoInventario();
                movimientoExtra.setInventarioId(inventario.getId());
                movimientoExtra.setProductoId(productoId);
                movimientoExtra.setTipo(tipo);
                movimientoExtra.setCantidad(cantidad);
                movimientoExtra.setStockAnterior(stockInicial);
                movimientoExtra.setStockResultante(nuevoStock);
                movimientoExtra.setMotivo(faker.commerce().productName());
                movimientoInventarioRepository.save(movimientoExtra);

                inventario.setStock(nuevoStock);
                inventarioRepository.save(inventario);
            }
        }

        System.out.println(">> DataLoader: 30 registros de inventario de prueba cargados en ms-inventario (perfil dev).");
    }
}
