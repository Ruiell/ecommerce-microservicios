package com.ecommerce.inventario.controller;

import com.ecommerce.inventario.dto.InventarioDTO;
import com.ecommerce.inventario.service.InventarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/inventario")
@RequiredArgsConstructor
public class InventarioController {

    private static final Logger log = LoggerFactory.getLogger(InventarioController.class);
    private final InventarioService inventarioService;

    @GetMapping
    public ResponseEntity<List<InventarioDTO.Response>> listar() {
        log.info("GET /api/inventario");
        return ResponseEntity.ok(inventarioService.listarTodos());
    }

    @GetMapping("/producto/{productoId}")
    public ResponseEntity<InventarioDTO.Response> obtenerPorProducto(@PathVariable Long productoId) {
        log.info("GET /api/inventario/producto/{}", productoId);
        return ResponseEntity.ok(inventarioService.obtenerPorProducto(productoId));
    }

    @GetMapping("/stock-bajo")
    public ResponseEntity<List<InventarioDTO.Response>> stockBajo() {
        log.info("GET /api/inventario/stock-bajo");
        return ResponseEntity.ok(inventarioService.listarStockBajo());
    }

    @PostMapping
    public ResponseEntity<InventarioDTO.Response> crear(@Valid @RequestBody InventarioDTO.Request request) {
        log.info("POST /api/inventario - productoId: {}", request.getProductoId());
        return ResponseEntity.status(HttpStatus.CREATED).body(inventarioService.crearInventario(request));
    }

    @PostMapping("/movimiento")
    public ResponseEntity<InventarioDTO.Response> registrarMovimiento(@Valid @RequestBody InventarioDTO.MovimientoRequest request) {
        log.info("POST /api/inventario/movimiento - tipo: {}", request.getTipo());
        return ResponseEntity.ok(inventarioService.registrarMovimiento(request));
    }

    /* ===== Endpoints consumidos por otros microservicios (ms-pedidos, ms-carrito) vía Feign ===== */

    @GetMapping("/producto/{productoId}/disponibilidad")
    public ResponseEntity<Map<String, Object>> verificarDisponibilidad(@PathVariable Long productoId,
            @RequestParam Integer cantidad) {
        log.info("GET /api/inventario/producto/{}/disponibilidad?cantidad={}", productoId, cantidad);
        boolean disponible = inventarioService.verificarDisponibilidad(productoId, cantidad);
        return ResponseEntity.ok(Map.of("productoId", productoId, "cantidadSolicitada", cantidad, "disponible", disponible));
    }

    @PostMapping("/producto/{productoId}/reservar")
    public ResponseEntity<InventarioDTO.Response> reservarStock(@PathVariable Long productoId,
            @RequestParam Integer cantidad) {
        log.info("POST /api/inventario/producto/{}/reservar?cantidad={}", productoId, cantidad);
        return ResponseEntity.ok(inventarioService.reservarStock(productoId, cantidad));
    }

    @PostMapping("/producto/{productoId}/liberar")
    public ResponseEntity<InventarioDTO.Response> liberarReserva(@PathVariable Long productoId,
            @RequestParam Integer cantidad) {
        log.info("POST /api/inventario/producto/{}/liberar?cantidad={}", productoId, cantidad);
        return ResponseEntity.ok(inventarioService.liberarReserva(productoId, cantidad));
    }

    @PostMapping("/producto/{productoId}/salida")
    public ResponseEntity<InventarioDTO.Response> salida(@PathVariable Long productoId,
            @RequestBody Map<String, Object> body) {
        Integer cantidad = ((Number) body.get("cantidad")).intValue();
        log.info("POST /api/inventario/producto/{}/salida - cantidad: {}", productoId, cantidad);
        return ResponseEntity.ok(inventarioService.reservarStock(productoId, cantidad));
    }
}
