package com.ecommerce.inventario.service;

import com.ecommerce.inventario.dto.InventarioDTO;
import com.ecommerce.inventario.exception.*;
import com.ecommerce.inventario.model.Inventario;
import com.ecommerce.inventario.model.MovimientoInventario;
import com.ecommerce.inventario.model.MovimientoInventario.TipoMovimiento;
import com.ecommerce.inventario.repository.InventarioRepository;
import com.ecommerce.inventario.repository.MovimientoInventarioRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Servicio de Inventario - Lógica de negocio de stock
 * Usa WebClient para validar producto en ms-productos
 */
@Service
@RequiredArgsConstructor
public class InventarioService {

    private static final Logger log = LoggerFactory.getLogger(InventarioService.class);
    private final InventarioRepository inventarioRepository;
    private final MovimientoInventarioRepository movimientoRepository;
    private final WebClient.Builder webClientBuilder;

    @Value("${microservices.productos.url}")
    private String productosUrl;

    @Transactional
    public InventarioDTO.Response crearInventario(InventarioDTO.Request request) {
        log.info("Creando inventario para productoId: {}", request.getProductoId());

        // Regla de negocio: validar producto via WebClient
        try {
            Boolean existe = webClientBuilder.build()
                    .get()
                    .uri(productosUrl + "/api/productos/{id}/existe", request.getProductoId())
                    .retrieve()
                    .bodyToMono(java.util.Map.class)
                    .map(m -> (Boolean) m.get("existe"))
                    .block(java.time.Duration.ofSeconds(5));
            if (Boolean.FALSE.equals(existe)) {
                throw new RecursoNoEncontradoException("Producto no existe: " + request.getProductoId());
            }
        } catch (RecursoNoEncontradoException e) {
            throw e;
        } catch (Exception e) {
            log.warn("No se pudo validar el producto (ms-productos no disponible): {}", e.getMessage());
        }

        if (inventarioRepository.existsByProductoId(request.getProductoId())) {
            throw new IllegalStateException("Ya existe inventario para el producto: " + request.getProductoId());
        }

        Inventario inventario = new Inventario();
        inventario.setProductoId(request.getProductoId());
        inventario.setStock(request.getStock());
        inventario.setStockMinimo(request.getStockMinimo() != null ? request.getStockMinimo() : 5);
        Inventario guardado = inventarioRepository.save(inventario);
        log.info("Inventario creado ID: {}", guardado.getId());
        return mapear(guardado);
    }

    @Transactional
    public InventarioDTO.Response registrarMovimiento(InventarioDTO.MovimientoRequest request) {
        log.info("Registrando movimiento {} para productoId: {}", request.getTipo(), request.getProductoId());

        Inventario inventario = inventarioRepository.findByProductoId(request.getProductoId())
                .orElseThrow(() -> new RecursoNoEncontradoException("Inventario no encontrado para producto: " + request.getProductoId()));

        int stockAnterior = inventario.getStock();
        int nuevoStock;

        // Regla de negocio: calcular nuevo stock según tipo de movimiento
        nuevoStock = switch (request.getTipo()) {
            case ENTRADA, AJUSTE -> stockAnterior + request.getCantidad();
            case SALIDA -> {
                if (stockAnterior < request.getCantidad()) {
                    log.warn("Stock insuficiente: disponible={}, solicitado={}", stockAnterior, request.getCantidad());
                    throw new StockInsuficienteException(
                        "Stock insuficiente. Disponible: " + stockAnterior + ", Solicitado: " + request.getCantidad());
                }
                yield stockAnterior - request.getCantidad();
            }
        };

        inventario.setStock(nuevoStock);
        inventarioRepository.save(inventario);

        // Registrar movimiento en historial
        MovimientoInventario movimiento = new MovimientoInventario();
        movimiento.setInventarioId(inventario.getId());
        movimiento.setProductoId(request.getProductoId());
        movimiento.setTipo(request.getTipo());
        movimiento.setCantidad(request.getCantidad());
        movimiento.setStockAnterior(stockAnterior);
        movimiento.setStockResultante(nuevoStock);
        movimiento.setMotivo(request.getMotivo());
        movimientoRepository.save(movimiento);

        if (nuevoStock <= inventario.getStockMinimo()) {
            log.warn("ALERTA: Stock bajo para productoId={}, stock={}", request.getProductoId(), nuevoStock);
        }

        log.info("Movimiento registrado: {} -> stock {} -> {}", request.getTipo(), stockAnterior, nuevoStock);
        return mapear(inventario);
    }

    @Transactional(readOnly = true)
    public InventarioDTO.Response obtenerPorProducto(Long productoId) {
        log.info("Consultando inventario para productoId: {}", productoId);
        return mapear(inventarioRepository.findByProductoId(productoId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Inventario no encontrado para producto: " + productoId)));
    }

    @Transactional(readOnly = true)
    public List<InventarioDTO.Response> listarStockBajo() {
        log.info("Listando productos con stock bajo");
        return inventarioRepository.findStockBajo().stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<InventarioDTO.Response> listarTodos() {
        return inventarioRepository.findAll().stream().map(this::mapear).collect(Collectors.toList());
    }

    /* ===== Endpoints consumidos por otros microservicios vía Feign =====
       ms-pedidos.InventarioFeignClient.reducirStock()      -> POST /producto/{id}/salida
       ms-carrito.InventarioFeignClient.verificarDisponibilidad() -> GET  /producto/{id}/disponibilidad
       ms-carrito.InventarioFeignClient.reservarStock()      -> POST /producto/{id}/reservar
       ms-carrito.InventarioFeignClient.liberarReserva()     -> POST /producto/{id}/liberar
       Todas reutilizan la misma lógica de registrarMovimiento() para mantener el historial consistente. */

    @Transactional(readOnly = true)
    public boolean verificarDisponibilidad(Long productoId, Integer cantidad) {
        return inventarioRepository.findByProductoId(productoId)
                .map(inv -> inv.getStock() >= cantidad)
                .orElse(false);
    }

    @Transactional
    public InventarioDTO.Response reservarStock(Long productoId, Integer cantidad) {
        log.info("Reservando stock (salida) productoId={} cantidad={}", productoId, cantidad);
        InventarioDTO.MovimientoRequest request = new InventarioDTO.MovimientoRequest();
        request.setProductoId(productoId);
        request.setTipo(TipoMovimiento.SALIDA);
        request.setCantidad(cantidad);
        request.setMotivo("Reserva/salida solicitada por otro microservicio");
        return registrarMovimiento(request);
    }

    @Transactional
    public InventarioDTO.Response liberarReserva(Long productoId, Integer cantidad) {
        log.info("Liberando reserva (entrada) productoId={} cantidad={}", productoId, cantidad);
        InventarioDTO.MovimientoRequest request = new InventarioDTO.MovimientoRequest();
        request.setProductoId(productoId);
        request.setTipo(TipoMovimiento.ENTRADA);
        request.setCantidad(cantidad);
        request.setMotivo("Liberación de reserva solicitada por otro microservicio");
        return registrarMovimiento(request);
    }

    // ===== Reportes con HATEOAS (mismo patrón que PagoService/PedidoService) =====

    // 1. Obtener el historial de movimientos de un producto
    @Transactional(readOnly = true)
    public List<MovimientoInventario> listarMovimientosPorProducto(Long productoId) {
        return movimientoRepository.findByProductoIdOrderByFechaMovimientoDesc(productoId);
    }

    private InventarioDTO.Response mapear(Inventario i) {
        InventarioDTO.Response r = new InventarioDTO.Response();
        r.setId(i.getId()); r.setProductoId(i.getProductoId());
        r.setStock(i.getStock()); r.setStockMinimo(i.getStockMinimo());
        r.setStockBajo(i.getStock() <= i.getStockMinimo());
        r.setUltimaActualizacion(i.getUltimaActualizacion());
        return r;
    }
}
