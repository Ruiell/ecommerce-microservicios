package com.ecommerce.inventario.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.inventario.controller.InventarioControllerV2;
import com.ecommerce.inventario.dto.InventarioDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class InventarioModelAssembler implements RepresentationModelAssembler<InventarioDTO.Response, EntityModel<InventarioDTO.Response>> {

    @Override
    public EntityModel<InventarioDTO.Response> toModel(InventarioDTO.Response inventario) {
        return EntityModel.of(inventario,
                linkTo(methodOn(InventarioControllerV2.class).obtenerPorProducto(inventario.getProductoId())).withSelfRel(),
                linkTo(methodOn(InventarioControllerV2.class).listarMovimientos(inventario.getProductoId())).withRel("movimientos"));
    }
}
