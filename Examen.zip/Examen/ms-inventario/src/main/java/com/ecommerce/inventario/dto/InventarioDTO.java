package com.ecommerce.inventario.dto;

import com.ecommerce.inventario.model.MovimientoInventario.TipoMovimiento;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

public class InventarioDTO {

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Request {
        @NotNull(message = "El productoId es obligatorio")
        private Long productoId;
        @NotNull @Min(0)
        private Integer stock;
        @Min(0)
        private Integer stockMinimo;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class MovimientoRequest {
        @NotNull
        private Long productoId;
        @NotNull
        private TipoMovimiento tipo;
        @NotNull @Min(1)
        private Integer cantidad;
        private String motivo;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id;
        private Long productoId;
        private Integer stock;
        private Integer stockMinimo;
        private Boolean stockBajo;
        private LocalDateTime ultimaActualizacion;
    }
}
