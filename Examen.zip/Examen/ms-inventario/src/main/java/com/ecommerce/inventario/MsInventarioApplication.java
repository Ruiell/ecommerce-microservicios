package com.ecommerce.inventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Microservicio de Inventario
 * Puerto: 8084
 * Responsabilidad: Stock, movimientos y alertas de inventario
 * Comunicación: WebClient → ms-productos para validar existencia
 */
@SpringBootApplication
@EnableFeignClients
public class MsInventarioApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsInventarioApplication.class, args);
    }
}
