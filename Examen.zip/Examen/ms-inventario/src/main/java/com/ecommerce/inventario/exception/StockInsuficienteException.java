package com.ecommerce.inventario.exception;
public class StockInsuficienteException extends RuntimeException {
    public StockInsuficienteException(String m) { super(m); }
}
