package com.ecommerce.inventario.controller;

import com.ecommerce.inventario.assemblers.InventarioModelAssembler;
import com.ecommerce.inventario.dto.InventarioDTO;
import com.ecommerce.inventario.model.MovimientoInventario;
import com.ecommerce.inventario.service.InventarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de inventario.
 * Las respuestas incluyen enlaces de navegación (self, movimientos).
 * Para la versión sin HATEOAS usar /api/inventario (InventarioController).
 */
@RestController
@RequestMapping("/api/v2/inventario")
@Tag(name = "Inventario (HATEOAS)", description = "Operaciones sobre inventario con enlaces HATEOAS")
public class InventarioControllerV2 {

    @Autowired
    private InventarioService inventarioService;

    @Autowired
    private InventarioModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar todo el inventario (HATEOAS)")
    public CollectionModel<EntityModel<InventarioDTO.Response>> listar() {
        List<EntityModel<InventarioDTO.Response>> inventarios = inventarioService.listarTodos().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(inventarios, linkTo(methodOn(InventarioControllerV2.class).listar()).withSelfRel());
    }

    @GetMapping(value = "/producto/{productoId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el inventario de un producto (HATEOAS)")
    public EntityModel<InventarioDTO.Response> obtenerPorProducto(@PathVariable Long productoId) {
        return assembler.toModel(inventarioService.obtenerPorProducto(productoId));
    }

    @GetMapping(value = "/stock-bajo", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar productos con stock bajo (HATEOAS)")
    public CollectionModel<EntityModel<InventarioDTO.Response>> stockBajo() {
        List<EntityModel<InventarioDTO.Response>> inventarios = inventarioService.listarStockBajo().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(inventarios, linkTo(methodOn(InventarioControllerV2.class).stockBajo()).withSelfRel());
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear inventario para un producto (HATEOAS)")
    public ResponseEntity<EntityModel<InventarioDTO.Response>> crear(@Valid @RequestBody InventarioDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(inventarioService.crearInventario(request)));
    }

    @PostMapping(value = "/movimiento", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Registrar un movimiento de stock (HATEOAS)")
    public EntityModel<InventarioDTO.Response> registrarMovimiento(@Valid @RequestBody InventarioDTO.MovimientoRequest request) {
        return assembler.toModel(inventarioService.registrarMovimiento(request));
    }

    // ===== Reportes con HATEOAS (ver InventarioService) =====

    // 1. Obtener el historial de movimientos de un producto
    @GetMapping(value = "/producto/{productoId}/movimientos", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar el historial de movimientos de un producto (HATEOAS)")
    public CollectionModel<MovimientoInventario> listarMovimientos(@PathVariable Long productoId) {
        List<MovimientoInventario> movimientos = inventarioService.listarMovimientosPorProducto(productoId);
        return CollectionModel.of(movimientos,
                linkTo(methodOn(InventarioControllerV2.class).listarMovimientos(productoId)).withSelfRel(),
                linkTo(methodOn(InventarioControllerV2.class).obtenerPorProducto(productoId)).withRel("inventario"));
    }
}
