package com.ecommerce.inventario.service;

import com.ecommerce.inventario.dto.InventarioDTO;
import com.ecommerce.inventario.exception.RecursoNoEncontradoException;
import com.ecommerce.inventario.exception.StockInsuficienteException;
import com.ecommerce.inventario.model.Inventario;
import com.ecommerce.inventario.model.MovimientoInventario.TipoMovimiento;
import com.ecommerce.inventario.repository.InventarioRepository;
import com.ecommerce.inventario.repository.MovimientoInventarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InventarioServiceTest {

    @Mock
    private InventarioRepository inventarioRepository;

    @Mock
    private MovimientoInventarioRepository movimientoRepository;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private WebClient.Builder webClientBuilder;

    private InventarioService inventarioService;

    @BeforeEach
    void setUp() {
        inventarioService = new InventarioService(inventarioRepository, movimientoRepository, webClientBuilder);
    }

    private Inventario crearInventarioDePrueba() {
        Inventario i = new Inventario();
        i.setId(1L);
        i.setProductoId(10L);
        i.setStock(20);
        i.setStockMinimo(5);
        return i;
    }

    @Test
    void testObtenerPorProducto() {
        when(inventarioRepository.findByProductoId(10L)).thenReturn(Optional.of(crearInventarioDePrueba()));

        InventarioDTO.Response respuesta = inventarioService.obtenerPorProducto(10L);

        assertNotNull(respuesta);
        assertEquals(20, respuesta.getStock());
        assertFalse(respuesta.getStockBajo());
    }

    @Test
    void testObtenerPorProducto_NoEncontrado() {
        when(inventarioRepository.findByProductoId(99L)).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> inventarioService.obtenerPorProducto(99L));
    }

    @Test
    void testRegistrarMovimiento_Entrada() {
        Inventario inventario = crearInventarioDePrueba();
        when(inventarioRepository.findByProductoId(10L)).thenReturn(Optional.of(inventario));
        when(inventarioRepository.save(any(Inventario.class))).thenReturn(inventario);

        InventarioDTO.MovimientoRequest request = new InventarioDTO.MovimientoRequest();
        request.setProductoId(10L);
        request.setTipo(TipoMovimiento.ENTRADA);
        request.setCantidad(10);

        InventarioDTO.Response resultado = inventarioService.registrarMovimiento(request);

        assertEquals(30, resultado.getStock());
        verify(movimientoRepository, times(1)).save(any());
    }

    @Test
    void testRegistrarMovimiento_SalidaConStockInsuficiente() {
        Inventario inventario = crearInventarioDePrueba(); // stock = 20
        when(inventarioRepository.findByProductoId(10L)).thenReturn(Optional.of(inventario));

        InventarioDTO.MovimientoRequest request = new InventarioDTO.MovimientoRequest();
        request.setProductoId(10L);
        request.setTipo(TipoMovimiento.SALIDA);
        request.setCantidad(50); // mayor al stock disponible

        assertThrows(StockInsuficienteException.class, () -> inventarioService.registrarMovimiento(request));
    }

    @Test
    void testListarStockBajo() {
        when(inventarioRepository.findStockBajo()).thenReturn(java.util.List.of(crearInventarioDePrueba()));

        var resultado = inventarioService.listarStockBajo();

        assertEquals(1, resultado.size());
    }

    @Test
    void testVerificarDisponibilidad_Disponible() {
        when(inventarioRepository.findByProductoId(10L)).thenReturn(Optional.of(crearInventarioDePrueba())); // stock = 20

        assertTrue(inventarioService.verificarDisponibilidad(10L, 5));
    }

    @Test
    void testVerificarDisponibilidad_NoDisponible() {
        when(inventarioRepository.findByProductoId(10L)).thenReturn(Optional.of(crearInventarioDePrueba())); // stock = 20

        assertFalse(inventarioService.verificarDisponibilidad(10L, 50));
    }

    @Test
    void testVerificarDisponibilidad_ProductoSinInventario() {
        when(inventarioRepository.findByProductoId(99L)).thenReturn(Optional.empty());

        assertFalse(inventarioService.verificarDisponibilidad(99L, 1));
    }

    @Test
    void testReservarStock() {
        Inventario inventario = crearInventarioDePrueba(); // stock = 20
        when(inventarioRepository.findByProductoId(10L)).thenReturn(Optional.of(inventario));
        when(inventarioRepository.save(any(Inventario.class))).thenReturn(inventario);

        InventarioDTO.Response resultado = inventarioService.reservarStock(10L, 5);

        assertEquals(15, resultado.getStock());
        verify(movimientoRepository, times(1)).save(any());
    }

    @Test
    void testLiberarReserva() {
        Inventario inventario = crearInventarioDePrueba(); // stock = 20
        when(inventarioRepository.findByProductoId(10L)).thenReturn(Optional.of(inventario));
        when(inventarioRepository.save(any(Inventario.class))).thenReturn(inventario);

        InventarioDTO.Response resultado = inventarioService.liberarReserva(10L, 5);

        assertEquals(25, resultado.getStock());
        verify(movimientoRepository, times(1)).save(any());
    }
}
