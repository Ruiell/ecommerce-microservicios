/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_notificaciones_dev
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_notificaciones_dev;

/* ============================================================
   2. Tabla notificaciones
   ============================================================ */
CREATE TABLE notificaciones (
    id                BIGINT       NOT NULL AUTO_INCREMENT,
    usuario_id        BIGINT       NOT NULL,
    tipo              VARCHAR(30)  NOT NULL,
    titulo            VARCHAR(200) NOT NULL,
    mensaje           TEXT         NOT NULL,
    referencia_id     BIGINT       NULL,
    leida             TINYINT(1)   NOT NULL DEFAULT 0,
    canal_envio       VARCHAR(10)  NOT NULL DEFAULT 'EMAIL',
    fecha_creacion    DATETIME     NOT NULL,
    fecha_lectura     DATETIME     NULL,
    CONSTRAINT notificaciones_PK PRIMARY KEY (id),
    CONSTRAINT chk_notificaciones_tipo CHECK (tipo IN
        ('PEDIDO_CONFIRMADO','PEDIDO_ENVIADO','PAGO_APROBADO','PAGO_RECHAZADO','STOCK_BAJO','GENERAL')),
    CONSTRAINT chk_notificaciones_canal CHECK (canal_envio IN ('EMAIL','SMS','PUSH'))
) ENGINE = InnoDB;

/* ============================================================
   ¡Todo listo!
   ============================================================ */
