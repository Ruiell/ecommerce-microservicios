package com.ecommerce.notificaciones.service;

import com.ecommerce.notificaciones.dto.NotificacionDTO;
import com.ecommerce.notificaciones.exception.RecursoNoEncontradoException;
import com.ecommerce.notificaciones.model.Notificacion;
import com.ecommerce.notificaciones.model.Notificacion.TipoNotificacion;
import com.ecommerce.notificaciones.repository.NotificacionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificacionServiceTest {

    @Mock
    private NotificacionRepository notificacionRepository;
    @Mock
    private WebClient.Builder webClientBuilder;

    private NotificacionService notificacionService;

    @BeforeEach
    void setUp() {
        notificacionService = new NotificacionService(notificacionRepository, webClientBuilder);
    }

    private Notificacion crearNotificacionDePrueba() {
        Notificacion n = new Notificacion();
        n.setId(1L);
        n.setUsuarioId(5L);
        n.setTipo(TipoNotificacion.PEDIDO_CONFIRMADO);
        n.setTitulo("Pedido confirmado");
        n.setMensaje("Tu pedido fue confirmado");
        n.setLeida(false);
        n.setCanal(Notificacion.CanalEnvio.EMAIL);
        return n;
    }

    @Test
    void testCrearNotificacion() {
        // webClientBuilder.build() devuelve null (mock simple, sin stubear la cadena):
        // el servicio captura cualquier excepcion de la validacion remota y continua igual.
        when(notificacionRepository.save(any(Notificacion.class))).thenReturn(crearNotificacionDePrueba());

        NotificacionDTO.Request request = new NotificacionDTO.Request();
        request.setUsuarioId(5L);
        request.setTipo(TipoNotificacion.PEDIDO_CONFIRMADO);
        request.setTitulo("Pedido confirmado");
        request.setMensaje("Tu pedido fue confirmado");

        NotificacionDTO.Response respuesta = notificacionService.crearNotificacion(request);

        assertNotNull(respuesta);
        assertEquals("Pedido confirmado", respuesta.getTitulo());
    }

    @Test
    void testListarPorUsuario() {
        when(notificacionRepository.findByUsuarioIdOrderByFechaCreacionDesc(5L))
                .thenReturn(List.of(crearNotificacionDePrueba()));

        List<NotificacionDTO.Response> resultado = notificacionService.listarPorUsuario(5L);

        assertEquals(1, resultado.size());
    }

    @Test
    void testMarcarComoLeida() {
        Notificacion notificacion = crearNotificacionDePrueba();
        when(notificacionRepository.findById(1L)).thenReturn(Optional.of(notificacion));
        when(notificacionRepository.save(any(Notificacion.class))).thenReturn(notificacion);

        NotificacionDTO.Response resultado = notificacionService.marcarComoLeida(1L);

        assertTrue(resultado.getLeida());
        assertNotNull(resultado.getFechaLectura());
    }

    @Test
    void testMarcarComoLeida_NoEncontrada() {
        when(notificacionRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> notificacionService.marcarComoLeida(99L));
    }

    @Test
    void testContarNoLeidas() {
        when(notificacionRepository.countNoLeidasByUsuarioId(5L)).thenReturn(3L);

        var resultado = notificacionService.contarNoLeidas(5L);

        assertEquals(3L, resultado.get("noLeidas"));
    }

    @Test
    void testExisteNotificacion() {
        when(notificacionRepository.existsById(1L)).thenReturn(true);

        assertTrue(notificacionService.existeNotificacion(1L));
    }

    @Test
    void testListarPorTipo() {
        when(notificacionRepository.findByTipo(TipoNotificacion.PEDIDO_CONFIRMADO))
                .thenReturn(List.of(crearNotificacionDePrueba()));

        List<NotificacionDTO.Response> resultado = notificacionService.listarPorTipo(TipoNotificacion.PEDIDO_CONFIRMADO);

        assertEquals(1, resultado.size());
    }

    @Test
    void testContarPorUsuario() {
        when(notificacionRepository.countByUsuarioId(5L)).thenReturn(8L);

        long total = notificacionService.contarPorUsuario(5L);

        assertEquals(8L, total);
    }
}
