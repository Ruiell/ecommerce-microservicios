package com.ecommerce.notificaciones.dto;
import com.ecommerce.notificaciones.model.Notificacion.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

public class NotificacionDTO {
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Request {
        @NotNull private Long usuarioId;
        @NotNull private TipoNotificacion tipo;
        @NotBlank @Size(max = 200) private String titulo;
        @NotBlank private String mensaje;
        private Long referenciaId;
        private CanalEnvio canal;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id; private Long usuarioId; private TipoNotificacion tipo;
        private String titulo; private String mensaje; private Long referenciaId;
        private Boolean leida; private CanalEnvio canal;
        private LocalDateTime fechaCreacion; private LocalDateTime fechaLectura;
    }
}
