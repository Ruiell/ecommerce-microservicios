package com.ecommerce.notificaciones.controller;

import com.ecommerce.notificaciones.assemblers.NotificacionModelAssembler;
import com.ecommerce.notificaciones.dto.NotificacionDTO;
import com.ecommerce.notificaciones.model.Notificacion;
import com.ecommerce.notificaciones.service.NotificacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de notificaciones.
 * Las respuestas incluyen enlaces de navegación (notificacionesDelUsuario, marcarLeida).
 * Para la versión sin HATEOAS usar /api/notificaciones (NotificacionController).
 */
@RestController
@RequestMapping("/api/v2/notificaciones")
@Tag(name = "Notificaciones (HATEOAS)", description = "Operaciones sobre notificaciones con enlaces HATEOAS")
public class NotificacionControllerV2 {

    @Autowired
    private NotificacionService notificacionService;

    @Autowired
    private NotificacionModelAssembler assembler;

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear una notificación (HATEOAS)")
    public ResponseEntity<EntityModel<NotificacionDTO.Response>> crear(@Valid @RequestBody NotificacionDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(notificacionService.crearNotificacion(request)));
    }

    @GetMapping(value = "/usuario/{usuarioId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar notificaciones de un usuario (HATEOAS)")
    public CollectionModel<EntityModel<NotificacionDTO.Response>> listarPorUsuario(@PathVariable Long usuarioId) {
        List<EntityModel<NotificacionDTO.Response>> notificaciones = notificacionService.listarPorUsuario(usuarioId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(notificaciones, linkTo(methodOn(NotificacionControllerV2.class).listarPorUsuario(usuarioId)).withSelfRel());
    }

    @GetMapping(value = "/usuario/{usuarioId}/no-leidas", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar notificaciones no leídas de un usuario (HATEOAS)")
    public CollectionModel<EntityModel<NotificacionDTO.Response>> listarNoLeidas(@PathVariable Long usuarioId) {
        List<EntityModel<NotificacionDTO.Response>> notificaciones = notificacionService.listarNoLeidas(usuarioId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(notificaciones, linkTo(methodOn(NotificacionControllerV2.class).listarNoLeidas(usuarioId)).withSelfRel());
    }

    @PatchMapping(value = "/{id}/leer", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Marcar una notificación como leída (HATEOAS)")
    public EntityModel<NotificacionDTO.Response> marcarLeida(@PathVariable Long id) {
        return assembler.toModel(notificacionService.marcarComoLeida(id));
    }

    // ===== Reportes con HATEOAS (ver NotificacionService) =====

    // 1. Obtener todas las notificaciones de un tipo específico
    @GetMapping(value = "/tipo/{tipo}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar notificaciones por tipo (HATEOAS)")
    public CollectionModel<EntityModel<NotificacionDTO.Response>> listarPorTipo(@PathVariable Notificacion.TipoNotificacion tipo) {
        List<EntityModel<NotificacionDTO.Response>> notificaciones = notificacionService.listarPorTipo(tipo).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(notificaciones, linkTo(methodOn(NotificacionControllerV2.class).listarPorTipo(tipo)).withSelfRel());
    }

    // 2. Obtener todas las notificaciones enviadas por un canal específico
    @GetMapping(value = "/canal/{canal}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar notificaciones por canal de envío (HATEOAS)")
    public CollectionModel<EntityModel<NotificacionDTO.Response>> listarPorCanal(@PathVariable Notificacion.CanalEnvio canal) {
        List<EntityModel<NotificacionDTO.Response>> notificaciones = notificacionService.listarPorCanal(canal).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(notificaciones, linkTo(methodOn(NotificacionControllerV2.class).listarPorCanal(canal)).withSelfRel());
    }

    // 3. Obtener el total de notificaciones de un usuario
    @GetMapping(value = "/usuario/{usuarioId}/total", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el total de notificaciones de un usuario (HATEOAS)")
    public EntityModel<Map<String, Object>> contarPorUsuario(@PathVariable Long usuarioId) {
        long total = notificacionService.contarPorUsuario(usuarioId);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("usuarioId", usuarioId);
        body.put("totalNotificaciones", total);

        return EntityModel.of(body,
                linkTo(methodOn(NotificacionControllerV2.class).contarPorUsuario(usuarioId)).withSelfRel(),
                linkTo(methodOn(NotificacionControllerV2.class).listarPorUsuario(usuarioId)).withRel("notificacionesDelUsuario"));
    }
}
