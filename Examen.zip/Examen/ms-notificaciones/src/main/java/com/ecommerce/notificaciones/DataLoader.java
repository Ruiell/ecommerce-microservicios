package com.ecommerce.notificaciones;

import com.ecommerce.notificaciones.model.Notificacion;
import com.ecommerce.notificaciones.model.Notificacion.CanalEnvio;
import com.ecommerce.notificaciones.model.Notificacion.TipoNotificacion;
import com.ecommerce.notificaciones.repository.NotificacionRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Random;

@Profile({"dev", "render", "aiven"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private NotificacionRepository notificacionRepository;

    @Override
    public void run(String... args) throws Exception {
        if (notificacionRepository.count() > 0) {
            return;
        }

        Faker faker = new Faker();
        Random random = new Random();
        TipoNotificacion[] tipos = TipoNotificacion.values();
        CanalEnvio[] canales = CanalEnvio.values();

        for (long usuarioId = 1; usuarioId <= 20; usuarioId++) {
            int cantidad = faker.number().numberBetween(1, 4);
            for (int i = 0; i < cantidad; i++) {
                Notificacion notificacion = new Notificacion();
                notificacion.setUsuarioId(usuarioId);

                TipoNotificacion tipo = tipos[random.nextInt(tipos.length)];
                notificacion.setTipo(tipo);
                notificacion.setTitulo(faker.lorem().sentence(4));
                notificacion.setMensaje(faker.lorem().sentence(20));
                notificacion.setReferenciaId((long) faker.number().numberBetween(1, 50));
                notificacion.setLeida(random.nextInt(10) < 5);
                notificacion.setCanal(canales[random.nextInt(canales.length)]);

                if (notificacion.getLeida()) {
                    notificacion.setFechaLectura(LocalDateTime.now().minusHours(faker.number().numberBetween(1, 72)));
                }

                notificacionRepository.save(notificacion);
            }
        }

        System.out.println(">> DataLoader: notificaciones de prueba cargadas en ms-notificaciones (perfil dev).");
    }
}
