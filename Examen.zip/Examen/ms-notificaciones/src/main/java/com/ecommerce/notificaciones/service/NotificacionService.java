package com.ecommerce.notificaciones.service;

import com.ecommerce.notificaciones.dto.NotificacionDTO;
import com.ecommerce.notificaciones.exception.RecursoNoEncontradoException;
import com.ecommerce.notificaciones.model.Notificacion;
import com.ecommerce.notificaciones.repository.NotificacionRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Servicio de Notificaciones
 * Usa WebClient para obtener datos del usuario desde ms-usuarios
 */
@Service @RequiredArgsConstructor
public class NotificacionService {

    private static final Logger log = LoggerFactory.getLogger(NotificacionService.class);
    private final NotificacionRepository notificacionRepository;
    private final WebClient.Builder webClientBuilder;

    @Value("${microservices.usuarios.url}")
    private String usuariosUrl;

    @Transactional
    public NotificacionDTO.Response crearNotificacion(NotificacionDTO.Request request) {
        log.info("Creando notificación tipo={} para usuarioId={}", request.getTipo(), request.getUsuarioId());

        // Verificar usuario via WebClient
        try {
            Boolean existe = webClientBuilder.build()
                .get().uri(usuariosUrl + "/api/usuarios/{id}/existe", request.getUsuarioId())
                .retrieve().bodyToMono(Map.class)
                .map(m -> (Boolean) m.get("existe"))
                .block(java.time.Duration.ofSeconds(5));
            if (Boolean.FALSE.equals(existe)) {
                throw new RecursoNoEncontradoException("Usuario no encontrado: " + request.getUsuarioId());
            }
        } catch (RecursoNoEncontradoException e) {
            throw e;
        } catch (Exception e) {
            log.warn("ms-usuarios no disponible, continuando: {}", e.getMessage());
        }

        Notificacion notificacion = new Notificacion();
        notificacion.setUsuarioId(request.getUsuarioId());
        notificacion.setTipo(request.getTipo());
        notificacion.setTitulo(request.getTitulo());
        notificacion.setMensaje(request.getMensaje());
        notificacion.setReferenciaId(request.getReferenciaId());
        notificacion.setCanal(request.getCanal() != null ? request.getCanal() : Notificacion.CanalEnvio.EMAIL);
        notificacion.setLeida(false);

        Notificacion guardada = notificacionRepository.save(notificacion);
        log.info("Notificación creada ID={} - simulando envío por {}", guardada.getId(), guardada.getCanal());
        return mapear(guardada);
    }

    @Transactional(readOnly = true)
    public List<NotificacionDTO.Response> listarPorUsuario(Long usuarioId) {
        log.info("Listando notificaciones del usuario: {}", usuarioId);
        return notificacionRepository.findByUsuarioIdOrderByFechaCreacionDesc(usuarioId)
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<NotificacionDTO.Response> listarNoLeidas(Long usuarioId) {
        log.info("Listando notificaciones no leídas del usuario: {}", usuarioId);
        return notificacionRepository.findByUsuarioIdAndLeidaFalseOrderByFechaCreacionDesc(usuarioId)
                .stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional
    public NotificacionDTO.Response marcarComoLeida(Long id) {
        log.info("Marcando notificación {} como leída", id);
        Notificacion notificacion = notificacionRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Notificación no encontrada: " + id));
        notificacion.setLeida(true);
        notificacion.setFechaLectura(LocalDateTime.now());
        log.info("Notificación {} marcada como leída", id);
        return mapear(notificacionRepository.save(notificacion));
    }

    @Transactional
    public Map<String, Long> contarNoLeidas(Long usuarioId) {
        Long count = notificacionRepository.countNoLeidasByUsuarioId(usuarioId);
        log.debug("Notificaciones no leídas para usuario {}: {}", usuarioId, count);
        return Map.of("noLeidas", count);
    }

    @Transactional
    public void marcarTodasComoLeidas(Long usuarioId) {
        log.info("Marcando todas las notificaciones como leídas para usuario: {}", usuarioId);
        List<Notificacion> pendientes = notificacionRepository
                .findByUsuarioIdAndLeidaFalseOrderByFechaCreacionDesc(usuarioId);
        pendientes.forEach(n -> { n.setLeida(true); n.setFechaLectura(LocalDateTime.now()); });
        notificacionRepository.saveAll(pendientes);
        log.info("Se marcaron {} notificaciones como leídas", pendientes.size());
    }

    private NotificacionDTO.Response mapear(Notificacion n) {
        NotificacionDTO.Response r = new NotificacionDTO.Response();
        r.setId(n.getId()); r.setUsuarioId(n.getUsuarioId()); r.setTipo(n.getTipo());
        r.setTitulo(n.getTitulo()); r.setMensaje(n.getMensaje()); r.setReferenciaId(n.getReferenciaId());
        r.setLeida(n.getLeida()); r.setCanal(n.getCanal());
        r.setFechaCreacion(n.getFechaCreacion()); r.setFechaLectura(n.getFechaLectura());
        return r;
    }

    /**
     * Verifica si una notificación existe (usado por otros microservicios, mismo patrón
     * que ProductoService.existeProducto / UsuarioService.existeUsuario)
     */
    public boolean existeNotificacion(Long id) {
        return notificacionRepository.existsById(id);
    }

    // ===== Reportes con HATEOAS (mismo patrón que PagoService/PedidoService) =====

    // 1. Obtener todas las notificaciones de un tipo específico
    @Transactional(readOnly = true)
    public List<NotificacionDTO.Response> listarPorTipo(Notificacion.TipoNotificacion tipo) {
        return notificacionRepository.findByTipo(tipo).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 2. Obtener todas las notificaciones enviadas por un canal específico
    @Transactional(readOnly = true)
    public List<NotificacionDTO.Response> listarPorCanal(Notificacion.CanalEnvio canal) {
        return notificacionRepository.findByCanal(canal).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 3. Obtener el total de notificaciones (leídas y no leídas) de un usuario
    @Transactional(readOnly = true)
    public long contarPorUsuario(Long usuarioId) {
        return notificacionRepository.countByUsuarioId(usuarioId);
    }
}
