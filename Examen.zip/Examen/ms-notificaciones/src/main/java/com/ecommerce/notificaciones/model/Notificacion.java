package com.ecommerce.notificaciones.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name = "notificaciones") @Data @NoArgsConstructor @AllArgsConstructor
public class Notificacion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "usuario_id", nullable = false) private Long usuarioId;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private TipoNotificacion tipo;
    @Column(nullable = false, length = 200) private String titulo;
    @Column(nullable = false, columnDefinition = "TEXT") private String mensaje;
    @Column(name = "referencia_id") private Long referenciaId;
    @Column(name = "leida") private Boolean leida = false;
    @Column(name = "canal_envio") @Enumerated(EnumType.STRING) private CanalEnvio canal = CanalEnvio.EMAIL;
    @Column(name = "fecha_creacion", updatable = false) private LocalDateTime fechaCreacion;
    @Column(name = "fecha_lectura") private LocalDateTime fechaLectura;
    @PrePersist protected void onCreate() { fechaCreacion = LocalDateTime.now(); }

    public enum TipoNotificacion { PEDIDO_CONFIRMADO, PEDIDO_ENVIADO, PAGO_APROBADO, PAGO_RECHAZADO, STOCK_BAJO, GENERAL }
    public enum CanalEnvio { EMAIL, SMS, PUSH }
}
