package com.ecommerce.notificaciones.exception;
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String m) { super(m); }
}
