package com.ecommerce.notificaciones.repository;
import com.ecommerce.notificaciones.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {
    List<Notificacion> findByUsuarioIdOrderByFechaCreacionDesc(Long usuarioId);
    List<Notificacion> findByUsuarioIdAndLeidaFalseOrderByFechaCreacionDesc(Long usuarioId);
    @Query("SELECT COUNT(n) FROM Notificacion n WHERE n.usuarioId = :usuarioId AND n.leida = false")
    Long countNoLeidasByUsuarioId(Long usuarioId);

    // Métodos personalizados para los reportes con HATEOAS (NotificacionControllerV2)
    List<Notificacion> findByTipo(Notificacion.TipoNotificacion tipo);
    List<Notificacion> findByCanal(Notificacion.CanalEnvio canal);
    long countByUsuarioId(Long usuarioId);
}
