package com.ecommerce.notificaciones.controller;

import com.ecommerce.notificaciones.dto.NotificacionDTO;
import com.ecommerce.notificaciones.service.NotificacionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/notificaciones") @RequiredArgsConstructor
public class NotificacionController {

    private static final Logger log = LoggerFactory.getLogger(NotificacionController.class);
    private final NotificacionService notificacionService;

    @PostMapping
    public ResponseEntity<NotificacionDTO.Response> crear(@Valid @RequestBody NotificacionDTO.Request request) {
        log.info("POST /api/notificaciones - usuarioId: {}", request.getUsuarioId());
        return ResponseEntity.status(HttpStatus.CREATED).body(notificacionService.crearNotificacion(request));
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<NotificacionDTO.Response>> listarPorUsuario(@PathVariable Long usuarioId) {
        log.info("GET /api/notificaciones/usuario/{}", usuarioId);
        return ResponseEntity.ok(notificacionService.listarPorUsuario(usuarioId));
    }

    @GetMapping("/usuario/{usuarioId}/no-leidas")
    public ResponseEntity<List<NotificacionDTO.Response>> listarNoLeidas(@PathVariable Long usuarioId) {
        log.info("GET /api/notificaciones/usuario/{}/no-leidas", usuarioId);
        return ResponseEntity.ok(notificacionService.listarNoLeidas(usuarioId));
    }

    @GetMapping("/usuario/{usuarioId}/contador")
    public ResponseEntity<Map<String, Long>> contarNoLeidas(@PathVariable Long usuarioId) {
        log.info("GET /api/notificaciones/usuario/{}/contador", usuarioId);
        return ResponseEntity.ok(notificacionService.contarNoLeidas(usuarioId));
    }

    @PatchMapping("/{id}/leer")
    public ResponseEntity<NotificacionDTO.Response> marcarLeida(@PathVariable Long id) {
        log.info("PATCH /api/notificaciones/{}/leer", id);
        return ResponseEntity.ok(notificacionService.marcarComoLeida(id));
    }

    @PatchMapping("/usuario/{usuarioId}/leer-todas")
    public ResponseEntity<Map<String,String>> marcarTodasLeidas(@PathVariable Long usuarioId) {
        log.info("PATCH /api/notificaciones/usuario/{}/leer-todas", usuarioId);
        notificacionService.marcarTodasComoLeidas(usuarioId);
        return ResponseEntity.ok(Map.of("mensaje", "Todas las notificaciones marcadas como leídas"));
    }

    @GetMapping("/{id}/existe")
    public ResponseEntity<Map<String,Boolean>> existe(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("existe", notificacionService.existeNotificacion(id)));
    }
}
