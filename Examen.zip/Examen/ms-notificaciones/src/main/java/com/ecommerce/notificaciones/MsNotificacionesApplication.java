package com.ecommerce.notificaciones;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
/**
 * Microservicio de Notificaciones - Puerto: 8090
 * Responsabilidad: Registro y consulta de notificaciones del sistema
 * Comunicación: WebClient → ms-usuarios para obtener email
 */
@SpringBootApplication @EnableFeignClients
public class MsNotificacionesApplication {
    public static void main(String[] args) { SpringApplication.run(MsNotificacionesApplication.class, args); }
}
