package com.ecommerce.notificaciones.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.notificaciones.controller.NotificacionControllerV2;
import com.ecommerce.notificaciones.dto.NotificacionDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class NotificacionModelAssembler implements RepresentationModelAssembler<NotificacionDTO.Response, EntityModel<NotificacionDTO.Response>> {

    @Override
    public EntityModel<NotificacionDTO.Response> toModel(NotificacionDTO.Response notificacion) {
        return EntityModel.of(notificacion,
                linkTo(methodOn(NotificacionControllerV2.class).listarPorUsuario(notificacion.getUsuarioId())).withRel("notificacionesDelUsuario"),
                linkTo(methodOn(NotificacionControllerV2.class).marcarLeida(notificacion.getId())).withRel("marcarLeida"));
    }
}
