package com.ecommerce.categorias.service;

import com.ecommerce.categorias.dto.CategoriaDTO;
import com.ecommerce.categorias.exception.RecursoNoEncontradoException;
import com.ecommerce.categorias.model.Categoria;
import com.ecommerce.categorias.repository.CategoriaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CategoriaServiceTest {

    @Mock
    private CategoriaRepository categoriaRepository;

    @InjectMocks
    private CategoriaService categoriaService;

    private Categoria crearCategoriaDePrueba() {
        Categoria c = new Categoria();
        c.setId(1L);
        c.setNombre("Peluches");
        c.setDescripcion("Peluches y muñecos de felpa");
        c.setActiva(true);
        return c;
    }

    @Test
    void testCrearCategoria() {
        CategoriaDTO.Request request = new CategoriaDTO.Request();
        request.setNombre("Peluches");
        request.setDescripcion("Peluches y muñecos de felpa");

        when(categoriaRepository.save(any(Categoria.class))).thenReturn(crearCategoriaDePrueba());

        CategoriaDTO.Response creada = categoriaService.crearCategoria(request);

        assertNotNull(creada);
        assertEquals("Peluches", creada.getNombre());
        verify(categoriaRepository, times(1)).save(any(Categoria.class));
    }

    @Test
    void testCrearCategoria_ConPadreInexistente() {
        CategoriaDTO.Request request = new CategoriaDTO.Request();
        request.setNombre("Sub");
        request.setCategoriaPadreId(99L);

        when(categoriaRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> categoriaService.crearCategoria(request));
    }

    @Test
    void testListarCategorias() {
        when(categoriaRepository.findByActivaTrue()).thenReturn(List.of(crearCategoriaDePrueba()));

        List<CategoriaDTO.Response> categorias = categoriaService.listarCategorias();

        assertEquals(1, categorias.size());
        assertEquals("Peluches", categorias.get(0).getNombre());
    }

    @Test
    void testObtenerPorId() {
        when(categoriaRepository.findById(1L)).thenReturn(Optional.of(crearCategoriaDePrueba()));

        CategoriaDTO.Response encontrada = categoriaService.obtenerPorId(1L);

        assertNotNull(encontrada);
        assertEquals(1L, encontrada.getId());
    }

    @Test
    void testObtenerPorId_NoEncontrada() {
        when(categoriaRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> categoriaService.obtenerPorId(99L));
    }

    @Test
    void testEliminar() {
        Categoria categoria = crearCategoriaDePrueba();
        when(categoriaRepository.findById(1L)).thenReturn(Optional.of(categoria));
        when(categoriaRepository.save(any(Categoria.class))).thenReturn(categoria);

        categoriaService.eliminar(1L);

        assertFalse(categoria.getActiva());
        verify(categoriaRepository, times(1)).save(categoria);
    }

    @Test
    void testExiste() {
        when(categoriaRepository.existsById(1L)).thenReturn(true);

        assertTrue(categoriaService.existe(1L));
    }

    @Test
    void testListarRaiz() {
        when(categoriaRepository.findByCategoriaPadreIsNull()).thenReturn(List.of(crearCategoriaDePrueba()));

        List<CategoriaDTO.Response> raiz = categoriaService.listarRaiz();

        assertEquals(1, raiz.size());
    }

    @Test
    void testListarSubcategorias() {
        when(categoriaRepository.findByCategoriaPadreId(1L)).thenReturn(List.of(crearCategoriaDePrueba()));

        List<CategoriaDTO.Response> subcategorias = categoriaService.listarSubcategorias(1L);

        assertEquals(1, subcategorias.size());
    }

    @Test
    void testContarSubcategorias() {
        when(categoriaRepository.countByCategoriaPadreId(1L)).thenReturn(3L);

        long total = categoriaService.contarSubcategorias(1L);

        assertEquals(3L, total);
    }
}
