package com.ecommerce.categorias.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.categorias.controller.CategoriaControllerV2;
import com.ecommerce.categorias.dto.CategoriaDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class CategoriaModelAssembler implements RepresentationModelAssembler<CategoriaDTO.Response, EntityModel<CategoriaDTO.Response>> {

    @Override
    public EntityModel<CategoriaDTO.Response> toModel(CategoriaDTO.Response categoria) {
        EntityModel<CategoriaDTO.Response> model = EntityModel.of(categoria,
                linkTo(methodOn(CategoriaControllerV2.class).obtener(categoria.getId())).withSelfRel(),
                linkTo(methodOn(CategoriaControllerV2.class).listarSubcategorias(categoria.getId())).withRel("subcategorias"));
        if (categoria.getCategoriaPadreId() != null) {
            model.add(linkTo(methodOn(CategoriaControllerV2.class).obtener(categoria.getCategoriaPadreId())).withRel("categoriaPadre"));
        }
        return model;
    }
}
