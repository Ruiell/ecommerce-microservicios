package com.ecommerce.categorias.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.*;

@ControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(RecursoNoEncontradoException.class)
    public ResponseEntity<Map<String,Object>> handleNotFound(RecursoNoEncontradoException ex) {
        log.error("No encontrado: {}", ex.getMessage());
        return ResponseEntity.status(404).body(build(404, ex.getMessage(), "NOT_FOUND"));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String,Object>> handleValidation(MethodArgumentNotValidException ex) {
        Map<String,String> errores = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(e -> errores.put(((FieldError)e).getField(), e.getDefaultMessage()));
        Map<String,Object> r = build(400, "Error de validación", "VALIDATION_ERROR");
        r.put("errores", errores);
        return ResponseEntity.badRequest().body(r);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String,Object>> handleGeneric(Exception ex) {
        log.error("Error interno: {}", ex.getMessage(), ex);
        return ResponseEntity.status(500).body(build(500, "Error interno del servidor", "INTERNAL_ERROR"));
    }

    private Map<String,Object> build(int status, String msg, String tipo) {
        Map<String,Object> r = new HashMap<>();
        r.put("timestamp", LocalDateTime.now().toString());
        r.put("status", status); r.put("tipo", tipo); r.put("mensaje", msg);
        return r;
    }
}
