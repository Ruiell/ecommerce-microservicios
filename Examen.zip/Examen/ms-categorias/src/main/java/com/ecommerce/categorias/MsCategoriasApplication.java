package com.ecommerce.categorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Microservicio de Categorías
 * Puerto: 8083
 * Responsabilidad: Gestión del árbol de categorías del catálogo
 */
@SpringBootApplication
public class MsCategoriasApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsCategoriasApplication.class, args);
    }
}
