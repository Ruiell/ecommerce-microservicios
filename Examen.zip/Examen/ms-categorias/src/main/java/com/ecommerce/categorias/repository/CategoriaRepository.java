package com.ecommerce.categorias.repository;

import com.ecommerce.categorias.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
    List<Categoria> findByActivaTrue();
    List<Categoria> findByCategoriaPadreIsNull();
    boolean existsByNombre(String nombre);

    // Métodos personalizados para los reportes con HATEOAS (CategoriaControllerV2)
    List<Categoria> findByCategoriaPadreId(Long categoriaPadreId);
    long countByCategoriaPadreId(Long categoriaPadreId);
}
