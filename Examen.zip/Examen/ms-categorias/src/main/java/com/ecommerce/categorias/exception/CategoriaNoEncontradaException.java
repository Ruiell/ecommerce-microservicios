package com.ecommerce.categorias.exception;
public class CategoriaNoEncontradaException extends RuntimeException {
    public CategoriaNoEncontradaException(String msg) { super(msg); }
}
