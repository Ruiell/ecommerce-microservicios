package com.ecommerce.categorias.service;

import com.ecommerce.categorias.dto.CategoriaDTO;
import com.ecommerce.categorias.exception.RecursoNoEncontradoException;
import com.ecommerce.categorias.model.Categoria;
import com.ecommerce.categorias.repository.CategoriaRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CategoriaService {

    private static final Logger log = LoggerFactory.getLogger(CategoriaService.class);
    private final CategoriaRepository categoriaRepository;

    @Transactional
    public CategoriaDTO.Response crearCategoria(CategoriaDTO.Request request) {
        log.info("Creando categoría: {}", request.getNombre());
        Categoria categoria = new Categoria();
        categoria.setNombre(request.getNombre());
        categoria.setDescripcion(request.getDescripcion());
        categoria.setImagenUrl(request.getImagenUrl());
        categoria.setActiva(true);

        if (request.getCategoriaPadreId() != null) {
            Categoria padre = categoriaRepository.findById(request.getCategoriaPadreId())
                    .orElseThrow(() -> new RecursoNoEncontradoException("Categoría padre no encontrada: " + request.getCategoriaPadreId()));
            categoria.setCategoriaPadre(padre);
        }

        Categoria guardada = categoriaRepository.save(categoria);
        log.info("Categoría creada con ID: {}", guardada.getId());
        return mapear(guardada);
    }

    @Transactional(readOnly = true)
    public List<CategoriaDTO.Response> listarCategorias() {
        log.info("Listando categorías activas");
        return categoriaRepository.findByActivaTrue().stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public CategoriaDTO.Response obtenerPorId(Long id) {
        log.info("Buscando categoría ID: {}", id);
        return mapear(categoriaRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Categoría no encontrada: " + id)));
    }

    @Transactional
    public CategoriaDTO.Response actualizar(Long id, CategoriaDTO.Request request) {
        log.info("Actualizando categoría ID: {}", id);
        Categoria categoria = categoriaRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Categoría no encontrada: " + id));
        if (request.getNombre() != null) categoria.setNombre(request.getNombre());
        if (request.getDescripcion() != null) categoria.setDescripcion(request.getDescripcion());
        if (request.getImagenUrl() != null) categoria.setImagenUrl(request.getImagenUrl());
        log.info("Categoría actualizada: {}", id);
        return mapear(categoriaRepository.save(categoria));
    }

    @Transactional
    public void eliminar(Long id) {
        log.info("Desactivando categoría ID: {}", id);
        Categoria categoria = categoriaRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Categoría no encontrada: " + id));
        categoria.setActiva(false);
        categoriaRepository.save(categoria);
    }

    public boolean existe(Long id) {
        return categoriaRepository.existsById(id);
    }

    // ===== Reportes con HATEOAS (mismo patrón que PagoService/PedidoService) =====

    // 1. Obtener todas las categorías raíz (sin padre)
    @Transactional(readOnly = true)
    public List<CategoriaDTO.Response> listarRaiz() {
        return categoriaRepository.findByCategoriaPadreIsNull().stream().map(this::mapear).collect(Collectors.toList());
    }

    // 2. Obtener las subcategorías directas de una categoría
    @Transactional(readOnly = true)
    public List<CategoriaDTO.Response> listarSubcategorias(Long categoriaPadreId) {
        return categoriaRepository.findByCategoriaPadreId(categoriaPadreId).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 3. Obtener el total de subcategorías directas de una categoría
    @Transactional(readOnly = true)
    public long contarSubcategorias(Long categoriaPadreId) {
        return categoriaRepository.countByCategoriaPadreId(categoriaPadreId);
    }

    private CategoriaDTO.Response mapear(Categoria c) {
        CategoriaDTO.Response r = new CategoriaDTO.Response();
        r.setId(c.getId());
        r.setNombre(c.getNombre());
        r.setDescripcion(c.getDescripcion());
        r.setImagenUrl(c.getImagenUrl());
        r.setActiva(c.getActiva());
        if (c.getCategoriaPadre() != null) {
            r.setCategoriaPadreId(c.getCategoriaPadre().getId());
            r.setNombrePadre(c.getCategoriaPadre().getNombre());
        }
        return r;
    }
}
