package com.ecommerce.categorias.controller;

import com.ecommerce.categorias.assemblers.CategoriaModelAssembler;
import com.ecommerce.categorias.dto.CategoriaDTO;
import com.ecommerce.categorias.service.CategoriaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de categorías.
 * Las respuestas incluyen enlaces de navegación (self, subcategorias, categoriaPadre).
 * Para la versión sin HATEOAS usar /api/categorias (CategoriaController).
 */
@RestController
@RequestMapping("/api/v2/categorias")
@Tag(name = "Categorías (HATEOAS)", description = "Operaciones sobre categorías con enlaces HATEOAS")
public class CategoriaControllerV2 {

    @Autowired
    private CategoriaService categoriaService;

    @Autowired
    private CategoriaModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar categorías activas (HATEOAS)")
    public CollectionModel<EntityModel<CategoriaDTO.Response>> listar() {
        List<EntityModel<CategoriaDTO.Response>> categorias = categoriaService.listarCategorias().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(categorias, linkTo(methodOn(CategoriaControllerV2.class).listar()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener una categoría por id (HATEOAS)")
    public EntityModel<CategoriaDTO.Response> obtener(@PathVariable Long id) {
        return assembler.toModel(categoriaService.obtenerPorId(id));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear una categoría (HATEOAS)")
    public ResponseEntity<EntityModel<CategoriaDTO.Response>> crear(@Valid @RequestBody CategoriaDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(categoriaService.crearCategoria(request)));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar una categoría (HATEOAS)")
    public EntityModel<CategoriaDTO.Response> actualizar(@PathVariable Long id, @Valid @RequestBody CategoriaDTO.Request request) {
        return assembler.toModel(categoriaService.actualizar(id, request));
    }

    // ===== Reportes con HATEOAS (ver CategoriaService) =====

    // 1. Obtener todas las categorías raíz (sin padre)
    @GetMapping(value = "/raiz", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar categorías raíz, sin categoría padre (HATEOAS)")
    public CollectionModel<EntityModel<CategoriaDTO.Response>> listarRaiz() {
        List<EntityModel<CategoriaDTO.Response>> categorias = categoriaService.listarRaiz().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(categorias, linkTo(methodOn(CategoriaControllerV2.class).listarRaiz()).withSelfRel());
    }

    // 2. Obtener las subcategorías directas de una categoría
    @GetMapping(value = "/{id}/subcategorias", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar las subcategorías directas de una categoría (HATEOAS)")
    public CollectionModel<EntityModel<CategoriaDTO.Response>> listarSubcategorias(@PathVariable Long id) {
        List<EntityModel<CategoriaDTO.Response>> categorias = categoriaService.listarSubcategorias(id).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(categorias,
                linkTo(methodOn(CategoriaControllerV2.class).listarSubcategorias(id)).withSelfRel(),
                linkTo(methodOn(CategoriaControllerV2.class).obtener(id)).withRel("categoriaPadre"));
    }

    // 3. Obtener el total de subcategorías directas de una categoría
    @GetMapping(value = "/{id}/subcategorias/total", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el total de subcategorías directas de una categoría (HATEOAS)")
    public EntityModel<Map<String, Object>> contarSubcategorias(@PathVariable Long id) {
        long total = categoriaService.contarSubcategorias(id);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("categoriaPadreId", id);
        body.put("totalSubcategorias", total);

        return EntityModel.of(body,
                linkTo(methodOn(CategoriaControllerV2.class).contarSubcategorias(id)).withSelfRel(),
                linkTo(methodOn(CategoriaControllerV2.class).listarSubcategorias(id)).withRel("subcategorias"));
    }
}
