package com.ecommerce.categorias.exception;
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String m) { super(m); }
}
