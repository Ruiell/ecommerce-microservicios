package com.ecommerce.categorias.controller;

import com.ecommerce.categorias.dto.CategoriaDTO;
import com.ecommerce.categorias.service.CategoriaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/categorias")
@RequiredArgsConstructor
public class CategoriaController {

    private static final Logger log = LoggerFactory.getLogger(CategoriaController.class);
    private final CategoriaService categoriaService;

    @GetMapping
    public ResponseEntity<List<CategoriaDTO.Response>> listar() {
        log.info("GET /api/categorias");
        return ResponseEntity.ok(categoriaService.listarCategorias());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CategoriaDTO.Response> obtener(@PathVariable Long id) {
        log.info("GET /api/categorias/{}", id);
        return ResponseEntity.ok(categoriaService.obtenerPorId(id));
    }

    @PostMapping
    public ResponseEntity<CategoriaDTO.Response> crear(@Valid @RequestBody CategoriaDTO.Request request) {
        log.info("POST /api/categorias - nombre: {}", request.getNombre());
        return ResponseEntity.status(HttpStatus.CREATED).body(categoriaService.crearCategoria(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CategoriaDTO.Response> actualizar(@PathVariable Long id, @Valid @RequestBody CategoriaDTO.Request request) {
        log.info("PUT /api/categorias/{}", id);
        return ResponseEntity.ok(categoriaService.actualizar(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String,String>> eliminar(@PathVariable Long id) {
        log.info("DELETE /api/categorias/{}", id);
        categoriaService.eliminar(id);
        return ResponseEntity.ok(Map.of("mensaje", "Categoría desactivada exitosamente"));
    }

    @GetMapping("/{id}/existe")
    public ResponseEntity<Map<String,Boolean>> existe(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("existe", categoriaService.existe(id)));
    }
}
