package com.ecommerce.categorias.dto;

import jakarta.validation.constraints.*;
import lombok.*;

public class CategoriaDTO {

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Request {
        @NotBlank(message = "El nombre es obligatorio")
        @Size(min = 2, max = 100)
        private String nombre;
        private String descripcion;
        private String imagenUrl;
        private Long categoriaPadreId;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id;
        private String nombre;
        private String descripcion;
        private String imagenUrl;
        private Boolean activa;
        private Long categoriaPadreId;
        private String nombrePadre;
    }
}
