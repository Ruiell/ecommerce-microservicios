package com.ecommerce.categorias;

import com.ecommerce.categorias.model.Categoria;
import com.ecommerce.categorias.repository.CategoriaRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Profile({"dev", "render", "aiven"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Override
    public void run(String... args) throws Exception {
        if (categoriaRepository.count() > 0) {
            return;
        }

        Faker faker = new Faker();
        Random random = new Random();
        List<Categoria> padres = new ArrayList<>();

        for (int i = 0; i < 6; i++) {
            Categoria categoria = new Categoria();
            categoria.setNombre(faker.commerce().department());
            categoria.setDescripcion(faker.lorem().sentence(10));
            categoria.setImagenUrl("https://picsum.photos/seed/" + faker.number().digits(6) + "/400/400");
            categoria.setActiva(true);
            categoriaRepository.save(categoria);
            padres.add(categoria);
        }

        for (int i = 0; i < 12; i++) {
            Categoria categoria = new Categoria();
            categoria.setNombre(faker.commerce().productName());
            categoria.setDescripcion(faker.lorem().sentence(8));
            categoria.setImagenUrl("https://picsum.photos/seed/" + faker.number().digits(6) + "/400/400");
            categoria.setActiva(random.nextInt(10) < 9);
            categoria.setCategoriaPadre(padres.get(random.nextInt(padres.size())));
            categoriaRepository.save(categoria);
        }

        System.out.println(">> DataLoader: 18 categorias de prueba cargadas en ms-categorias (perfil dev).");
    }
}
