/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_categorias
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_categorias;

/* ============================================================
   2. Tabla categorias (árbol jerárquico self-referencing)
   ============================================================ */
CREATE TABLE categorias (
    id                   BIGINT       NOT NULL AUTO_INCREMENT,
    nombre               VARCHAR(100) NOT NULL,
    descripcion          VARCHAR(255) NULL,
    imagen_url           VARCHAR(255) NULL,
    activa               TINYINT(1)   NOT NULL DEFAULT 1,
    categoria_padre_id   BIGINT       NULL,
    CONSTRAINT categorias_PK PRIMARY KEY (id),
    CONSTRAINT categorias_padre_FK FOREIGN KEY (categoria_padre_id)
        REFERENCES categorias (id) ON DELETE SET NULL
) ENGINE = InnoDB;

/* ============================================================
   ¡Todo listo!
   ============================================================ */
