package com.ecommerce.carrito.controller;

import com.ecommerce.carrito.assemblers.CarritoModelAssembler;
import com.ecommerce.carrito.dto.CarritoDTO;
import com.ecommerce.carrito.model.Carrito;
import com.ecommerce.carrito.service.CarritoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de carrito.
 * Las respuestas incluyen enlaces de navegación (self, vaciarCarrito).
 * Para la versión sin HATEOAS usar /api/carrito (CarritoController).
 */
@RestController
@RequestMapping("/api/v2/carrito")
@Tag(name = "Carrito (HATEOAS)", description = "Operaciones sobre el carrito de compras con enlaces HATEOAS")
public class CarritoControllerV2 {

    @Autowired
    private CarritoService carritoService;

    @Autowired
    private CarritoModelAssembler assembler;

    @GetMapping(value = "/usuario/{usuarioId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener (o crear) el carrito activo de un usuario (HATEOAS)")
    public EntityModel<CarritoDTO.Response> obtenerCarrito(@PathVariable Long usuarioId) {
        return assembler.toModel(carritoService.obtenerOCrearCarrito(usuarioId));
    }

    @PostMapping(value = "/usuario/{usuarioId}/items", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Agregar un item al carrito (HATEOAS)")
    public ResponseEntity<EntityModel<CarritoDTO.Response>> agregarItem(@PathVariable Long usuarioId,
            @Valid @RequestBody CarritoDTO.AgregarItemRequest request) {
        CarritoDTO.Response carrito = carritoService.agregarItem(usuarioId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(carrito));
    }

    @DeleteMapping(value = "/usuario/{usuarioId}/items/{productoId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Eliminar un item del carrito (HATEOAS)")
    public EntityModel<CarritoDTO.Response> eliminarItem(@PathVariable Long usuarioId, @PathVariable Long productoId) {
        return assembler.toModel(carritoService.eliminarItem(usuarioId, productoId));
    }

    @DeleteMapping(value = "/usuario/{usuarioId}/vaciar", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Vaciar el carrito de un usuario (HATEOAS)")
    public ResponseEntity<Map<String, String>> vaciar(@PathVariable Long usuarioId) {
        carritoService.vaciarCarrito(usuarioId);
        return ResponseEntity.ok(Map.of("mensaje", "Carrito vaciado exitosamente"));
    }

    // ===== Reportes con HATEOAS (ver CarritoService) =====

    // 1. Obtener todos los carritos en un estado específico
    @GetMapping(value = "/estado/{estado}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar carritos por estado (HATEOAS)",
            description = "Obtiene todos los carritos en un estado específico: ACTIVO, COMPLETADO o ABANDONADO")
    public CollectionModel<EntityModel<CarritoDTO.Response>> listarPorEstado(@PathVariable Carrito.EstadoCarrito estado) {
        List<EntityModel<CarritoDTO.Response>> carritos = carritoService.listarPorEstado(estado).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(carritos,
                linkTo(methodOn(CarritoControllerV2.class).listarPorEstado(estado)).withSelfRel());
    }

    // 2. Obtener todos los carritos creados en una fecha específica (ej: /api/v2/carrito/fecha/2026-06-26)
    @GetMapping(value = "/fecha/{fecha}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar carritos creados en una fecha específica (HATEOAS)")
    public CollectionModel<EntityModel<CarritoDTO.Response>> listarPorFecha(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        List<EntityModel<CarritoDTO.Response>> carritos = carritoService.listarPorFecha(fecha).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(carritos,
                linkTo(methodOn(CarritoControllerV2.class).listarPorFecha(fecha)).withSelfRel());
    }

    // 3. Obtener todos los carritos creados entre dos fechas
    @GetMapping(value = "/rango", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar carritos creados entre dos fechas (HATEOAS)")
    public CollectionModel<EntityModel<CarritoDTO.Response>> listarEntreFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        List<EntityModel<CarritoDTO.Response>> carritos = carritoService.listarEntreFechas(inicio, fin).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(carritos,
                linkTo(methodOn(CarritoControllerV2.class).listarEntreFechas(inicio, fin)).withSelfRel());
    }

    // 4. Obtener el total de carritos en un estado específico
    @GetMapping(value = "/estado/{estado}/total", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el total de carritos en un estado específico (HATEOAS)")
    public EntityModel<Map<String, Object>> contarPorEstado(@PathVariable Carrito.EstadoCarrito estado) {
        long total = carritoService.contarPorEstado(estado);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("estado", estado);
        body.put("totalCarritos", total);

        return EntityModel.of(body,
                linkTo(methodOn(CarritoControllerV2.class).contarPorEstado(estado)).withSelfRel(),
                linkTo(methodOn(CarritoControllerV2.class).listarPorEstado(estado)).withRel("carritosEnEseEstado"));
    }
}
