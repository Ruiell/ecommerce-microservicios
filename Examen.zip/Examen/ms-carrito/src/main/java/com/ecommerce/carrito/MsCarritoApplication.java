package com.ecommerce.carrito;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
/**
 * Microservicio de Carrito de Compras
 * Puerto: 8085
 * Responsabilidad: Gestión del carrito antes del checkout
 * Comunicación: Feign → ms-productos | WebClient → ms-inventario
 */
@SpringBootApplication @EnableFeignClients
public class MsCarritoApplication {
    public static void main(String[] args) { SpringApplication.run(MsCarritoApplication.class, args); }
}
