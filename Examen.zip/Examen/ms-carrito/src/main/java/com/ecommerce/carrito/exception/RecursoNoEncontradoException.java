package com.ecommerce.carrito.exception;
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String m) { super(m); }
}
