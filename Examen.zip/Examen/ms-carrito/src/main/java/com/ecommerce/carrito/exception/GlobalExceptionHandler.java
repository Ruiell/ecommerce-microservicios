package com.ecommerce.carrito.exception;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime; import java.util.*;
@ControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    @ExceptionHandler(RecursoNoEncontradoException.class)
    public ResponseEntity<Map<String,Object>> handleNotFound(RecursoNoEncontradoException ex) {
        log.error("No encontrado: {}", ex.getMessage());
        return ResponseEntity.status(404).body(build(404, ex.getMessage(), "NOT_FOUND"));
    }
    @ExceptionHandler(StockInsuficienteException.class)
    public ResponseEntity<Map<String,Object>> handleStockInsuficiente(StockInsuficienteException ex) {
        log.warn("Stock insuficiente: {}", ex.getMessage());
        return ResponseEntity.status(409).body(build(409, ex.getMessage(), "CONFLICT"));
    }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String,Object>> handleValidation(MethodArgumentNotValidException ex) {
        Map<String,String> errores = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(e -> errores.put(((FieldError)e).getField(), e.getDefaultMessage()));
        Map<String,Object> r = build(400, "Error de validación", "VALIDATION_ERROR");
        r.put("errores", errores); return ResponseEntity.badRequest().body(r);
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String,Object>> handleGeneric(Exception ex) {
        log.error("Error interno: {}", ex.getMessage(), ex);
        return ResponseEntity.status(500).body(build(500, "Error interno", "INTERNAL_ERROR"));
    }
    private Map<String,Object> build(int s, String m, String t) {
        return Map.of("timestamp", LocalDateTime.now().toString(), "status", s, "mensaje", m, "tipo", t);
    }
}
