package com.ecommerce.carrito.dto;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.util.List;

public class CarritoDTO {
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class AgregarItemRequest {
        @NotNull(message = "El productoId es obligatorio") private Long productoId;
        @NotNull @Min(1) private Integer cantidad;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ItemResponse {
        private Long id; private Long productoId; private String nombreProducto;
        private Integer cantidad; private BigDecimal precioUnitario; private BigDecimal subtotal;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id; private Long usuarioId; private String estado;
        private List<ItemResponse> items; private BigDecimal total; private Integer totalItems;
    }
}
