package com.ecommerce.carrito.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.carrito.controller.CarritoControllerV2;
import com.ecommerce.carrito.dto.CarritoDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class CarritoModelAssembler implements RepresentationModelAssembler<CarritoDTO.Response, EntityModel<CarritoDTO.Response>> {

    @Override
    public EntityModel<CarritoDTO.Response> toModel(CarritoDTO.Response carrito) {
        return EntityModel.of(carrito,
                linkTo(methodOn(CarritoControllerV2.class).obtenerCarrito(carrito.getUsuarioId())).withSelfRel(),
                linkTo(methodOn(CarritoControllerV2.class).vaciar(carrito.getUsuarioId())).withRel("vaciarCarrito"));
    }
}
