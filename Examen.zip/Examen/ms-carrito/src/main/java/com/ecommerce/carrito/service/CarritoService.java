package com.ecommerce.carrito.service;

import com.ecommerce.carrito.config.ProductoFeignClient;
import com.ecommerce.carrito.config.InventarioFeignClient;
import com.ecommerce.carrito.dto.CarritoDTO;
import com.ecommerce.carrito.exception.RecursoNoEncontradoException;
import com.ecommerce.carrito.exception.StockInsuficienteException;
import com.ecommerce.carrito.model.Carrito;
import com.ecommerce.carrito.model.ItemCarrito;
import com.ecommerce.carrito.repository.CarritoRepository;
import com.ecommerce.carrito.repository.ItemCarritoRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Servicio de Carrito - Lógica de negocio de compras
 */
@Service @RequiredArgsConstructor
public class CarritoService {

    private static final Logger log = LoggerFactory.getLogger(CarritoService.class);
    private final CarritoRepository carritoRepository;
    private final ItemCarritoRepository itemCarritoRepository;
    private final ProductoFeignClient productoFeignClient;
    private final InventarioFeignClient inventarioFeignClient;

    @Transactional
    public CarritoDTO.Response obtenerOCrearCarrito(Long usuarioId) {
        log.info("Obteniendo/creando carrito para usuario: {}", usuarioId);
        Carrito carrito = carritoRepository.findByUsuarioIdAndEstado(usuarioId, Carrito.EstadoCarrito.ACTIVO)
                .orElseGet(() -> {
                    log.info("Creando nuevo carrito para usuario: {}", usuarioId);
                    Carrito nuevo = new Carrito();
                    nuevo.setUsuarioId(usuarioId);
                    nuevo.setEstado(Carrito.EstadoCarrito.ACTIVO);
                    nuevo.setItems(new ArrayList<>());
                    return carritoRepository.save(nuevo);
                });
        return mapear(carrito);
    }

    @Transactional
    public CarritoDTO.Response agregarItem(Long usuarioId, CarritoDTO.AgregarItemRequest request) {
        log.info("Agregando item productoId={} al carrito del usuario={}", request.getProductoId(), usuarioId);

        Carrito carrito = carritoRepository.findByUsuarioIdAndEstado(usuarioId, Carrito.EstadoCarrito.ACTIVO)
                .orElseGet(() -> {
                    Carrito c = new Carrito();
                    c.setUsuarioId(usuarioId); c.setEstado(Carrito.EstadoCarrito.ACTIVO); c.setItems(new ArrayList<>());
                    return carritoRepository.save(c);
                });

        // Obtener datos del producto via Feign
        Map<String, Object> producto;
        try {
            producto = productoFeignClient.obtenerProducto(request.getProductoId());
        } catch (Exception e) {
            log.error("Error al obtener producto {}: {}", request.getProductoId(), e.getMessage());
            throw new RecursoNoEncontradoException("Producto no encontrado: " + request.getProductoId());
        }

        BigDecimal precio = new BigDecimal(producto.get("precio").toString());
        String nombre = (String) producto.get("nombre");

        // Verificar disponibilidad de stock via Feign hacia ms-inventario.
        // Si ms-inventario no responde, se deja pasar (no bloqueamos la compra por una caída
        // de un servicio secundario) pero se registra en el log para revisión.
        try {
            Map<String, Object> disponibilidad = inventarioFeignClient.verificarDisponibilidad(
                    request.getProductoId(), request.getCantidad());
            if (Boolean.FALSE.equals(disponibilidad.get("disponible"))) {
                throw new StockInsuficienteException(
                        "Stock insuficiente para el producto " + request.getProductoId()
                                + " (solicitado: " + request.getCantidad() + ")");
            }
        } catch (StockInsuficienteException e) {
            throw e;
        } catch (Exception e) {
            log.warn("No se pudo verificar disponibilidad en ms-inventario para producto {}: {}",
                    request.getProductoId(), e.getMessage());
        }

        // Regla de negocio: si el item ya existe, sumar cantidad
        Optional<ItemCarrito> itemExistente = itemCarritoRepository
                .findByCarritoIdAndProductoId(carrito.getId(), request.getProductoId());

        if (itemExistente.isPresent()) {
            ItemCarrito item = itemExistente.get();
            item.setCantidad(item.getCantidad() + request.getCantidad());
            itemCarritoRepository.save(item);
            log.info("Cantidad actualizada para productoId={}", request.getProductoId());
        } else {
            ItemCarrito nuevoItem = new ItemCarrito();
            nuevoItem.setCarrito(carrito); nuevoItem.setProductoId(request.getProductoId());
            nuevoItem.setCantidad(request.getCantidad());
            nuevoItem.setPrecioUnitario(precio); nuevoItem.setNombreProducto(nombre);
            itemCarritoRepository.save(nuevoItem);
        }

        return mapear(carritoRepository.findById(carrito.getId()).orElseThrow());
    }

    @Transactional
    public CarritoDTO.Response eliminarItem(Long usuarioId, Long productoId) {
        log.info("Eliminando productoId={} del carrito del usuario={}", productoId, usuarioId);
        Carrito carrito = carritoRepository.findByUsuarioIdAndEstado(usuarioId, Carrito.EstadoCarrito.ACTIVO)
                .orElseThrow(() -> new RecursoNoEncontradoException("Carrito activo no encontrado para usuario: " + usuarioId));
        ItemCarrito item = itemCarritoRepository.findByCarritoIdAndProductoId(carrito.getId(), productoId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Producto no está en el carrito: " + productoId));
        itemCarritoRepository.delete(item);
        log.info("Item eliminado del carrito");
        return mapear(carritoRepository.findById(carrito.getId()).orElseThrow());
    }

    @Transactional
    public void vaciarCarrito(Long usuarioId) {
        log.info("Vaciando carrito del usuario: {}", usuarioId);
        carritoRepository.findByUsuarioIdAndEstado(usuarioId, Carrito.EstadoCarrito.ACTIVO)
                .ifPresent(c -> { itemCarritoRepository.deleteByCarritoId(c.getId()); log.info("Carrito vaciado"); });
    }

    // ===== Reportes con HATEOAS (mismo patrón que PagoService/PedidoService) =====

    // 1. Obtener todos los carritos en un estado específico
    @Transactional(readOnly = true)
    public List<CarritoDTO.Response> listarPorEstado(Carrito.EstadoCarrito estado) {
        return carritoRepository.findByEstado(estado).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 2. Obtener todos los carritos creados en una fecha específica (entre el inicio y el fin de ese día)
    @Transactional(readOnly = true)
    public List<CarritoDTO.Response> listarPorFecha(LocalDate fecha) {
        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.atTime(LocalTime.MAX);
        return carritoRepository.findByFechaCreacionBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 3. Obtener todos los carritos creados entre dos fechas
    @Transactional(readOnly = true)
    public List<CarritoDTO.Response> listarEntreFechas(LocalDateTime inicio, LocalDateTime fin) {
        return carritoRepository.findByFechaCreacionBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 4. Obtener el total de carritos en un estado específico
    @Transactional(readOnly = true)
    public long contarPorEstado(Carrito.EstadoCarrito estado) {
        return carritoRepository.countByEstado(estado);
    }

    private CarritoDTO.Response mapear(Carrito c) {
        List<CarritoDTO.ItemResponse> items = c.getItems() == null ? List.of() :
            c.getItems().stream().map(i -> {
                CarritoDTO.ItemResponse ir = new CarritoDTO.ItemResponse();
                ir.setId(i.getId()); ir.setProductoId(i.getProductoId());
                ir.setNombreProducto(i.getNombreProducto()); ir.setCantidad(i.getCantidad());
                ir.setPrecioUnitario(i.getPrecioUnitario());
                ir.setSubtotal(i.getPrecioUnitario().multiply(BigDecimal.valueOf(i.getCantidad())));
                return ir;
            }).collect(Collectors.toList());

        BigDecimal total = items.stream().map(CarritoDTO.ItemResponse::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        CarritoDTO.Response r = new CarritoDTO.Response();
        r.setId(c.getId()); r.setUsuarioId(c.getUsuarioId());
        r.setEstado(c.getEstado().name()); r.setItems(items);
        r.setTotal(total); r.setTotalItems(items.stream().mapToInt(CarritoDTO.ItemResponse::getCantidad).sum());
        return r;
    }
}
