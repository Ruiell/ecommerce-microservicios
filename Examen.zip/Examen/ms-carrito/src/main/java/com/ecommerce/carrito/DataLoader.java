package com.ecommerce.carrito;

import com.ecommerce.carrito.model.Carrito;
import com.ecommerce.carrito.model.ItemCarrito;
import com.ecommerce.carrito.repository.CarritoRepository;
import com.ecommerce.carrito.repository.ItemCarritoRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Profile({"dev", "render"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private CarritoRepository carritoRepository;

    @Autowired
    private ItemCarritoRepository itemCarritoRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

        Carrito.EstadoCarrito[] estados = Carrito.EstadoCarrito.values();

        // Generar carritos de ejemplo, cada uno con 1 a 4 items
        for (int i = 0; i < 15; i++) {
            Carrito carrito = new Carrito();
            carrito.setUsuarioId((long) faker.number().numberBetween(1, 50));
            carrito.setEstado(estados[random.nextInt(estados.length)]);
            carrito.setItems(new ArrayList<>());
            carrito = carritoRepository.save(carrito);

            int cantidadItems = faker.number().numberBetween(1, 4);
            List<Long> productosYaAgregados = new ArrayList<>();

            for (int j = 0; j < cantidadItems; j++) {
                long productoId = faker.number().numberBetween(1, 100);
                if (productosYaAgregados.contains(productoId)) {
                    continue;
                }
                productosYaAgregados.add(productoId);

                ItemCarrito item = new ItemCarrito();
                item.setCarrito(carrito);
                item.setProductoId(productoId);
                item.setCantidad(faker.number().numberBetween(1, 5));
                item.setPrecioUnitario(BigDecimal.valueOf(faker.number().randomDouble(2, 1000, 60000)));
                item.setNombreProducto(faker.commerce().productName());
                itemCarritoRepository.save(item);
            }
        }

        List<Carrito> carritos = carritoRepository.findAll();
        System.out.println("DataLoader: se generaron " + carritos.size() + " carritos de ejemplo.");
    }
}
