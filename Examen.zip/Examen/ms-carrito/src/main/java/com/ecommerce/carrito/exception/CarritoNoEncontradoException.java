package com.ecommerce.carrito.exception;
public class CarritoNoEncontradoException extends RuntimeException {
    public CarritoNoEncontradoException(String msg) { super(msg); }
}
