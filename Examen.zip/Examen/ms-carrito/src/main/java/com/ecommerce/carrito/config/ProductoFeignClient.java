package com.ecommerce.carrito.config;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
/**
 * Feign Client - Obtiene datos de producto desde ms-productos
 */
@FeignClient(name = "ms-productos", url = "${microservices.productos.url}")
public interface ProductoFeignClient {
    @GetMapping("/api/productos/{id}")
    Map<String, Object> obtenerProducto(@PathVariable Long id);
}
