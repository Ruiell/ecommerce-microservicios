package com.ecommerce.carrito.controller;

import com.ecommerce.carrito.dto.CarritoDTO;
import com.ecommerce.carrito.service.CarritoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController @RequestMapping("/api/carrito") @RequiredArgsConstructor
public class CarritoController {

    private static final Logger log = LoggerFactory.getLogger(CarritoController.class);
    private final CarritoService carritoService;

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<CarritoDTO.Response> obtenerCarrito(@PathVariable Long usuarioId) {
        log.info("GET /api/carrito/usuario/{}", usuarioId);
        return ResponseEntity.ok(carritoService.obtenerOCrearCarrito(usuarioId));
    }

    @PostMapping("/usuario/{usuarioId}/items")
    public ResponseEntity<CarritoDTO.Response> agregarItem(@PathVariable Long usuarioId,
            @Valid @RequestBody CarritoDTO.AgregarItemRequest request) {
        log.info("POST /api/carrito/usuario/{}/items", usuarioId);
        return ResponseEntity.status(HttpStatus.CREATED).body(carritoService.agregarItem(usuarioId, request));
    }

    @DeleteMapping("/usuario/{usuarioId}/items/{productoId}")
    public ResponseEntity<CarritoDTO.Response> eliminarItem(@PathVariable Long usuarioId,
            @PathVariable Long productoId) {
        log.info("DELETE /api/carrito/usuario/{}/items/{}", usuarioId, productoId);
        return ResponseEntity.ok(carritoService.eliminarItem(usuarioId, productoId));
    }

    @DeleteMapping("/usuario/{usuarioId}/vaciar")
    public ResponseEntity<Map<String,String>> vaciar(@PathVariable Long usuarioId) {
        log.info("DELETE /api/carrito/usuario/{}/vaciar", usuarioId);
        carritoService.vaciarCarrito(usuarioId);
        return ResponseEntity.ok(Map.of("mensaje", "Carrito vaciado exitosamente"));
    }
}
