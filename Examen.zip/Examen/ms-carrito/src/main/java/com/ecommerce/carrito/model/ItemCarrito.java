package com.ecommerce.carrito.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;

@Entity @Table(name = "items_carrito") @Data @NoArgsConstructor @AllArgsConstructor
public class ItemCarrito {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "carrito_id", nullable = false) private Carrito carrito;
    @NotNull @Column(name = "producto_id", nullable = false) private Long productoId;
    @NotNull @Min(1) @Column(nullable = false) private Integer cantidad;
    @NotNull @Column(name = "precio_unitario", nullable = false, precision = 10, scale = 2) private BigDecimal precioUnitario;
    @Column(name = "nombre_producto") private String nombreProducto;
}
