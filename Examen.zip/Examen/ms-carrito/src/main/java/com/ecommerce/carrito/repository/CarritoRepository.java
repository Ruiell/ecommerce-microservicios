package com.ecommerce.carrito.repository;
import com.ecommerce.carrito.model.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Repository
public interface CarritoRepository extends JpaRepository<Carrito, Long> {
    Optional<Carrito> findByUsuarioIdAndEstado(Long usuarioId, Carrito.EstadoCarrito estado);

    // Métodos personalizados para los reportes con HATEOAS (CarritoControllerV2)
    List<Carrito> findByEstado(Carrito.EstadoCarrito estado);
    List<Carrito> findByFechaCreacionBetween(LocalDateTime inicio, LocalDateTime fin);
    long countByEstado(Carrito.EstadoCarrito estado);
}
