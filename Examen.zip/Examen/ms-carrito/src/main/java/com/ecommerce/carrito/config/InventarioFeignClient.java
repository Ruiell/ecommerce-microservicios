package com.ecommerce.carrito.config;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

/**
 * Feign Client para comunicarse con ms-inventario
 */
@FeignClient(name = "ms-inventario", url = "${microservices.inventario.url}")
public interface InventarioFeignClient {
    @GetMapping("/api/inventario/producto/{productoId}/disponibilidad")
    Map<String, Object> verificarDisponibilidad(@PathVariable Long productoId, @RequestParam Integer cantidad);

    @PostMapping("/api/inventario/producto/{productoId}/reservar")
    Object reservarStock(@PathVariable Long productoId, @RequestParam Integer cantidad);

    @PostMapping("/api/inventario/producto/{productoId}/liberar")
    Object liberarReserva(@PathVariable Long productoId, @RequestParam Integer cantidad);
}
