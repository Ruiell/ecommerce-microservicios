package com.ecommerce.carrito.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity @Table(name = "carritos") @Data @NoArgsConstructor @AllArgsConstructor
public class Carrito {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "usuario_id", nullable = false) private Long usuarioId;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private EstadoCarrito estado = EstadoCarrito.ACTIVO;
    @OneToMany(mappedBy = "carrito", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<ItemCarrito> items;
    @Column(name = "fecha_creacion", updatable = false) private LocalDateTime fechaCreacion;
    @Column(name = "fecha_actualizacion") private LocalDateTime fechaActualizacion;
    @PrePersist protected void onCreate() { fechaCreacion = LocalDateTime.now(); fechaActualizacion = LocalDateTime.now(); }
    @PreUpdate protected void onUpdate() { fechaActualizacion = LocalDateTime.now(); }
    public enum EstadoCarrito { ACTIVO, COMPLETADO, ABANDONADO }
}
