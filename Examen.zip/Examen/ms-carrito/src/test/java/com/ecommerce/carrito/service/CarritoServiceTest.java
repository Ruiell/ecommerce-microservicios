package com.ecommerce.carrito.service;

import com.ecommerce.carrito.config.ProductoFeignClient;
import com.ecommerce.carrito.config.InventarioFeignClient;
import com.ecommerce.carrito.dto.CarritoDTO;
import com.ecommerce.carrito.exception.RecursoNoEncontradoException;
import com.ecommerce.carrito.exception.StockInsuficienteException;
import com.ecommerce.carrito.model.Carrito;
import com.ecommerce.carrito.model.ItemCarrito;
import com.ecommerce.carrito.repository.CarritoRepository;
import com.ecommerce.carrito.repository.ItemCarritoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CarritoServiceTest {

    @Mock
    private CarritoRepository carritoRepository;
    @Mock
    private ItemCarritoRepository itemCarritoRepository;
    @Mock
    private ProductoFeignClient productoFeignClient;
    @Mock
    private InventarioFeignClient inventarioFeignClient;

    @InjectMocks
    private CarritoService carritoService;

    private Carrito crearCarritoDePrueba() {
        Carrito c = new Carrito();
        c.setId(1L);
        c.setUsuarioId(5L);
        c.setEstado(Carrito.EstadoCarrito.ACTIVO);
        c.setItems(new ArrayList<>());
        return c;
    }

    @Test
    void testObtenerOCrearCarrito_Existente() {
        when(carritoRepository.findByUsuarioIdAndEstado(5L, Carrito.EstadoCarrito.ACTIVO))
                .thenReturn(Optional.of(crearCarritoDePrueba()));

        CarritoDTO.Response respuesta = carritoService.obtenerOCrearCarrito(5L);

        assertNotNull(respuesta);
        assertEquals(5L, respuesta.getUsuarioId());
        verify(carritoRepository, never()).save(any());
    }

    @Test
    void testObtenerOCrearCarrito_Nuevo() {
        when(carritoRepository.findByUsuarioIdAndEstado(5L, Carrito.EstadoCarrito.ACTIVO))
                .thenReturn(Optional.empty());
        when(carritoRepository.save(any(Carrito.class))).thenReturn(crearCarritoDePrueba());

        CarritoDTO.Response respuesta = carritoService.obtenerOCrearCarrito(5L);

        assertNotNull(respuesta);
        verify(carritoRepository, times(1)).save(any(Carrito.class));
    }

    @Test
    void testAgregarItem_ProductoInexistente() {
        Carrito carrito = crearCarritoDePrueba();
        when(carritoRepository.findByUsuarioIdAndEstado(5L, Carrito.EstadoCarrito.ACTIVO))
                .thenReturn(Optional.of(carrito));
        when(productoFeignClient.obtenerProducto(999L)).thenThrow(new RuntimeException("no encontrado"));

        CarritoDTO.AgregarItemRequest request = new CarritoDTO.AgregarItemRequest();
        request.setProductoId(999L);
        request.setCantidad(1);

        assertThrows(RecursoNoEncontradoException.class, () -> carritoService.agregarItem(5L, request));
    }

    @Test
    void testAgregarItem_NuevoItem() {
        Carrito carrito = crearCarritoDePrueba();
        when(carritoRepository.findByUsuarioIdAndEstado(5L, Carrito.EstadoCarrito.ACTIVO))
                .thenReturn(Optional.of(carrito));
        when(productoFeignClient.obtenerProducto(10L))
                .thenReturn(Map.of("precio", "9990.00", "nombre", "Peluche Squishy"));
        when(inventarioFeignClient.verificarDisponibilidad(10L, 2))
                .thenReturn(Map.of("disponible", true));
        when(itemCarritoRepository.findByCarritoIdAndProductoId(1L, 10L)).thenReturn(Optional.empty());
        when(carritoRepository.findById(1L)).thenReturn(Optional.of(carrito));

        CarritoDTO.AgregarItemRequest request = new CarritoDTO.AgregarItemRequest();
        request.setProductoId(10L);
        request.setCantidad(2);

        CarritoDTO.Response respuesta = carritoService.agregarItem(5L, request);

        assertNotNull(respuesta);
        verify(itemCarritoRepository, times(1)).save(any(ItemCarrito.class));
    }

    @Test
    void testAgregarItem_StockInsuficiente() {
        Carrito carrito = crearCarritoDePrueba();
        when(carritoRepository.findByUsuarioIdAndEstado(5L, Carrito.EstadoCarrito.ACTIVO))
                .thenReturn(Optional.of(carrito));
        when(productoFeignClient.obtenerProducto(10L))
                .thenReturn(Map.of("precio", "9990.00", "nombre", "Peluche Squishy"));
        when(inventarioFeignClient.verificarDisponibilidad(10L, 50))
                .thenReturn(Map.of("disponible", false));

        CarritoDTO.AgregarItemRequest request = new CarritoDTO.AgregarItemRequest();
        request.setProductoId(10L);
        request.setCantidad(50);

        assertThrows(StockInsuficienteException.class, () -> carritoService.agregarItem(5L, request));
        verify(itemCarritoRepository, never()).save(any(ItemCarrito.class));
    }

    @Test
    void testAgregarItem_InventarioNoDisponible_NoBloqueaLaCompra() {
        // Si ms-inventario está caído, agregarItem no debe fallar: solo se registra el warning.
        Carrito carrito = crearCarritoDePrueba();
        when(carritoRepository.findByUsuarioIdAndEstado(5L, Carrito.EstadoCarrito.ACTIVO))
                .thenReturn(Optional.of(carrito));
        when(productoFeignClient.obtenerProducto(10L))
                .thenReturn(Map.of("precio", "9990.00", "nombre", "Peluche Squishy"));
        when(inventarioFeignClient.verificarDisponibilidad(10L, 2))
                .thenThrow(new RuntimeException("ms-inventario no disponible"));
        when(itemCarritoRepository.findByCarritoIdAndProductoId(1L, 10L)).thenReturn(Optional.empty());
        when(carritoRepository.findById(1L)).thenReturn(Optional.of(carrito));

        CarritoDTO.AgregarItemRequest request = new CarritoDTO.AgregarItemRequest();
        request.setProductoId(10L);
        request.setCantidad(2);

        CarritoDTO.Response respuesta = carritoService.agregarItem(5L, request);

        assertNotNull(respuesta);
        verify(itemCarritoRepository, times(1)).save(any(ItemCarrito.class));
    }

    @Test
    void testEliminarItem_CarritoNoEncontrado() {
        when(carritoRepository.findByUsuarioIdAndEstado(5L, Carrito.EstadoCarrito.ACTIVO))
                .thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> carritoService.eliminarItem(5L, 10L));
    }

    @Test
    void testVaciarCarrito() {
        Carrito carrito = crearCarritoDePrueba();
        when(carritoRepository.findByUsuarioIdAndEstado(5L, Carrito.EstadoCarrito.ACTIVO))
                .thenReturn(Optional.of(carrito));

        carritoService.vaciarCarrito(5L);

        verify(itemCarritoRepository, times(1)).deleteByCarritoId(1L);
    }

    @Test
    void testListarPorEstado() {
        when(carritoRepository.findByEstado(Carrito.EstadoCarrito.ACTIVO))
                .thenReturn(java.util.List.of(crearCarritoDePrueba()));

        var carritos = carritoService.listarPorEstado(Carrito.EstadoCarrito.ACTIVO);

        assertEquals(1, carritos.size());
    }

    @Test
    void testContarPorEstado() {
        when(carritoRepository.countByEstado(Carrito.EstadoCarrito.ACTIVO)).thenReturn(7L);

        long total = carritoService.contarPorEstado(Carrito.EstadoCarrito.ACTIVO);

        assertEquals(7L, total);
    }
}
