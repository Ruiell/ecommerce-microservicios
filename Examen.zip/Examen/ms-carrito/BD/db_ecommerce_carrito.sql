/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_carrito
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_carrito;

/* ============================================================
   2. Tabla carritos
   ============================================================ */
CREATE TABLE carritos (
    id                      BIGINT      NOT NULL AUTO_INCREMENT,
    usuario_id              BIGINT      NOT NULL,
    estado                  VARCHAR(20) NOT NULL DEFAULT 'ACTIVO',
    fecha_creacion          DATETIME    NOT NULL,
    fecha_actualizacion     DATETIME    NULL,
    CONSTRAINT carritos_PK PRIMARY KEY (id)
) ENGINE = InnoDB;

/* ============================================================
   3. Tabla items_carrito
   ============================================================ */
CREATE TABLE items_carrito (
    id                  BIGINT        NOT NULL AUTO_INCREMENT,
    carrito_id          BIGINT        NOT NULL,
    producto_id         BIGINT        NOT NULL,
    cantidad            INT           NOT NULL,
    precio_unitario     DECIMAL(10,2) NOT NULL,
    nombre_producto     VARCHAR(150)  NULL,
    CONSTRAINT items_carrito_PK PRIMARY KEY (id),
    CONSTRAINT items_carrito_carrito_FK FOREIGN KEY (carrito_id)
        REFERENCES carritos (id) ON DELETE CASCADE
) ENGINE = InnoDB;

/* ============================================================
   4. Restricciones adicionales (MySQL 8)
   ============================================================ */

-- Validar estado del carrito (debe calzar con el enum EstadoCarrito)
ALTER TABLE carritos
ADD CONSTRAINT chk_carritos_estado
  CHECK (estado IN ('ACTIVO','COMPLETADO','ABANDONADO'));

-- La cantidad de un item siempre debe ser positiva
ALTER TABLE items_carrito
ADD CONSTRAINT chk_items_carrito_cantidad
  CHECK (cantidad > 0);

/* ============================================================
   ¡Todo listo!
   ============================================================ */
