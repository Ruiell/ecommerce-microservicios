/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_pagos
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_pagos;

/* ============================================================
   2. Tabla pagos
   ============================================================ */
CREATE TABLE pagos (
    id                  BIGINT        NOT NULL AUTO_INCREMENT,
    pedido_id           BIGINT        NOT NULL,
    usuario_id          BIGINT        NOT NULL,
    monto               DECIMAL(10,2) NOT NULL,
    metodo_pago         VARCHAR(20)   NOT NULL,
    estado              VARCHAR(20)   NOT NULL DEFAULT 'PENDIENTE',
    codigo_transaccion  VARCHAR(50)   NULL,
    fecha_pago          DATETIME      NULL,
    fecha_creacion      DATETIME      NOT NULL,
    CONSTRAINT pagos_PK PRIMARY KEY (id),

    -- Clave candidata: el código de transacción es único cuando existe
    CONSTRAINT pagos_codigo_transaccion_UN UNIQUE (codigo_transaccion)
) ENGINE = InnoDB;

/* ============================================================
   3. Restricciones adicionales (MySQL 8)
   ============================================================ */

-- Validar método de pago (debe calzar con el enum MetodoPago)
ALTER TABLE pagos
ADD CONSTRAINT chk_pagos_metodo
  CHECK (metodo_pago IN ('TARJETA_CREDITO','TARJETA_DEBITO','TRANSFERENCIA','EFECTIVO'));

-- Validar estado del pago (debe calzar con el enum EstadoPago)
ALTER TABLE pagos
ADD CONSTRAINT chk_pagos_estado
  CHECK (estado IN ('PENDIENTE','APROBADO','RECHAZADO','REEMBOLSADO'));

/* ============================================================
   ¡Todo listo!
   ============================================================ */
