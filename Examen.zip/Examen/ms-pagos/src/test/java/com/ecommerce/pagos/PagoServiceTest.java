package com.ecommerce.pagos;

import com.ecommerce.pagos.config.PedidoFeignClient;
import com.ecommerce.pagos.dto.PagoDTO;
import com.ecommerce.pagos.exception.PagoRechazadoException;
import com.ecommerce.pagos.exception.RecursoNoEncontradoException;
import com.ecommerce.pagos.model.Pago;
import com.ecommerce.pagos.repository.PagoRepository;
import com.ecommerce.pagos.service.PagoService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class PagoServiceTest {

    // Inyecta el servicio de Pago para ser probado.
    @Autowired
    private PagoService pagoService;

    // Crea un mock del repositorio de Pago para simular su comportamiento.
    @MockBean
    private PagoRepository pagoRepository;

    // Crea un mock del Feign Client hacia ms-pedidos para no depender de ese microservicio.
    @MockBean
    private PedidoFeignClient pedidoFeignClient;

    @Test
    public void testProcesarPago_GuardaConLosDatosDelRequest() {
        PagoDTO.Request request = new PagoDTO.Request(
                1L, 2L, BigDecimal.valueOf(25000), Pago.MetodoPago.TRANSFERENCIA);

        // Define el comportamiento del mock: al guardar, devuelve el mismo Pago que recibe.
        when(pagoRepository.save(any(Pago.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // El servicio simula un 10% de probabilidad de rechazo (Math.random()), por lo que
        // en ese caso lanza PagoRechazadoException. Igualmente el pago queda guardado antes de lanzarla.
        try {
            pagoService.procesarPago(request);
        } catch (PagoRechazadoException ignored) {
            // Caso esperado cuando la simulación aleatoria rechaza el pago.
        }

        // Verifica que se haya llamado a save() exactamente una vez y captura el Pago guardado.
        ArgumentCaptor<Pago> captor = ArgumentCaptor.forClass(Pago.class);
        verify(pagoRepository, times(1)).save(captor.capture());
        Pago guardado = captor.getValue();

        // Verifica que los datos guardados correspondan a los del request, sin importar si fue aprobado o rechazado.
        assertEquals(request.getPedidoId(), guardado.getPedidoId());
        assertEquals(request.getUsuarioId(), guardado.getUsuarioId());
        assertEquals(request.getMonto(), guardado.getMonto());
        assertEquals(request.getMetodoPago(), guardado.getMetodoPago());
    }

    @Test
    public void testObtenerPorId() {
        Long id = 1L;
        Pago pago = crearPagoAprobado(id);

        // Define el comportamiento del mock: cuando se llame a findById(1L), devuelve el Pago.
        when(pagoRepository.findById(id)).thenReturn(Optional.of(pago));

        PagoDTO.Response response = pagoService.obtenerPorId(id);

        // Verifica que la respuesta no sea nula y que los datos coincidan.
        assertNotNull(response);
        assertEquals(id, response.getId());
        assertEquals(Pago.EstadoPago.APROBADO, response.getEstado());
    }

    @Test
    public void testObtenerPorId_NoEncontrado_LanzaExcepcion() {
        Long id = 99L;

        // Define el comportamiento del mock: no existe ningún Pago con ese id.
        when(pagoRepository.findById(id)).thenReturn(Optional.empty());

        // Verifica que el servicio lance la excepción correspondiente.
        assertThrows(RecursoNoEncontradoException.class, () -> pagoService.obtenerPorId(id));
    }

    @Test
    public void testListarPorPedido() {
        Long pedidoId = 5L;
        when(pagoRepository.findByPedidoId(pedidoId)).thenReturn(List.of(crearPagoAprobado(1L)));

        List<PagoDTO.Response> pagos = pagoService.listarPorPedido(pedidoId);

        assertNotNull(pagos);
        assertEquals(1, pagos.size());
    }

    @Test
    public void testListarPorUsuario() {
        Long usuarioId = 7L;
        when(pagoRepository.findByUsuarioId(usuarioId)).thenReturn(List.of(crearPagoAprobado(1L)));

        List<PagoDTO.Response> pagos = pagoService.listarPorUsuario(usuarioId);

        assertNotNull(pagos);
        assertEquals(1, pagos.size());
    }

    // ===== Tests de los reportes con HATEOAS (ver PagoService) =====

    @Test
    public void testListarPorEstado() {
        when(pagoRepository.findByEstado(Pago.EstadoPago.APROBADO))
                .thenReturn(List.of(crearPagoAprobado(1L)));

        List<PagoDTO.Response> pagos = pagoService.listarPorEstado(Pago.EstadoPago.APROBADO);

        assertNotNull(pagos);
        assertEquals(1, pagos.size());
        assertEquals(Pago.EstadoPago.APROBADO, pagos.get(0).getEstado());
    }

    @Test
    public void testListarPorFecha() {
        LocalDate fecha = LocalDate.of(2026, 6, 26);
        // El servicio debe traducir la fecha al rango [00:00:00, 23:59:59.999999999] de ese día
        LocalDateTime inicioEsperado = fecha.atStartOfDay();
        LocalDateTime finEsperado = fecha.atTime(LocalTime.MAX);

        when(pagoRepository.findByFechaCreacionBetween(inicioEsperado, finEsperado))
                .thenReturn(List.of(crearPagoAprobado(1L)));

        List<PagoDTO.Response> pagos = pagoService.listarPorFecha(fecha);

        assertNotNull(pagos);
        assertEquals(1, pagos.size());
        // Confirma que el servicio calculó exactamente ese rango (y no otro) al consultar el repositorio
        verify(pagoRepository, times(1)).findByFechaCreacionBetween(inicioEsperado, finEsperado);
    }

    @Test
    public void testListarEntreFechas() {
        LocalDateTime inicio = LocalDateTime.of(2026, 6, 1, 0, 0);
        LocalDateTime fin = LocalDateTime.of(2026, 6, 26, 23, 59, 59);

        when(pagoRepository.findByFechaCreacionBetween(inicio, fin))
                .thenReturn(List.of(crearPagoAprobado(1L), crearPagoAprobado(2L)));

        List<PagoDTO.Response> pagos = pagoService.listarEntreFechas(inicio, fin);

        assertNotNull(pagos);
        assertEquals(2, pagos.size());
    }

    @Test
    public void testContarPorUsuario() {
        Long usuarioId = 3L;
        when(pagoRepository.countByUsuarioId(usuarioId)).thenReturn(4L);

        long total = pagoService.contarPorUsuario(usuarioId);

        assertEquals(4L, total);
    }

    @Test
    public void testReembolsar_PagoAprobado_QuedaReembolsado() {
        Long id = 1L;
        Pago pago = crearPagoAprobado(id);

        when(pagoRepository.findById(id)).thenReturn(Optional.of(pago));
        when(pagoRepository.save(any(Pago.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PagoDTO.Response response = pagoService.reembolsar(id);

        assertNotNull(response);
        assertEquals(Pago.EstadoPago.REEMBOLSADO, response.getEstado());
    }

    @Test
    public void testReembolsar_PagoNoAprobado_LanzaExcepcion() {
        Long id = 1L;
        Pago pago = crearPagoAprobado(id);
        pago.setEstado(Pago.EstadoPago.PENDIENTE);

        when(pagoRepository.findById(id)).thenReturn(Optional.of(pago));

        // Solo se pueden reembolsar pagos aprobados; cualquier otro estado debe lanzar excepción.
        assertThrows(PagoRechazadoException.class, () -> pagoService.reembolsar(id));
    }

    @Test
    public void testExistePago_Existe() {
        Long id = 1L;
        when(pagoRepository.existsById(id)).thenReturn(true);

        boolean existe = pagoService.existePago(id);

        assertTrue(existe);
        verify(pagoRepository).existsById(id);
    }

    @Test
    public void testExistePago_NoExiste() {
        Long id = 99L;
        when(pagoRepository.existsById(id)).thenReturn(false);

        boolean existe = pagoService.existePago(id);

        assertFalse(existe);
    }

    private Pago crearPagoAprobado(Long id) {
        Pago pago = new Pago();
        pago.setId(id);
        pago.setPedidoId(1L);
        pago.setUsuarioId(1L);
        pago.setMonto(BigDecimal.valueOf(15000));
        pago.setMetodoPago(Pago.MetodoPago.TARJETA_CREDITO);
        pago.setEstado(Pago.EstadoPago.APROBADO);
        pago.setCodigoTransaccion("TXN-ABCD1234");
        pago.setFechaPago(LocalDateTime.now());
        return pago;
    }
}
