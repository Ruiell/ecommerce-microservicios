package com.ecommerce.pagos.model;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity @Table(name = "pagos") @Data @NoArgsConstructor @AllArgsConstructor
public class Pago {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "pedido_id", nullable = false) private Long pedidoId;
    @Column(name = "usuario_id", nullable = false) private Long usuarioId;
    @Column(nullable = false, precision = 10, scale = 2) private BigDecimal monto;
    @Enumerated(EnumType.STRING) @Column(name = "metodo_pago", nullable = false) private MetodoPago metodoPago;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private EstadoPago estado = EstadoPago.PENDIENTE;
    @Column(name = "codigo_transaccion", unique = true) private String codigoTransaccion;
    @Column(name = "fecha_pago") private LocalDateTime fechaPago;
    @Column(name = "fecha_creacion", updatable = false) private LocalDateTime fechaCreacion;
    @PrePersist protected void onCreate() { fechaCreacion = LocalDateTime.now(); }
    public enum MetodoPago { TARJETA_CREDITO, TARJETA_DEBITO, TRANSFERENCIA, EFECTIVO }
    public enum EstadoPago { PENDIENTE, APROBADO, RECHAZADO, REEMBOLSADO }
}
