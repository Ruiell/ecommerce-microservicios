package com.ecommerce.pagos.config;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
/** Feign Client - Actualiza estado del pedido tras pago */
@FeignClient(name = "ms-pedidos", url = "${microservices.pedidos.url}")
public interface PedidoFeignClient {
    @PatchMapping("/api/pedidos/{id}/estado")
    Map<String,Object> actualizarEstado(@PathVariable Long id, @RequestParam String estado);
}
