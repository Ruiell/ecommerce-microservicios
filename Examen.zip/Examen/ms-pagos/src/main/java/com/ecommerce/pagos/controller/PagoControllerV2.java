package com.ecommerce.pagos.controller;

import com.ecommerce.pagos.assemblers.PagoModelAssembler;
import com.ecommerce.pagos.dto.PagoDTO;
import com.ecommerce.pagos.model.Pago;
import com.ecommerce.pagos.service.PagoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de pagos.
 * Las respuestas incluyen enlaces de navegación (self, pagosDelPedido, pagosDelUsuario).
 * Para la versión sin HATEOAS usar /api/pagos (PagoController).
 */
@RestController
@RequestMapping("/api/v2/pagos")
@Tag(name = "Pagos (HATEOAS)", description = "Operaciones sobre pagos con enlaces HATEOAS")
public class PagoControllerV2 {

    @Autowired
    private PagoService pagoService;

    @Autowired
    private PagoModelAssembler assembler;

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Procesar un nuevo pago", description = "Igual que /api/pagos, pero responde en formato HAL con enlaces")
    public ResponseEntity<EntityModel<PagoDTO.Response>> procesarPago(@Valid @RequestBody PagoDTO.Request request) {
        PagoDTO.Response nuevoPago = pagoService.procesarPago(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(assembler.toModel(nuevoPago));
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un pago por id (HATEOAS)")
    public EntityModel<PagoDTO.Response> obtener(@PathVariable Long id) {
        PagoDTO.Response pago = pagoService.obtenerPorId(id);
        return assembler.toModel(pago);
    }

    @GetMapping(value = "/pedido/{pedidoId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar pagos de un pedido (HATEOAS)")
    public CollectionModel<EntityModel<PagoDTO.Response>> listarPorPedido(@PathVariable Long pedidoId) {
        List<EntityModel<PagoDTO.Response>> pagos = pagoService.listarPorPedido(pedidoId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pagos,
                linkTo(methodOn(PagoControllerV2.class).listarPorPedido(pedidoId)).withSelfRel());
    }

    @GetMapping(value = "/usuario/{usuarioId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar pagos de un usuario (HATEOAS)")
    public CollectionModel<EntityModel<PagoDTO.Response>> listarPorUsuario(@PathVariable Long usuarioId) {
        List<EntityModel<PagoDTO.Response>> pagos = pagoService.listarPorUsuario(usuarioId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pagos,
                linkTo(methodOn(PagoControllerV2.class).listarPorUsuario(usuarioId)).withSelfRel());
    }

    @PostMapping(value = "/{id}/reembolsar", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Reembolsar un pago (HATEOAS)")
    public EntityModel<PagoDTO.Response> reembolsar(@PathVariable Long id) {
        PagoDTO.Response pago = pagoService.reembolsar(id);
        return assembler.toModel(pago);
    }

    // ===== Reportes con HATEOAS (ver PagoService) =====

    // 1. Obtener todos los pagos con un estado específico
    @GetMapping(value = "/estado/{estado}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar pagos por estado (HATEOAS)",
            description = "Obtiene todos los pagos en un estado específico: PENDIENTE, APROBADO, RECHAZADO o REEMBOLSADO")
    public CollectionModel<EntityModel<PagoDTO.Response>> listarPorEstado(@PathVariable Pago.EstadoPago estado) {
        List<EntityModel<PagoDTO.Response>> pagos = pagoService.listarPorEstado(estado).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pagos,
                linkTo(methodOn(PagoControllerV2.class).listarPorEstado(estado)).withSelfRel());
    }

    // 2. Obtener todos los pagos creados en una fecha específica (ej: /api/v2/pagos/fecha/2026-06-26)
    @GetMapping(value = "/fecha/{fecha}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar pagos creados en una fecha específica (HATEOAS)")
    public CollectionModel<EntityModel<PagoDTO.Response>> listarPorFecha(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        List<EntityModel<PagoDTO.Response>> pagos = pagoService.listarPorFecha(fecha).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pagos,
                linkTo(methodOn(PagoControllerV2.class).listarPorFecha(fecha)).withSelfRel());
    }

    // 3. Obtener todos los pagos creados entre dos fechas (ej: ?inicio=2026-06-01T00:00:00&fin=2026-06-26T23:59:59)
    @GetMapping(value = "/rango", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar pagos creados entre dos fechas (HATEOAS)")
    public CollectionModel<EntityModel<PagoDTO.Response>> listarEntreFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        List<EntityModel<PagoDTO.Response>> pagos = pagoService.listarEntreFechas(inicio, fin).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pagos,
                linkTo(methodOn(PagoControllerV2.class).listarEntreFechas(inicio, fin)).withSelfRel());
    }

    // 4. Obtener el total de pagos realizados por un usuario
    @GetMapping(value = "/usuario/{usuarioId}/total", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el total de pagos realizados por un usuario (HATEOAS)")
    public EntityModel<Map<String, Object>> contarPorUsuario(@PathVariable Long usuarioId) {
        long total = pagoService.contarPorUsuario(usuarioId);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("usuarioId", usuarioId);
        body.put("totalPagos", total);

        return EntityModel.of(body,
                linkTo(methodOn(PagoControllerV2.class).contarPorUsuario(usuarioId)).withSelfRel(),
                linkTo(methodOn(PagoControllerV2.class).listarPorUsuario(usuarioId)).withRel("pagosDelUsuario"));
    }

    /* ===== Ejercicios para el estudiante (mismo patrón de la guía HATEOAS) =====
       Implementa estos 5 reportes siguiendo el mismo patrón (repositorio -> servicio -> aquí):
       1. Listar pagos de un usuario en un estado específico    -> findByUsuarioIdAndEstado
       2. Listar pagos de un pedido en un estado específico     -> findByPedidoIdAndEstado
       3. Listar pagos de un usuario entre dos fechas           -> findByUsuarioIdAndFechaCreacionBetween
       4. Listar pagos de un pedido entre dos fechas            -> findByPedidoIdAndFechaCreacionBetween
       5. Obtener el total de pagos realizados con un método de pago específico -> countByMetodoPago */
}
