package com.ecommerce.pagos;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
/** Microservicio de Pagos - Puerto: 8087 */
@SpringBootApplication @EnableFeignClients
public class MsPagosApplication {
    public static void main(String[] args) { SpringApplication.run(MsPagosApplication.class, args); }
}
