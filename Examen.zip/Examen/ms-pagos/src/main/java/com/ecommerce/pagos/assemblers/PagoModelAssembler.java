package com.ecommerce.pagos.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.pagos.controller.PagoControllerV2;
import com.ecommerce.pagos.dto.PagoDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class PagoModelAssembler implements RepresentationModelAssembler<PagoDTO.Response, EntityModel<PagoDTO.Response>> {

    @Override
    public EntityModel<PagoDTO.Response> toModel(PagoDTO.Response pago) {
        return EntityModel.of(pago,
                linkTo(methodOn(PagoControllerV2.class).obtener(pago.getId())).withSelfRel(),
                linkTo(methodOn(PagoControllerV2.class).listarPorPedido(pago.getPedidoId())).withRel("pagosDelPedido"),
                linkTo(methodOn(PagoControllerV2.class).listarPorUsuario(pago.getUsuarioId())).withRel("pagosDelUsuario"));
    }
}
