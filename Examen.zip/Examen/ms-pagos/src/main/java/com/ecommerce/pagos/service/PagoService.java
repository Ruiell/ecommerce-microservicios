package com.ecommerce.pagos.service;

import com.ecommerce.pagos.config.PedidoFeignClient;
import com.ecommerce.pagos.dto.PagoDTO;
import com.ecommerce.pagos.exception.*;
import com.ecommerce.pagos.model.Pago;
import com.ecommerce.pagos.repository.PagoRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor
public class PagoService {

    private static final Logger log = LoggerFactory.getLogger(PagoService.class);
    private final PagoRepository pagoRepository;
    private final PedidoFeignClient pedidoFeignClient;

    @Transactional
    public PagoDTO.Response procesarPago(PagoDTO.Request request) {
        log.info("Procesando pago para pedidoId: {} monto: {}", request.getPedidoId(), request.getMonto());

        Pago pago = new Pago();
        pago.setPedidoId(request.getPedidoId());
        pago.setUsuarioId(request.getUsuarioId());
        pago.setMonto(request.getMonto());
        pago.setMetodoPago(request.getMetodoPago());

        // Simular procesamiento de pago (en producción iría gateway real)
        boolean aprobado = simularProcesamiento(request.getMetodoPago());

        if (aprobado) {
            pago.setEstado(Pago.EstadoPago.APROBADO);
            pago.setCodigoTransaccion("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
            pago.setFechaPago(LocalDateTime.now());
            log.info("Pago aprobado - transacción: {}", pago.getCodigoTransaccion());

            // Notificar al pedido via Feign
            try {
                pedidoFeignClient.actualizarEstado(request.getPedidoId(), "CONFIRMADO");
                log.info("Pedido {} confirmado tras pago exitoso", request.getPedidoId());
            } catch (Exception e) {
                log.warn("No se pudo actualizar estado del pedido: {}", e.getMessage());
            }
        } else {
            pago.setEstado(Pago.EstadoPago.RECHAZADO);
            log.warn("Pago rechazado para pedidoId: {}", request.getPedidoId());
        }

        Pago guardado = pagoRepository.save(pago);

        if (!aprobado) {
            throw new PagoRechazadoException("El pago fue rechazado por la entidad financiera");
        }
        return mapear(guardado);
    }

    @Transactional(readOnly = true)
    public PagoDTO.Response obtenerPorId(Long id) {
        return mapear(pagoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pago no encontrado: " + id)));
    }

    @Transactional(readOnly = true)
    public List<PagoDTO.Response> listarPorPedido(Long pedidoId) {
        log.info("Listando pagos del pedido: {}", pedidoId);
        return pagoRepository.findByPedidoId(pedidoId).stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<PagoDTO.Response> listarPorUsuario(Long usuarioId) {
        return pagoRepository.findByUsuarioId(usuarioId).stream().map(this::mapear).collect(Collectors.toList());
    }

    // ===== Métodos personalizados para los reportes con HATEOAS (PagoControllerV2) =====

    // 1. Obtener todos los pagos con un estado específico
    @Transactional(readOnly = true)
    public List<PagoDTO.Response> listarPorEstado(Pago.EstadoPago estado) {
        return pagoRepository.findByEstado(estado).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 2. Obtener todos los pagos creados en una fecha específica (entre el inicio y el fin de ese día)
    @Transactional(readOnly = true)
    public List<PagoDTO.Response> listarPorFecha(LocalDate fecha) {
        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.atTime(LocalTime.MAX);
        return pagoRepository.findByFechaCreacionBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 3. Obtener todos los pagos creados entre dos fechas
    @Transactional(readOnly = true)
    public List<PagoDTO.Response> listarEntreFechas(LocalDateTime inicio, LocalDateTime fin) {
        return pagoRepository.findByFechaCreacionBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 4. Obtener el total de pagos realizados por un usuario
    @Transactional(readOnly = true)
    public long contarPorUsuario(Long usuarioId) {
        return pagoRepository.countByUsuarioId(usuarioId);
    }

    /**
     * Verifica si un pago existe (usado por otros microservicios, mismo patrón
     * que ProductoService.existeProducto / UsuarioService.existeUsuario)
     */
    public boolean existePago(Long id) {
        boolean existe = pagoRepository.existsById(id);
        log.debug("Verificación de existencia para pago ID {}: {}", id, existe);
        return existe;
    }

    /* ===== Ejercicios para el estudiante (mismo patrón que ReservaControllerV2 de la guía) =====
       1. Obtener todos los pagos de un usuario en un estado específico
       2. Obtener todos los pagos de un pedido en un estado específico
       3. Obtener todos los pagos de un usuario entre dos fechas
       4. Obtener todos los pagos de un pedido entre dos fechas
       5. Obtener el total de pagos realizados con un método de pago específico
       Pista: agrega los métodos derivados en PagoRepository (ej. findByUsuarioIdAndEstado,
       countByMetodoPago) y expón los endpoints correspondientes en PagoControllerV2. */

    @Transactional
    public PagoDTO.Response reembolsar(Long id) {
        log.info("Procesando reembolso del pago: {}", id);
        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pago no encontrado: " + id));
        if (pago.getEstado() != Pago.EstadoPago.APROBADO) {
            throw new PagoRechazadoException("Solo se pueden reembolsar pagos aprobados");
        }
        pago.setEstado(Pago.EstadoPago.REEMBOLSADO);
        log.info("Reembolso procesado para pago: {}", id);
        return mapear(pagoRepository.save(pago));
    }

    // Simulación de aprobación (90% de probabilidad de éxito)
    private boolean simularProcesamiento(Pago.MetodoPago metodo) {
        return Math.random() > 0.1;
    }

    private PagoDTO.Response mapear(Pago p) {
        PagoDTO.Response r = new PagoDTO.Response();
        r.setId(p.getId()); r.setPedidoId(p.getPedidoId()); r.setUsuarioId(p.getUsuarioId());
        r.setMonto(p.getMonto()); r.setMetodoPago(p.getMetodoPago()); r.setEstado(p.getEstado());
        r.setCodigoTransaccion(p.getCodigoTransaccion()); r.setFechaPago(p.getFechaPago());
        r.setFechaCreacion(p.getFechaCreacion());
        return r;
    }
}
