package com.ecommerce.pagos.exception;
public class PagoRechazadoException extends RuntimeException {
    public PagoRechazadoException(String m) { super(m); }
}
