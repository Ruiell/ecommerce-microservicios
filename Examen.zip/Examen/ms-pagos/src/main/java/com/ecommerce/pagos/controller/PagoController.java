package com.ecommerce.pagos.controller;
import com.ecommerce.pagos.dto.PagoDTO;
import com.ecommerce.pagos.service.PagoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/pagos") @RequiredArgsConstructor
@Tag(name = "Pagos", description = "Operaciones relacionadas con el procesamiento de pagos")
public class PagoController {
    private static final Logger log = LoggerFactory.getLogger(PagoController.class);
    private final PagoService pagoService;

    @PostMapping
    @Operation(summary = "Procesar un nuevo pago", description = "Recibe los datos de un pedido y simula el procesamiento del pago con la entidad financiera")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Pago aprobado",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = PagoDTO.Response.class))),
            @ApiResponse(responseCode = "402", description = "Pago rechazado por la entidad financiera"),
            @ApiResponse(responseCode = "400", description = "Datos de la solicitud inválidos")
    })
    public ResponseEntity<PagoDTO.Response> procesarPago(@Valid @RequestBody PagoDTO.Request request) {
        log.info("POST /api/pagos - pedidoId: {}", request.getPedidoId());
        return ResponseEntity.status(HttpStatus.CREATED).body(pagoService.procesarPago(request));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un pago por id", description = "Obtiene los datos de un pago a partir de su identificador")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pago encontrado"),
            @ApiResponse(responseCode = "404", description = "Pago no encontrado")
    })
    public ResponseEntity<PagoDTO.Response> obtener(
            @Parameter(description = "Id del pago", required = true) @PathVariable Long id) {
        log.info("GET /api/pagos/{}", id); return ResponseEntity.ok(pagoService.obtenerPorId(id));
    }

    @GetMapping("/pedido/{pedidoId}")
    @Operation(summary = "Listar pagos de un pedido", description = "Obtiene todos los pagos asociados a un pedido específico")
    public ResponseEntity<List<PagoDTO.Response>> listarPorPedido(
            @Parameter(description = "Id del pedido", required = true) @PathVariable Long pedidoId) {
        log.info("GET /api/pagos/pedido/{}", pedidoId); return ResponseEntity.ok(pagoService.listarPorPedido(pedidoId));
    }

    @GetMapping("/usuario/{usuarioId}")
    @Operation(summary = "Listar pagos de un usuario", description = "Obtiene todos los pagos realizados por un usuario específico")
    public ResponseEntity<List<PagoDTO.Response>> listarPorUsuario(
            @Parameter(description = "Id del usuario", required = true) @PathVariable Long usuarioId) {
        return ResponseEntity.ok(pagoService.listarPorUsuario(usuarioId));
    }

    @PostMapping("/{id}/reembolsar")
    @Operation(summary = "Reembolsar un pago", description = "Reembolsa un pago que se encuentre en estado APROBADO")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pago reembolsado exitosamente"),
            @ApiResponse(responseCode = "402", description = "El pago no está en estado APROBADO"),
            @ApiResponse(responseCode = "404", description = "Pago no encontrado")
    })
    public ResponseEntity<PagoDTO.Response> reembolsar(
            @Parameter(description = "Id del pago", required = true) @PathVariable Long id) {
        log.info("POST /api/pagos/{}/reembolsar", id); return ResponseEntity.ok(pagoService.reembolsar(id));
    }

    @GetMapping("/{id}/existe")
    @Operation(summary = "Verificar si un pago existe",
            description = "Endpoint interno usado por otros microservicios para validar referencias")
    public ResponseEntity<Map<String, Boolean>> verificarExistencia(
            @Parameter(description = "Id del pago", required = true) @PathVariable Long id) {
        log.info("GET /api/pagos/{}/existe", id);
        return ResponseEntity.ok(Map.of("existe", pagoService.existePago(id)));
    }
}
