package com.ecommerce.pagos.exception;
public class PagoNoEncontradoException extends RuntimeException {
    public PagoNoEncontradoException(String msg) { super(msg); }
}
