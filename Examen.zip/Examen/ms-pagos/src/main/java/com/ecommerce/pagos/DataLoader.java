package com.ecommerce.pagos;

import com.ecommerce.pagos.model.Pago;
import com.ecommerce.pagos.repository.PagoRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Profile({"dev", "render"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private PagoRepository pagoRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

        // Métodos y estados disponibles (tomados directamente del enum del modelo)
        Pago.MetodoPago[] metodos = Pago.MetodoPago.values();
        Pago.EstadoPago[] estados = Pago.EstadoPago.values();

        // Generar pagos de ejemplo
        for (int i = 0; i < 20; i++) {
            Pago pago = new Pago();

            // Simulan referencias a otros microservicios (pedidos / usuarios)
            pago.setPedidoId((long) faker.number().numberBetween(1, 50));
            pago.setUsuarioId((long) faker.number().numberBetween(1, 50));

            // Monto entre 1.000 y 500.000, con 2 decimales
            pago.setMonto(BigDecimal.valueOf(faker.number().randomDouble(2, 1000, 500000)));

            pago.setMetodoPago(metodos[random.nextInt(metodos.length)]);

            Pago.EstadoPago estado = estados[random.nextInt(estados.length)];
            pago.setEstado(estado);

            // Solo los pagos aprobados o reembolsados tienen código de transacción y fecha de pago
            if (estado == Pago.EstadoPago.APROBADO || estado == Pago.EstadoPago.REEMBOLSADO) {
                pago.setCodigoTransaccion("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
                pago.setFechaPago(LocalDateTime.now().minusDays(faker.number().numberBetween(0, 15)));
            }

            pagoRepository.save(pago);
        }

        List<Pago> pagos = pagoRepository.findAll();
        System.out.println("DataLoader: se generaron " + pagos.size() + " pagos de ejemplo.");
    }
}
