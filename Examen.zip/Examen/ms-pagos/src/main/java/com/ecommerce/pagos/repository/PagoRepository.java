package com.ecommerce.pagos.repository;
import com.ecommerce.pagos.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.*;
@Repository
public interface PagoRepository extends JpaRepository<Pago, Long> {
    List<Pago> findByPedidoId(Long pedidoId);
    List<Pago> findByUsuarioId(Long usuarioId);
    Optional<Pago> findByCodigoTransaccion(String codigo);

    // Métodos personalizados para los reportes con HATEOAS (PagoControllerV2)
    List<Pago> findByEstado(Pago.EstadoPago estado);
    List<Pago> findByFechaCreacionBetween(LocalDateTime inicio, LocalDateTime fin);
    long countByUsuarioId(Long usuarioId);
}
