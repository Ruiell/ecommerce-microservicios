package com.ecommerce.pagos.dto;
import com.ecommerce.pagos.model.Pago.*;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Schema(description = "Datos de entrada y salida para el procesamiento de pagos")
public class PagoDTO {
    @Data @NoArgsConstructor @AllArgsConstructor
    @Schema(description = "Datos requeridos para procesar un nuevo pago")
    public static class Request {
        @Schema(description = "Id del pedido asociado", example = "1")
        @NotNull private Long pedidoId;

        @Schema(description = "Id del usuario que realiza el pago", example = "1")
        @NotNull private Long usuarioId;

        @Schema(description = "Monto a pagar", example = "15000.00")
        @NotNull @DecimalMin("0.01") private BigDecimal monto;

        @Schema(description = "Método de pago utilizado")
        @NotNull private MetodoPago metodoPago;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    @Schema(description = "Representación de un pago ya procesado")
    public static class Response {
        @Schema(description = "Id del pago", example = "1")
        private Long id;
        @Schema(description = "Id del pedido asociado", example = "1")
        private Long pedidoId;
        @Schema(description = "Id del usuario que realizó el pago", example = "1")
        private Long usuarioId;
        @Schema(description = "Monto pagado", example = "15000.00")
        private BigDecimal monto;
        @Schema(description = "Método de pago utilizado")
        private MetodoPago metodoPago;
        @Schema(description = "Estado actual del pago")
        private EstadoPago estado;
        @Schema(description = "Código único de la transacción aprobada", example = "TXN-ABCD1234")
        private String codigoTransaccion;
        @Schema(description = "Fecha y hora en que el pago fue aprobado")
        private LocalDateTime fechaPago;
        @Schema(description = "Fecha y hora de creación del registro")
        private LocalDateTime fechaCreacion;
    }
}
