/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_envios
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_envios;

/* ============================================================
   2. Tabla envios
   ============================================================ */
CREATE TABLE envios (
    id                       BIGINT       NOT NULL AUTO_INCREMENT,
    pedido_id                BIGINT       NOT NULL,
    numero_seguimiento       VARCHAR(30)  NULL,
    estado                   VARCHAR(20)  NOT NULL DEFAULT 'PREPARANDO',
    direccion_destino        VARCHAR(300) NOT NULL,
    transportista            VARCHAR(100) NULL,
    fecha_estimada_entrega   DATE         NULL,
    fecha_entrega_real       DATETIME     NULL,
    fecha_creacion           DATETIME     NOT NULL,
    CONSTRAINT envios_PK PRIMARY KEY (id),
    CONSTRAINT envios_pedido_UN UNIQUE (pedido_id),
    CONSTRAINT envios_seguimiento_UN UNIQUE (numero_seguimiento),
    CONSTRAINT chk_envios_estado
        CHECK (estado IN ('PREPARANDO','EN_TRANSITO','EN_REPARTO','ENTREGADO','DEVUELTO'))
) ENGINE = InnoDB;

/* ============================================================
   ¡Todo listo!
   ============================================================ */
