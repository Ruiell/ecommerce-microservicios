package com.ecommerce.envios.service;

import com.ecommerce.envios.dto.EnvioDTO;
import com.ecommerce.envios.exception.RecursoNoEncontradoException;
import com.ecommerce.envios.model.Envio;
import com.ecommerce.envios.repository.EnvioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EnvioServiceTest {

    @Mock
    private EnvioRepository envioRepository;

    @InjectMocks
    private EnvioService envioService;

    private Envio crearEnvioDePrueba() {
        Envio e = new Envio();
        e.setId(1L);
        e.setPedidoId(100L);
        e.setNumeroSeguimiento("ENV-ABC12345");
        e.setEstado(Envio.EstadoEnvio.PREPARANDO);
        e.setDireccionDestino("Av. Siempre Viva 123");
        return e;
    }

    @Test
    void testCrearEnvio() {
        when(envioRepository.existsByPedidoId(100L)).thenReturn(false);
        when(envioRepository.save(any(Envio.class))).thenReturn(crearEnvioDePrueba());

        EnvioDTO.Request request = new EnvioDTO.Request();
        request.setPedidoId(100L);
        request.setDireccionDestino("Av. Siempre Viva 123");

        EnvioDTO.Response respuesta = envioService.crearEnvio(request);

        assertNotNull(respuesta);
        assertEquals(Envio.EstadoEnvio.PREPARANDO, respuesta.getEstado());
    }

    @Test
    void testCrearEnvio_YaExiste() {
        when(envioRepository.existsByPedidoId(100L)).thenReturn(true);

        EnvioDTO.Request request = new EnvioDTO.Request();
        request.setPedidoId(100L);
        request.setDireccionDestino("Av. Siempre Viva 123");

        assertThrows(IllegalStateException.class, () -> envioService.crearEnvio(request));
    }

    @Test
    void testObtenerPorSeguimiento_NoEncontrado() {
        when(envioRepository.findByNumeroSeguimiento("ENV-NOEXISTE")).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class,
                () -> envioService.obtenerPorSeguimiento("ENV-NOEXISTE"));
    }

    @Test
    void testActualizarEstado_Entregado() {
        Envio envio = crearEnvioDePrueba();
        when(envioRepository.findById(1L)).thenReturn(Optional.of(envio));
        when(envioRepository.save(any(Envio.class))).thenReturn(envio);

        EnvioDTO.Response resultado = envioService.actualizarEstado(1L, "ENTREGADO");

        assertEquals(Envio.EstadoEnvio.ENTREGADO, resultado.getEstado());
        assertNotNull(resultado.getFechaEntregaReal());
    }

    @Test
    void testObtenerPorPedido_NoEncontrado() {
        when(envioRepository.findByPedidoId(999L)).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> envioService.obtenerPorPedido(999L));
    }

    @Test
    void testExisteEnvio() {
        when(envioRepository.existsById(1L)).thenReturn(true);

        assertTrue(envioService.existeEnvio(1L));
    }

    @Test
    void testListarPorEstado() {
        when(envioRepository.findByEstado(Envio.EstadoEnvio.PREPARANDO))
                .thenReturn(java.util.List.of(crearEnvioDePrueba()));

        var envios = envioService.listarPorEstado(Envio.EstadoEnvio.PREPARANDO);

        assertEquals(1, envios.size());
    }

    @Test
    void testContarPorEstado() {
        when(envioRepository.countByEstado(Envio.EstadoEnvio.ENTREGADO)).thenReturn(4L);

        long total = envioService.contarPorEstado(Envio.EstadoEnvio.ENTREGADO);

        assertEquals(4L, total);
    }
}
