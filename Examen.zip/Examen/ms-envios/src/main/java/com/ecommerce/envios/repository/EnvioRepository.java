package com.ecommerce.envios.repository;
import com.ecommerce.envios.model.Envio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Repository
public interface EnvioRepository extends JpaRepository<Envio, Long> {
    Optional<Envio> findByPedidoId(Long pedidoId);
    Optional<Envio> findByNumeroSeguimiento(String numeroSeguimiento);
    boolean existsByPedidoId(Long pedidoId);

    // Métodos personalizados para los reportes con HATEOAS (EnvioControllerV2)
    List<Envio> findByEstado(Envio.EstadoEnvio estado);
    List<Envio> findByFechaCreacionBetween(LocalDateTime inicio, LocalDateTime fin);
    long countByEstado(Envio.EstadoEnvio estado);
}
