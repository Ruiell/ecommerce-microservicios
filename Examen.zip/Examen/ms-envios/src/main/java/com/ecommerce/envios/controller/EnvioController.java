package com.ecommerce.envios.controller;
import com.ecommerce.envios.dto.EnvioDTO;
import com.ecommerce.envios.service.EnvioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/envios") @RequiredArgsConstructor
public class EnvioController {
    private static final Logger log = LoggerFactory.getLogger(EnvioController.class);
    private final EnvioService envioService;

    @GetMapping
    public ResponseEntity<List<EnvioDTO.Response>> listar() {
        log.info("GET /api/envios"); return ResponseEntity.ok(envioService.listarTodos());
    }
    @PostMapping
    public ResponseEntity<EnvioDTO.Response> crear(@Valid @RequestBody EnvioDTO.Request request) {
        log.info("POST /api/envios - pedidoId: {}", request.getPedidoId());
        return ResponseEntity.status(HttpStatus.CREATED).body(envioService.crearEnvio(request));
    }
    @GetMapping("/seguimiento/{numero}")
    public ResponseEntity<EnvioDTO.Response> obtenerPorSeguimiento(@PathVariable String numero) {
        log.info("GET /api/envios/seguimiento/{}", numero);
        return ResponseEntity.ok(envioService.obtenerPorSeguimiento(numero));
    }
    @GetMapping("/pedido/{pedidoId}")
    public ResponseEntity<EnvioDTO.Response> obtenerPorPedido(@PathVariable Long pedidoId) {
        return ResponseEntity.ok(envioService.obtenerPorPedido(pedidoId));
    }
    @PatchMapping("/{id}/estado")
    public ResponseEntity<EnvioDTO.Response> actualizarEstado(@PathVariable Long id, @RequestParam String estado) {
        log.info("PATCH /api/envios/{}/estado -> {}", id, estado);
        return ResponseEntity.ok(envioService.actualizarEstado(id, estado));
    }
    @GetMapping("/{id}/existe")
    public ResponseEntity<Map<String,Boolean>> existe(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("existe", envioService.existeEnvio(id)));
    }
}
