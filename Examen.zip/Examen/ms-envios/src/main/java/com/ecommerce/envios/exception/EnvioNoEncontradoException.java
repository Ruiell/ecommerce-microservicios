package com.ecommerce.envios.exception;
public class EnvioNoEncontradoException extends RuntimeException {
    public EnvioNoEncontradoException(String msg) { super(msg); }
}
