package com.ecommerce.envios;

import com.ecommerce.envios.model.Envio;
import com.ecommerce.envios.model.Envio.EstadoEnvio;
import com.ecommerce.envios.repository.EnvioRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Random;

@Profile({"dev", "render", "aiven"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private EnvioRepository envioRepository;

    @Override
    public void run(String... args) throws Exception {
        if (envioRepository.count() > 0) {
            return;
        }

        Faker faker = new Faker();
        Random random = new Random();
        String[] transportistas = {"Chilexpress", "Starken", "Correos de Chile", "Blue Express"};
        EstadoEnvio[] estados = EstadoEnvio.values();

        for (long pedidoId = 1; pedidoId <= 25; pedidoId++) {
            Envio envio = new Envio();
            envio.setPedidoId(pedidoId);
            envio.setNumeroSeguimiento(faker.code().isbn10().replace("-", "").toUpperCase());

            EstadoEnvio estado = estados[random.nextInt(estados.length)];
            envio.setEstado(estado);
            envio.setDireccionDestino(faker.address().fullAddress());
            envio.setTransportista(transportistas[random.nextInt(transportistas.length)]);
            envio.setFechaEstimadaEntrega(LocalDate.now().plusDays(faker.number().numberBetween(1, 10)));

            if (estado == EstadoEnvio.ENTREGADO) {
                envio.setFechaEntregaReal(LocalDateTime.now().minusDays(faker.number().numberBetween(0, 5)));
            }

            envioRepository.save(envio);
        }

        System.out.println(">> DataLoader: 25 envios de prueba cargados en ms-envios (perfil dev).");
    }
}
