package com.ecommerce.envios.exception;
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String m) { super(m); }
}
