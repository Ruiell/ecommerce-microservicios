package com.ecommerce.envios.config;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@FeignClient(name = "ms-pedidos-envios", url = "${microservices.pedidos.url}")
public interface PedidoFeignClient {
    @PatchMapping("/api/pedidos/{id}/estado")
    Map<String, Object> actualizarEstado(@PathVariable Long id, @RequestBody Map<String,String> body);
}
