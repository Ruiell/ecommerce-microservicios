package com.ecommerce.envios;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
/** Microservicio de Envíos - Puerto: 8088 */
@SpringBootApplication @EnableFeignClients
public class MsEnviosApplication {
    public static void main(String[] args) { SpringApplication.run(MsEnviosApplication.class, args); }
}
