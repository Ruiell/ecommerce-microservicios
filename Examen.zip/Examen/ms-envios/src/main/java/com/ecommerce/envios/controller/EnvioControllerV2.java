package com.ecommerce.envios.controller;

import com.ecommerce.envios.assemblers.EnvioModelAssembler;
import com.ecommerce.envios.dto.EnvioDTO;
import com.ecommerce.envios.model.Envio;
import com.ecommerce.envios.service.EnvioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de envíos.
 * Las respuestas incluyen enlaces de navegación (self, envioDelPedido).
 * Para la versión sin HATEOAS usar /api/envios (EnvioController).
 */
@RestController
@RequestMapping("/api/v2/envios")
@Tag(name = "Envíos (HATEOAS)", description = "Operaciones sobre envíos con enlaces HATEOAS")
public class EnvioControllerV2 {

    @Autowired
    private EnvioService envioService;

    @Autowired
    private EnvioModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar todos los envíos (HATEOAS)")
    public CollectionModel<EntityModel<EnvioDTO.Response>> listar() {
        List<EntityModel<EnvioDTO.Response>> envios = envioService.listarTodos().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(envios, linkTo(methodOn(EnvioControllerV2.class).listar()).withSelfRel());
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear un nuevo envío (HATEOAS)")
    public ResponseEntity<EntityModel<EnvioDTO.Response>> crear(@Valid @RequestBody EnvioDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(envioService.crearEnvio(request)));
    }

    @GetMapping(value = "/seguimiento/{numero}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un envío por número de seguimiento (HATEOAS)")
    public EntityModel<EnvioDTO.Response> obtenerPorSeguimiento(@PathVariable String numero) {
        return assembler.toModel(envioService.obtenerPorSeguimiento(numero));
    }

    @GetMapping(value = "/pedido/{pedidoId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el envío de un pedido (HATEOAS)")
    public EntityModel<EnvioDTO.Response> obtenerPorPedido(@PathVariable Long pedidoId) {
        return assembler.toModel(envioService.obtenerPorPedido(pedidoId));
    }

    @PatchMapping(value = "/{id}/estado", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar el estado de un envío (HATEOAS)")
    public EntityModel<EnvioDTO.Response> actualizarEstado(@PathVariable Long id, @RequestParam String estado) {
        return assembler.toModel(envioService.actualizarEstado(id, estado));
    }

    // ===== Reportes con HATEOAS (ver EnvioService) =====

    // 1. Obtener todos los envíos en un estado específico
    @GetMapping(value = "/estado/{estado}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar envíos por estado (HATEOAS)",
            description = "Estados válidos: PREPARANDO, EN_TRANSITO, EN_REPARTO, ENTREGADO, DEVUELTO")
    public CollectionModel<EntityModel<EnvioDTO.Response>> listarPorEstado(@PathVariable Envio.EstadoEnvio estado) {
        List<EntityModel<EnvioDTO.Response>> envios = envioService.listarPorEstado(estado).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(envios, linkTo(methodOn(EnvioControllerV2.class).listarPorEstado(estado)).withSelfRel());
    }

    // 2. Obtener todos los envíos creados en una fecha específica (ej: /api/v2/envios/fecha/2026-06-26)
    @GetMapping(value = "/fecha/{fecha}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar envíos creados en una fecha específica (HATEOAS)")
    public CollectionModel<EntityModel<EnvioDTO.Response>> listarPorFecha(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        List<EntityModel<EnvioDTO.Response>> envios = envioService.listarPorFecha(fecha).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(envios, linkTo(methodOn(EnvioControllerV2.class).listarPorFecha(fecha)).withSelfRel());
    }

    // 3. Obtener todos los envíos creados entre dos fechas
    @GetMapping(value = "/rango", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar envíos creados entre dos fechas (HATEOAS)")
    public CollectionModel<EntityModel<EnvioDTO.Response>> listarEntreFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        List<EntityModel<EnvioDTO.Response>> envios = envioService.listarEntreFechas(inicio, fin).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(envios, linkTo(methodOn(EnvioControllerV2.class).listarEntreFechas(inicio, fin)).withSelfRel());
    }

    // 4. Obtener el total de envíos en un estado específico
    @GetMapping(value = "/estado/{estado}/total", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el total de envíos en un estado específico (HATEOAS)")
    public EntityModel<Map<String, Object>> contarPorEstado(@PathVariable Envio.EstadoEnvio estado) {
        long total = envioService.contarPorEstado(estado);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("estado", estado);
        body.put("totalEnvios", total);

        return EntityModel.of(body,
                linkTo(methodOn(EnvioControllerV2.class).contarPorEstado(estado)).withSelfRel(),
                linkTo(methodOn(EnvioControllerV2.class).listarPorEstado(estado)).withRel("enviosEnEseEstado"));
    }
}
