package com.ecommerce.envios.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.envios.controller.EnvioControllerV2;
import com.ecommerce.envios.dto.EnvioDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class EnvioModelAssembler implements RepresentationModelAssembler<EnvioDTO.Response, EntityModel<EnvioDTO.Response>> {

    @Override
    public EntityModel<EnvioDTO.Response> toModel(EnvioDTO.Response envio) {
        return EntityModel.of(envio,
                linkTo(methodOn(EnvioControllerV2.class).obtenerPorSeguimiento(envio.getNumeroSeguimiento())).withSelfRel(),
                linkTo(methodOn(EnvioControllerV2.class).obtenerPorPedido(envio.getPedidoId())).withRel("envioDelPedido"));
    }
}
