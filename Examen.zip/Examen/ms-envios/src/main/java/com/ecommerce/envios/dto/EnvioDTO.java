package com.ecommerce.envios.dto;
import com.ecommerce.envios.model.Envio.EstadoEnvio;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class EnvioDTO {
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Request {
        @NotNull private Long pedidoId;
        @NotBlank private String direccionDestino;
        private String transportista;
        private LocalDate fechaEstimadaEntrega;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id; private Long pedidoId; private String numeroSeguimiento;
        private EstadoEnvio estado; private String direccionDestino;
        private String transportista; private LocalDate fechaEstimadaEntrega;
        private LocalDateTime fechaEntregaReal; private LocalDateTime fechaCreacion;
    }
}
