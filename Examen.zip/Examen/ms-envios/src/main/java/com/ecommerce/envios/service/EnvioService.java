package com.ecommerce.envios.service;
import com.ecommerce.envios.dto.EnvioDTO;
import com.ecommerce.envios.exception.RecursoNoEncontradoException;
import com.ecommerce.envios.model.Envio;
import com.ecommerce.envios.repository.EnvioRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate; import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor
public class EnvioService {
    private static final Logger log = LoggerFactory.getLogger(EnvioService.class);
    private final EnvioRepository envioRepository;

    @Transactional
    public EnvioDTO.Response crearEnvio(EnvioDTO.Request request) {
        log.info("Creando envío para pedidoId: {}", request.getPedidoId());
        if (envioRepository.existsByPedidoId(request.getPedidoId())) {
            throw new IllegalStateException("Ya existe envío para el pedido: " + request.getPedidoId());
        }
        Envio envio = new Envio();
        envio.setPedidoId(request.getPedidoId());
        envio.setNumeroSeguimiento("ENV-" + UUID.randomUUID().toString().substring(0,8).toUpperCase());
        envio.setDireccionDestino(request.getDireccionDestino());
        envio.setTransportista(request.getTransportista() != null ? request.getTransportista() : "Correos Chile");
        envio.setFechaEstimadaEntrega(request.getFechaEstimadaEntrega() != null ? request.getFechaEstimadaEntrega() : LocalDate.now().plusDays(5));
        envio.setEstado(Envio.EstadoEnvio.PREPARANDO);
        Envio guardado = envioRepository.save(envio);
        log.info("Envío creado: {} - seguimiento: {}", guardado.getId(), guardado.getNumeroSeguimiento());
        return mapear(guardado);
    }

    @Transactional(readOnly = true)
    public EnvioDTO.Response obtenerPorSeguimiento(String numeroSeguimiento) {
        log.info("Buscando envío por seguimiento: {}", numeroSeguimiento);
        return mapear(envioRepository.findByNumeroSeguimiento(numeroSeguimiento)
                .orElseThrow(() -> new RecursoNoEncontradoException("Envío no encontrado: " + numeroSeguimiento)));
    }

    @Transactional(readOnly = true)
    public EnvioDTO.Response obtenerPorPedido(Long pedidoId) {
        return mapear(envioRepository.findByPedidoId(pedidoId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Envío no encontrado para pedido: " + pedidoId)));
    }

    @Transactional
    public EnvioDTO.Response actualizarEstado(Long id, String nuevoEstado) {
        log.info("Actualizando estado envío {} a {}", id, nuevoEstado);
        Envio envio = envioRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Envío no encontrado: " + id));
        Envio.EstadoEnvio estado = Envio.EstadoEnvio.valueOf(nuevoEstado.toUpperCase());
        envio.setEstado(estado);
        if (estado == Envio.EstadoEnvio.ENTREGADO) { envio.setFechaEntregaReal(LocalDateTime.now()); }
        return mapear(envioRepository.save(envio));
    }

    @Transactional(readOnly = true)
    public List<EnvioDTO.Response> listarTodos() {
        return envioRepository.findAll().stream().map(this::mapear).collect(Collectors.toList());
    }

    /**
     * Verifica si un envío existe (usado por otros microservicios, mismo patrón
     * que ProductoService.existeProducto / UsuarioService.existeUsuario)
     */
    public boolean existeEnvio(Long id) {
        boolean existe = envioRepository.existsById(id);
        log.debug("Verificación de existencia para envío ID {}: {}", id, existe);
        return existe;
    }

    // ===== Reportes con HATEOAS (mismo patrón que PagoService/PedidoService) =====

    // 1. Obtener todos los envíos en un estado específico
    @Transactional(readOnly = true)
    public List<EnvioDTO.Response> listarPorEstado(Envio.EstadoEnvio estado) {
        return envioRepository.findByEstado(estado).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 2. Obtener todos los envíos creados en una fecha específica (entre el inicio y el fin de ese día)
    @Transactional(readOnly = true)
    public List<EnvioDTO.Response> listarPorFecha(LocalDate fecha) {
        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.atTime(java.time.LocalTime.MAX);
        return envioRepository.findByFechaCreacionBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 3. Obtener todos los envíos creados entre dos fechas
    @Transactional(readOnly = true)
    public List<EnvioDTO.Response> listarEntreFechas(LocalDateTime inicio, LocalDateTime fin) {
        return envioRepository.findByFechaCreacionBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 4. Obtener el total de envíos en un estado específico
    @Transactional(readOnly = true)
    public long contarPorEstado(Envio.EstadoEnvio estado) {
        return envioRepository.countByEstado(estado);
    }

    private EnvioDTO.Response mapear(Envio e) {
        EnvioDTO.Response r = new EnvioDTO.Response();
        r.setId(e.getId()); r.setPedidoId(e.getPedidoId()); r.setNumeroSeguimiento(e.getNumeroSeguimiento());
        r.setEstado(e.getEstado()); r.setDireccionDestino(e.getDireccionDestino());
        r.setTransportista(e.getTransportista()); r.setFechaEstimadaEntrega(e.getFechaEstimadaEntrega());
        r.setFechaEntregaReal(e.getFechaEntregaReal()); r.setFechaCreacion(e.getFechaCreacion());
        return r;
    }
}
