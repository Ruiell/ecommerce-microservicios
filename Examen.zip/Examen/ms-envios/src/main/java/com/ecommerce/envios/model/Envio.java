package com.ecommerce.envios.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity @Table(name = "envios") @Data @NoArgsConstructor @AllArgsConstructor
public class Envio {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "pedido_id", nullable = false, unique = true) private Long pedidoId;
    @Column(name = "numero_seguimiento", unique = true) private String numeroSeguimiento;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private EstadoEnvio estado = EstadoEnvio.PREPARANDO;
    @Column(name = "direccion_destino", nullable = false, length = 300) private String direccionDestino;
    @Column(name = "transportista", length = 100) private String transportista;
    @Column(name = "fecha_estimada_entrega") private LocalDate fechaEstimadaEntrega;
    @Column(name = "fecha_entrega_real") private LocalDateTime fechaEntregaReal;
    @Column(name = "fecha_creacion", updatable = false) private LocalDateTime fechaCreacion;
    @PrePersist protected void onCreate() { fechaCreacion = LocalDateTime.now(); }
    public enum EstadoEnvio { PREPARANDO, EN_TRANSITO, EN_REPARTO, ENTREGADO, DEVUELTO }
}
