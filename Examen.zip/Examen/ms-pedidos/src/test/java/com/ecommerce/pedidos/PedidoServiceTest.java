package com.ecommerce.pedidos;

import com.ecommerce.pedidos.config.UsuarioFeignClient;
import com.ecommerce.pedidos.dto.PedidoDTO;
import com.ecommerce.pedidos.exception.EstadoInvalidoException;
import com.ecommerce.pedidos.exception.RecursoNoEncontradoException;
import com.ecommerce.pedidos.model.Pedido;
import com.ecommerce.pedidos.repository.PedidoRepository;
import com.ecommerce.pedidos.service.PedidoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ActiveProfiles("test")
public class PedidoServiceTest {

    // Inyecta el servicio de Pedido para ser probado.
    @Autowired
    private PedidoService pedidoService;

    // Crea un mock del repositorio de Pedido para simular su comportamiento.
    @MockBean
    private PedidoRepository pedidoRepository;

    // Crea un mock del Feign Client hacia ms-usuarios para no depender de ese microservicio.
    @MockBean
    private UsuarioFeignClient usuarioFeignClient;

    // Crea un mock del WebClient.Builder hacia ms-inventario. Al quedar sin stub, build() devuelve
    // null y el descuento de stock cae en el catch genérico del servicio (es "best effort" por diseño).
    @MockBean
    private WebClient.Builder webClientBuilder;

    @Test
    public void testCrearPedido_GuardaConDatosCorrectosYCalculaTotal() {
        PedidoDTO.ItemRequest item1 = new PedidoDTO.ItemRequest(1L, 2, BigDecimal.valueOf(10000), "Producto A");
        PedidoDTO.ItemRequest item2 = new PedidoDTO.ItemRequest(2L, 3, BigDecimal.valueOf(5000), "Producto B");
        PedidoDTO.Request request = new PedidoDTO.Request(1L, List.of(item1, item2), "Av. Siempre Viva 742");

        when(usuarioFeignClient.verificarExistencia(1L)).thenReturn(Map.of("existe", true));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PedidoDTO.Response response = pedidoService.crearPedido(request);

        assertNotNull(response);
        assertEquals(1L, response.getUsuarioId());
        assertEquals(2, response.getItems().size());
        // total = (2 x 10000) + (3 x 5000) = 35000
        assertEquals(BigDecimal.valueOf(35000), response.getTotal());
        verify(pedidoRepository, times(1)).save(any(Pedido.class));
    }

    @Test
    public void testCrearPedido_UsuarioNoExiste_LanzaExcepcion() {
        PedidoDTO.ItemRequest item = new PedidoDTO.ItemRequest(1L, 1, BigDecimal.valueOf(1000), "Producto A");
        PedidoDTO.Request request = new PedidoDTO.Request(99L, List.of(item), "Dirección X");

        when(usuarioFeignClient.verificarExistencia(99L)).thenReturn(Map.of("existe", false));

        assertThrows(RecursoNoEncontradoException.class, () -> pedidoService.crearPedido(request));
    }

    @Test
    public void testObtenerPorId() {
        Long id = 1L;
        Pedido pedido = crearPedidoPendiente(id);

        when(pedidoRepository.findById(id)).thenReturn(Optional.of(pedido));

        PedidoDTO.Response response = pedidoService.obtenerPorId(id);

        assertNotNull(response);
        assertEquals(id, response.getId());
    }

    @Test
    public void testObtenerPorId_NoEncontrado_LanzaExcepcion() {
        Long id = 99L;

        when(pedidoRepository.findById(id)).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> pedidoService.obtenerPorId(id));
    }

    @Test
    public void testListarPorUsuario() {
        Long usuarioId = 5L;
        when(pedidoRepository.findByUsuarioId(usuarioId)).thenReturn(List.of(crearPedidoPendiente(1L)));

        List<PedidoDTO.Response> pedidos = pedidoService.listarPorUsuario(usuarioId);

        assertNotNull(pedidos);
        assertEquals(1, pedidos.size());
    }

    @Test
    public void testListarTodos() {
        when(pedidoRepository.findAll()).thenReturn(List.of(crearPedidoPendiente(1L), crearPedidoPendiente(2L)));

        List<PedidoDTO.Response> pedidos = pedidoService.listarTodos();

        assertNotNull(pedidos);
        assertEquals(2, pedidos.size());
    }

    @Test
    public void testActualizarEstado_TransicionValida() {
        Long id = 1L;
        Pedido pedido = crearPedidoPendiente(id); // arranca en PENDIENTE

        when(pedidoRepository.findById(id)).thenReturn(Optional.of(pedido));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PedidoDTO.Response response = pedidoService.actualizarEstado(id, "CONFIRMADO");

        assertEquals(Pedido.EstadoPedido.CONFIRMADO, response.getEstado());
    }

    @Test
    public void testActualizarEstado_EstadoInvalido_LanzaExcepcion() {
        Long id = 1L;
        Pedido pedido = crearPedidoPendiente(id);

        when(pedidoRepository.findById(id)).thenReturn(Optional.of(pedido));

        assertThrows(EstadoInvalidoException.class, () -> pedidoService.actualizarEstado(id, "ESTADO_QUE_NO_EXISTE"));
    }

    @Test
    public void testActualizarEstado_PedidoEntregado_NoPermiteCambio() {
        Long id = 1L;
        Pedido pedido = crearPedidoPendiente(id);
        pedido.setEstado(Pedido.EstadoPedido.ENTREGADO);

        when(pedidoRepository.findById(id)).thenReturn(Optional.of(pedido));

        // Un pedido ENTREGADO (o CANCELADO) no puede cambiar de estado.
        assertThrows(EstadoInvalidoException.class, () -> pedidoService.actualizarEstado(id, "CANCELADO"));
    }

    // ===== Tests de los reportes con HATEOAS (ver PedidoService) =====

    @Test
    public void testListarPorEstado() {
        when(pedidoRepository.findByEstado(Pedido.EstadoPedido.CONFIRMADO))
                .thenReturn(List.of(crearPedidoPendiente(1L)));

        List<PedidoDTO.Response> pedidos = pedidoService.listarPorEstado(Pedido.EstadoPedido.CONFIRMADO);

        assertNotNull(pedidos);
        assertEquals(1, pedidos.size());
    }

    @Test
    public void testListarPorFecha() {
        LocalDate fecha = LocalDate.of(2026, 6, 26);
        // El servicio debe traducir la fecha al rango [00:00:00, 23:59:59.999999999] de ese día
        LocalDateTime inicioEsperado = fecha.atStartOfDay();
        LocalDateTime finEsperado = fecha.atTime(LocalTime.MAX);

        when(pedidoRepository.findByFechaPedidoBetween(inicioEsperado, finEsperado))
                .thenReturn(List.of(crearPedidoPendiente(1L)));

        List<PedidoDTO.Response> pedidos = pedidoService.listarPorFecha(fecha);

        assertNotNull(pedidos);
        assertEquals(1, pedidos.size());
        // Confirma que el servicio calculó exactamente ese rango (y no otro) al consultar el repositorio
        verify(pedidoRepository, times(1)).findByFechaPedidoBetween(inicioEsperado, finEsperado);
    }

    @Test
    public void testListarEntreFechas() {
        LocalDateTime inicio = LocalDateTime.of(2026, 6, 1, 0, 0);
        LocalDateTime fin = LocalDateTime.of(2026, 6, 26, 23, 59, 59);

        when(pedidoRepository.findByFechaPedidoBetween(inicio, fin))
                .thenReturn(List.of(crearPedidoPendiente(1L), crearPedidoPendiente(2L)));

        List<PedidoDTO.Response> pedidos = pedidoService.listarEntreFechas(inicio, fin);

        assertNotNull(pedidos);
        assertEquals(2, pedidos.size());
    }

    @Test
    public void testContarPorUsuario() {
        Long usuarioId = 3L;
        when(pedidoRepository.countByUsuarioId(usuarioId)).thenReturn(5L);

        long total = pedidoService.contarPorUsuario(usuarioId);

        assertEquals(5L, total);
    }

    @Test
    public void testExistePedido_Existe() {
        Long id = 1L;
        when(pedidoRepository.existsById(id)).thenReturn(true);

        boolean existe = pedidoService.existePedido(id);

        assertTrue(existe);
        verify(pedidoRepository).existsById(id);
    }

    @Test
    public void testExistePedido_NoExiste() {
        Long id = 99L;
        when(pedidoRepository.existsById(id)).thenReturn(false);

        boolean existe = pedidoService.existePedido(id);

        assertFalse(existe);
    }

    private Pedido crearPedidoPendiente(Long id) {
        Pedido pedido = new Pedido();
        pedido.setId(id);
        pedido.setUsuarioId(1L);
        pedido.setNumeroPedido("PED-TEST-" + id);
        pedido.setEstado(Pedido.EstadoPedido.PENDIENTE);
        pedido.setTotal(BigDecimal.valueOf(10000));
        pedido.setDireccionEnvio("Dirección de prueba");
        pedido.setItems(new ArrayList<>());
        pedido.setFechaPedido(LocalDateTime.now());
        return pedido;
    }
}
