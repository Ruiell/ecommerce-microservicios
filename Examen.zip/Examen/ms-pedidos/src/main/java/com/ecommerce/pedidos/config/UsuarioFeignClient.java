package com.ecommerce.pedidos.config;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
/** Feign Client - Valida usuario en ms-usuarios */
@FeignClient(name = "ms-usuarios", url = "${microservices.usuarios.url}")
public interface UsuarioFeignClient {
    @GetMapping("/api/usuarios/{id}/existe")
    Map<String,Boolean> verificarExistencia(@PathVariable Long id);
}
