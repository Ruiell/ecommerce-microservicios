package com.ecommerce.pedidos.exception;
public class EstadoInvalidoException extends RuntimeException {
    public EstadoInvalidoException(String m) { super(m); }
}
