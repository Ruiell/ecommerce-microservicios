package com.ecommerce.pedidos;

import com.ecommerce.pedidos.model.ItemPedido;
import com.ecommerce.pedidos.model.Pedido;
import com.ecommerce.pedidos.repository.PedidoRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Profile({"dev", "render"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

        Pedido.EstadoPedido[] estados = Pedido.EstadoPedido.values();

        // Generar pedidos de ejemplo, cada uno con 1 a 4 items
        for (int i = 0; i < 20; i++) {
            Pedido pedido = new Pedido();

            // Simula referencia al usuario que hizo el pedido (otro microservicio)
            pedido.setUsuarioId((long) faker.number().numberBetween(1, 50));
            pedido.setNumeroPedido("PED-" + System.currentTimeMillis() + "-" + i);
            pedido.setDireccionEnvio(faker.address().fullAddress());
            pedido.setEstado(estados[random.nextInt(estados.length)]);

            int cantidadItems = faker.number().numberBetween(1, 4);
            List<ItemPedido> items = new ArrayList<>();
            BigDecimal total = BigDecimal.ZERO;

            for (int j = 0; j < cantidadItems; j++) {
                ItemPedido item = new ItemPedido();
                item.setPedido(pedido);
                item.setProductoId((long) faker.number().numberBetween(1, 100));
                item.setNombreProducto(faker.commerce().productName());
                item.setCantidad(faker.number().numberBetween(1, 5));
                item.setPrecioUnitario(BigDecimal.valueOf(faker.number().numberBetween(1000, 50000)));
                item.setSubtotal(item.getPrecioUnitario().multiply(BigDecimal.valueOf(item.getCantidad())));

                total = total.add(item.getSubtotal());
                items.add(item);
            }

            pedido.setItems(items);
            pedido.setTotal(total);

            pedidoRepository.save(pedido);
        }

        List<Pedido> pedidos = pedidoRepository.findAll();
        System.out.println("DataLoader: se generaron " + pedidos.size() + " pedidos de ejemplo.");
    }
}
