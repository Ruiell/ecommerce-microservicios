package com.ecommerce.pedidos.config;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@FeignClient(name = "ms-inventario-pedidos", url = "${microservices.inventario.url}")
public interface InventarioFeignClient {
    @PostMapping("/api/inventario/producto/{productoId}/salida")
    Object reducirStock(@PathVariable Long productoId, @RequestBody Map<String,Object> body);
}
