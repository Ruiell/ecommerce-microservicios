package com.ecommerce.pedidos.exception;
public class PedidoNoEncontradoException extends RuntimeException {
    public PedidoNoEncontradoException(String msg) { super(msg); }
}
