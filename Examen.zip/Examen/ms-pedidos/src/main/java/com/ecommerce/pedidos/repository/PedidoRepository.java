package com.ecommerce.pedidos.repository;
import com.ecommerce.pedidos.model.Pedido;
import com.ecommerce.pedidos.model.Pedido.EstadoPedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    List<Pedido> findByUsuarioId(Long usuarioId);
    List<Pedido> findByEstado(EstadoPedido estado);
    Optional<Pedido> findByNumeroPedido(String numeroPedido);

    // Métodos personalizados para los reportes con HATEOAS (PedidoControllerV2)
    List<Pedido> findByFechaPedidoBetween(LocalDateTime inicio, LocalDateTime fin);
    long countByUsuarioId(Long usuarioId);
}
