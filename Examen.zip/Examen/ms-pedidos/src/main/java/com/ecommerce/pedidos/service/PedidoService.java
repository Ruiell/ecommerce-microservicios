package com.ecommerce.pedidos.service;

import com.ecommerce.pedidos.config.UsuarioFeignClient;
import com.ecommerce.pedidos.dto.PedidoDTO;
import com.ecommerce.pedidos.exception.*;
import com.ecommerce.pedidos.model.ItemPedido;
import com.ecommerce.pedidos.model.Pedido;
import com.ecommerce.pedidos.model.Pedido.EstadoPedido;
import com.ecommerce.pedidos.repository.PedidoRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Servicio de Pedidos - Lógica de ciclo de vida de pedidos
 * Feign → ms-usuarios | WebClient → ms-inventario (descuento de stock)
 */
@Service @RequiredArgsConstructor
public class PedidoService {

    private static final Logger log = LoggerFactory.getLogger(PedidoService.class);
    private final PedidoRepository pedidoRepository;
    private final UsuarioFeignClient usuarioFeignClient;
    private final WebClient.Builder webClientBuilder;

    @Value("${microservices.inventario.url}")
    private String inventarioUrl;

    @Transactional
    public PedidoDTO.Response crearPedido(PedidoDTO.Request request) {
        log.info("Creando pedido para usuarioId: {}", request.getUsuarioId());

        // Regla de negocio: validar usuario via Feign
        try {
            Map<String,Boolean> r = usuarioFeignClient.verificarExistencia(request.getUsuarioId());
            if (Boolean.FALSE.equals(r.get("existe"))) {
                throw new RecursoNoEncontradoException("Usuario no encontrado: " + request.getUsuarioId());
            }
        } catch (RecursoNoEncontradoException e) {
            throw e;
        } catch (Exception e) {
            log.warn("No se pudo validar usuario (ms-usuarios no disponible): {}", e.getMessage());
        }

        Pedido pedido = new Pedido();
        pedido.setUsuarioId(request.getUsuarioId());
        pedido.setNumeroPedido("PED-" + System.currentTimeMillis());
        pedido.setDireccionEnvio(request.getDireccionEnvio());
        pedido.setEstado(EstadoPedido.PENDIENTE);

        List<ItemPedido> items = request.getItems().stream().map(i -> {
            ItemPedido item = new ItemPedido();
            item.setPedido(pedido); item.setProductoId(i.getProductoId());
            item.setNombreProducto(i.getNombreProducto()); item.setCantidad(i.getCantidad());
            item.setPrecioUnitario(i.getPrecioUnitario());
            item.setSubtotal(i.getPrecioUnitario().multiply(BigDecimal.valueOf(i.getCantidad())));
            return item;
        }).collect(Collectors.toList());

        BigDecimal total = items.stream().map(ItemPedido::getSubtotal).reduce(BigDecimal.ZERO, BigDecimal::add);
        pedido.setTotal(total);
        pedido.setItems(items);

        Pedido guardado = pedidoRepository.save(pedido);
        log.info("Pedido creado: {} con total: {}", guardado.getNumeroPedido(), total);

        // Descontar stock via WebClient hacia ms-inventario
        request.getItems().forEach(i -> {
            try {
                Map<String,Object> body = Map.of(
                    "productoId", i.getProductoId(), "tipo", "SALIDA",
                    "cantidad", i.getCantidad(), "motivo", "Pedido " + guardado.getNumeroPedido()
                );
                webClientBuilder.build().post()
                    .uri(inventarioUrl + "/api/inventario/movimiento")
                    .bodyValue(body).retrieve().toBodilessEntity()
                    .block(java.time.Duration.ofSeconds(5));
                log.info("Stock descontado para productoId={}", i.getProductoId());
            } catch (Exception e) {
                log.warn("No se pudo descontar stock para producto {}: {}", i.getProductoId(), e.getMessage());
            }
        });

        return mapear(guardado);
    }

    @Transactional(readOnly = true)
    public List<PedidoDTO.Response> listarPorUsuario(Long usuarioId) {
        log.info("Listando pedidos del usuario: {}", usuarioId);
        return pedidoRepository.findByUsuarioId(usuarioId).stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public PedidoDTO.Response obtenerPorId(Long id) {
        log.info("Buscando pedido ID: {}", id);
        return mapear(pedidoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pedido no encontrado: " + id)));
    }

    @Transactional
    public PedidoDTO.Response actualizarEstado(Long id, String nuevoEstado) {
        log.info("Actualizando estado del pedido {} a {}", id, nuevoEstado);
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pedido no encontrado: " + id));

        EstadoPedido estado;
        try {
            estado = EstadoPedido.valueOf(nuevoEstado.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new EstadoInvalidoException("Estado inválido: " + nuevoEstado);
        }

        // Regla de negocio: no se puede revertir un pedido entregado
        if (pedido.getEstado() == EstadoPedido.ENTREGADO || pedido.getEstado() == EstadoPedido.CANCELADO) {
            throw new EstadoInvalidoException("No se puede cambiar el estado de un pedido " + pedido.getEstado());
        }

        pedido.setEstado(estado);
        log.info("Estado del pedido {} actualizado a {}", id, estado);
        return mapear(pedidoRepository.save(pedido));
    }

    @Transactional(readOnly = true)
    public List<PedidoDTO.Response> listarTodos() {
        return pedidoRepository.findAll().stream().map(this::mapear).collect(Collectors.toList());
    }

    // ===== Métodos personalizados para los reportes con HATEOAS (PedidoControllerV2) =====

    // 1. Obtener todos los pedidos con un estado específico
    @Transactional(readOnly = true)
    public List<PedidoDTO.Response> listarPorEstado(EstadoPedido estado) {
        return pedidoRepository.findByEstado(estado).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 2. Obtener todos los pedidos creados en una fecha específica (entre el inicio y el fin de ese día)
    @Transactional(readOnly = true)
    public List<PedidoDTO.Response> listarPorFecha(LocalDate fecha) {
        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.atTime(LocalTime.MAX);
        return pedidoRepository.findByFechaPedidoBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 3. Obtener todos los pedidos creados entre dos fechas
    @Transactional(readOnly = true)
    public List<PedidoDTO.Response> listarEntreFechas(LocalDateTime inicio, LocalDateTime fin) {
        return pedidoRepository.findByFechaPedidoBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 4. Obtener el total de pedidos realizados por un usuario
    @Transactional(readOnly = true)
    public long contarPorUsuario(Long usuarioId) {
        return pedidoRepository.countByUsuarioId(usuarioId);
    }

    /**
     * Verifica si un pedido existe (usado por otros microservicios, mismo patrón
     * que ProductoService.existeProducto / UsuarioService.existeUsuario)
     */
    @Transactional(readOnly = true)
    public boolean existePedido(Long id) {
        boolean existe = pedidoRepository.existsById(id);
        log.debug("Verificación de existencia para pedido ID {}: {}", id, existe);
        return existe;
    }

    /* ===== Ejercicios para el estudiante (mismo patrón que en ms-pagos) =====
       1. Obtener todos los pedidos de un usuario en un estado específico
       2. Obtener todos los pedidos de un usuario entre dos fechas
       3. Obtener el total de pedidos en un estado específico
       4. Obtener todos los pedidos cuyo total supere un monto dado
       5. Obtener el pedido más reciente de un usuario
       Pista: agrega los métodos derivados en PedidoRepository (ej. findByUsuarioIdAndEstado,
       countByEstado, findByTotalGreaterThan, findFirstByUsuarioIdOrderByFechaPedidoDesc)
       y expón los endpoints correspondientes en PedidoControllerV2. */

    private PedidoDTO.Response mapear(Pedido p) {
        List<PedidoDTO.ItemResponse> items = p.getItems() == null ? List.of() :
            p.getItems().stream().map(i -> {
                PedidoDTO.ItemResponse ir = new PedidoDTO.ItemResponse();
                ir.setProductoId(i.getProductoId()); ir.setNombreProducto(i.getNombreProducto());
                ir.setCantidad(i.getCantidad()); ir.setPrecioUnitario(i.getPrecioUnitario()); ir.setSubtotal(i.getSubtotal());
                return ir;
            }).collect(Collectors.toList());
        PedidoDTO.Response r = new PedidoDTO.Response();
        r.setId(p.getId()); r.setUsuarioId(p.getUsuarioId()); r.setNumeroPedido(p.getNumeroPedido());
        r.setEstado(p.getEstado()); r.setTotal(p.getTotal()); r.setDireccionEnvio(p.getDireccionEnvio());
        r.setItems(items); r.setFechaPedido(p.getFechaPedido());
        return r;
    }
}
