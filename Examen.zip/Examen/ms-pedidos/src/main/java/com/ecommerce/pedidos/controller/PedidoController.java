package com.ecommerce.pedidos.controller;
import com.ecommerce.pedidos.dto.PedidoDTO;
import com.ecommerce.pedidos.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/pedidos") @RequiredArgsConstructor
@Tag(name = "Pedidos", description = "Operaciones relacionadas con la gestión de pedidos")
public class PedidoController {
    private static final Logger log = LoggerFactory.getLogger(PedidoController.class);
    private final PedidoService pedidoService;

    @GetMapping
    @Operation(summary = "Listar todos los pedidos", description = "Obtiene el listado completo de pedidos registrados")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente")
    })
    public ResponseEntity<List<PedidoDTO.Response>> listar() {
        log.info("GET /api/pedidos"); return ResponseEntity.ok(pedidoService.listarTodos());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un pedido por id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pedido encontrado"),
            @ApiResponse(responseCode = "404", description = "Pedido no encontrado")
    })
    public ResponseEntity<PedidoDTO.Response> obtener(@PathVariable Long id) {
        log.info("GET /api/pedidos/{}", id); return ResponseEntity.ok(pedidoService.obtenerPorId(id));
    }

    @GetMapping("/usuario/{usuarioId}")
    @Operation(summary = "Listar los pedidos de un usuario específico")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente (puede ser vacío)")
    })
    public ResponseEntity<List<PedidoDTO.Response>> listarPorUsuario(@PathVariable Long usuarioId) {
        log.info("GET /api/pedidos/usuario/{}", usuarioId); return ResponseEntity.ok(pedidoService.listarPorUsuario(usuarioId));
    }

    @PostMapping
    @Operation(summary = "Crear un nuevo pedido",
            description = "Valida la existencia del usuario vía ms-usuarios, calcula el total a partir de los items " +
                    "y descuenta stock en ms-inventario (best-effort, no bloquea la creación si inventario falla)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Pedido creado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos de la solicitud inválidos"),
            @ApiResponse(responseCode = "404", description = "El usuario indicado no existe en ms-usuarios")
    })
    public ResponseEntity<PedidoDTO.Response> crear(@Valid @RequestBody PedidoDTO.Request request) {
        log.info("POST /api/pedidos - usuarioId: {}", request.getUsuarioId());
        return ResponseEntity.status(HttpStatus.CREATED).body(pedidoService.crearPedido(request));
    }

    @PatchMapping("/{id}/estado")
    @Operation(summary = "Actualizar el estado de un pedido",
            description = "Estados válidos: PENDIENTE, CONFIRMADO, EN_PREPARACION, ENVIADO, ENTREGADO, CANCELADO. " +
                    "No se puede cambiar el estado de un pedido ENTREGADO o CANCELADO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Estado actualizado correctamente"),
            @ApiResponse(responseCode = "400", description = "Estado inválido o transición no permitida"),
            @ApiResponse(responseCode = "404", description = "Pedido no encontrado")
    })
    public ResponseEntity<PedidoDTO.Response> actualizarEstado(@PathVariable Long id, @RequestParam String estado) {
        log.info("PATCH /api/pedidos/{}/estado -> {}", id, estado);
        return ResponseEntity.ok(pedidoService.actualizarEstado(id, estado));
    }

    @GetMapping("/{id}/existe")
    @Operation(summary = "Verificar si un pedido existe",
            description = "Endpoint interno usado por otros microservicios para validar referencias")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Verificación realizada correctamente")
    })
    public ResponseEntity<Map<String, Boolean>> verificarExistencia(@PathVariable Long id) {
        log.info("GET /api/pedidos/{}/existe", id);
        return ResponseEntity.ok(Map.of("existe", pedidoService.existePedido(id)));
    }
}
