package com.ecommerce.pedidos;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
/**
 * Microservicio de Pedidos
 * Puerto: 8086
 * Responsabilidad: Gestión del ciclo de vida de pedidos
 * Comunicación: Feign → ms-usuarios, WebClient → ms-inventario
 */
@SpringBootApplication @EnableFeignClients
public class MsPedidosApplication {
    public static void main(String[] args) { SpringApplication.run(MsPedidosApplication.class, args); }
}
