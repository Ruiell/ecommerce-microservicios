package com.ecommerce.pedidos.model;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity @Table(name = "pedidos") @Data @NoArgsConstructor @AllArgsConstructor
public class Pedido {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "usuario_id", nullable = false) private Long usuarioId;
    @Column(name = "numero_pedido", unique = true, nullable = false) private String numeroPedido;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private EstadoPedido estado = EstadoPedido.PENDIENTE;
    @Column(name = "total", nullable = false, precision = 10, scale = 2) private BigDecimal total;
    @Column(name = "direccion_envio", length = 300) private String direccionEnvio;
    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ItemPedido> items;
    @Column(name = "fecha_pedido", updatable = false) private LocalDateTime fechaPedido;
    @Column(name = "fecha_actualizacion") private LocalDateTime fechaActualizacion;
    @PrePersist protected void onCreate() { fechaPedido = LocalDateTime.now(); fechaActualizacion = LocalDateTime.now(); }
    @PreUpdate protected void onUpdate() { fechaActualizacion = LocalDateTime.now(); }
    public enum EstadoPedido { PENDIENTE, CONFIRMADO, EN_PREPARACION, ENVIADO, ENTREGADO, CANCELADO }
}
