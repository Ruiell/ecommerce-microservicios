package com.ecommerce.pedidos.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.pedidos.controller.PedidoControllerV2;
import com.ecommerce.pedidos.dto.PedidoDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class PedidoModelAssembler implements RepresentationModelAssembler<PedidoDTO.Response, EntityModel<PedidoDTO.Response>> {

    @Override
    public EntityModel<PedidoDTO.Response> toModel(PedidoDTO.Response pedido) {
        return EntityModel.of(pedido,
                linkTo(methodOn(PedidoControllerV2.class).obtener(pedido.getId())).withSelfRel(),
                linkTo(methodOn(PedidoControllerV2.class).listar()).withRel("pedidos"),
                linkTo(methodOn(PedidoControllerV2.class).listarPorUsuario(pedido.getUsuarioId())).withRel("pedidosDelUsuario"));
    }
}
