package com.ecommerce.pedidos.model;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity @Table(name = "items_pedido") @Data @NoArgsConstructor @AllArgsConstructor
public class ItemPedido {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "pedido_id", nullable = false) private Pedido pedido;
    @Column(name = "producto_id", nullable = false) private Long productoId;
    @Column(name = "nombre_producto") private String nombreProducto;
    @Column(nullable = false) private Integer cantidad;
    @Column(name = "precio_unitario", nullable = false, precision = 10, scale = 2) private BigDecimal precioUnitario;
    @Column(precision = 10, scale = 2) private BigDecimal subtotal;
}
