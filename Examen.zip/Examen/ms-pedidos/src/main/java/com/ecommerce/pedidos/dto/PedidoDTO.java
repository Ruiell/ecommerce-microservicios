package com.ecommerce.pedidos.dto;
import com.ecommerce.pedidos.model.Pedido.EstadoPedido;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class PedidoDTO {
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ItemRequest {
        @NotNull private Long productoId;
        @NotNull @Min(1) private Integer cantidad;
        @NotNull private BigDecimal precioUnitario;
        private String nombreProducto;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Request {
        @NotNull private Long usuarioId;
        @NotNull @NotEmpty private List<ItemRequest> items;
        @NotBlank private String direccionEnvio;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ItemResponse {
        private Long productoId; private String nombreProducto;
        private Integer cantidad; private BigDecimal precioUnitario; private BigDecimal subtotal;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id; private Long usuarioId; private String numeroPedido;
        private EstadoPedido estado; private BigDecimal total;
        private String direccionEnvio; private List<ItemResponse> items;
        private LocalDateTime fechaPedido;
    }
}
