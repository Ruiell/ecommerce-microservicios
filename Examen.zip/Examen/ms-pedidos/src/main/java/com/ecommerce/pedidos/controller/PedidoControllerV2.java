package com.ecommerce.pedidos.controller;

import com.ecommerce.pedidos.assemblers.PedidoModelAssembler;
import com.ecommerce.pedidos.dto.PedidoDTO;
import com.ecommerce.pedidos.model.Pedido;
import com.ecommerce.pedidos.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de pedidos.
 * Para la versión sin HATEOAS usar /api/pedidos (PedidoController).
 */
@RestController
@RequestMapping("/api/v2/pedidos")
@Tag(name = "Pedidos (HATEOAS)", description = "Operaciones sobre pedidos con enlaces HATEOAS")
public class PedidoControllerV2 {

    @Autowired
    private PedidoService pedidoService;

    @Autowired
    private PedidoModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar todos los pedidos (HATEOAS)")
    public CollectionModel<EntityModel<PedidoDTO.Response>> listar() {
        List<EntityModel<PedidoDTO.Response>> pedidos = pedidoService.listarTodos().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pedidos,
                linkTo(methodOn(PedidoControllerV2.class).listar()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un pedido por id (HATEOAS)")
    public EntityModel<PedidoDTO.Response> obtener(@PathVariable Long id) {
        PedidoDTO.Response pedido = pedidoService.obtenerPorId(id);
        return assembler.toModel(pedido);
    }

    @GetMapping(value = "/usuario/{usuarioId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar pedidos de un usuario (HATEOAS)")
    public CollectionModel<EntityModel<PedidoDTO.Response>> listarPorUsuario(@PathVariable Long usuarioId) {
        List<EntityModel<PedidoDTO.Response>> pedidos = pedidoService.listarPorUsuario(usuarioId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pedidos,
                linkTo(methodOn(PedidoControllerV2.class).listarPorUsuario(usuarioId)).withSelfRel());
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear un nuevo pedido (HATEOAS)")
    public ResponseEntity<EntityModel<PedidoDTO.Response>> crear(@Valid @RequestBody PedidoDTO.Request request) {
        PedidoDTO.Response nuevoPedido = pedidoService.crearPedido(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(assembler.toModel(nuevoPedido));
    }

    @PatchMapping(value = "/{id}/estado", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar el estado de un pedido (HATEOAS)")
    public EntityModel<PedidoDTO.Response> actualizarEstado(@PathVariable Long id, @RequestParam String estado) {
        PedidoDTO.Response pedido = pedidoService.actualizarEstado(id, estado);
        return assembler.toModel(pedido);
    }

    // ===== Reportes con HATEOAS (ver PedidoService) =====

    // 1. Obtener todos los pedidos con un estado específico
    @GetMapping(value = "/estado/{estado}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar pedidos por estado (HATEOAS)",
            description = "Obtiene todos los pedidos en un estado específico: PENDIENTE, CONFIRMADO, EN_PREPARACION, ENVIADO, ENTREGADO o CANCELADO")
    public CollectionModel<EntityModel<PedidoDTO.Response>> listarPorEstado(@PathVariable Pedido.EstadoPedido estado) {
        List<EntityModel<PedidoDTO.Response>> pedidos = pedidoService.listarPorEstado(estado).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pedidos,
                linkTo(methodOn(PedidoControllerV2.class).listarPorEstado(estado)).withSelfRel());
    }

    // 2. Obtener todos los pedidos creados en una fecha específica (ej: /api/v2/pedidos/fecha/2026-06-26)
    @GetMapping(value = "/fecha/{fecha}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar pedidos creados en una fecha específica (HATEOAS)")
    public CollectionModel<EntityModel<PedidoDTO.Response>> listarPorFecha(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        List<EntityModel<PedidoDTO.Response>> pedidos = pedidoService.listarPorFecha(fecha).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pedidos,
                linkTo(methodOn(PedidoControllerV2.class).listarPorFecha(fecha)).withSelfRel());
    }

    // 3. Obtener todos los pedidos creados entre dos fechas (ej: ?inicio=2026-06-01T00:00:00&fin=2026-06-26T23:59:59)
    @GetMapping(value = "/rango", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar pedidos creados entre dos fechas (HATEOAS)")
    public CollectionModel<EntityModel<PedidoDTO.Response>> listarEntreFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        List<EntityModel<PedidoDTO.Response>> pedidos = pedidoService.listarEntreFechas(inicio, fin).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(pedidos,
                linkTo(methodOn(PedidoControllerV2.class).listarEntreFechas(inicio, fin)).withSelfRel());
    }

    // 4. Obtener el total de pedidos realizados por un usuario
    @GetMapping(value = "/usuario/{usuarioId}/total", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el total de pedidos realizados por un usuario (HATEOAS)")
    public EntityModel<Map<String, Object>> contarPorUsuario(@PathVariable Long usuarioId) {
        long total = pedidoService.contarPorUsuario(usuarioId);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("usuarioId", usuarioId);
        body.put("totalPedidos", total);

        return EntityModel.of(body,
                linkTo(methodOn(PedidoControllerV2.class).contarPorUsuario(usuarioId)).withSelfRel(),
                linkTo(methodOn(PedidoControllerV2.class).listarPorUsuario(usuarioId)).withRel("pedidosDelUsuario"));
    }

    /* ===== Ejercicios para el estudiante (ver los 5 pendientes en PedidoService) ===== */
}
