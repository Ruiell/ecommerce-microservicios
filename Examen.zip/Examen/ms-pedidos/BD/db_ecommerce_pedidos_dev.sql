/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_pedidos_dev
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_pedidos_dev;

/* ============================================================
   2. Tabla pedidos
   ============================================================ */
CREATE TABLE pedidos (
    id                   BIGINT        NOT NULL AUTO_INCREMENT,
    usuario_id           BIGINT        NOT NULL,
    numero_pedido        VARCHAR(50)   NOT NULL,
    estado               VARCHAR(20)   NOT NULL DEFAULT 'PENDIENTE',
    total                DECIMAL(10,2) NOT NULL,
    direccion_envio      VARCHAR(300)  NULL,
    fecha_pedido         DATETIME      NOT NULL,
    fecha_actualizacion  DATETIME      NULL,
    CONSTRAINT pedidos_PK PRIMARY KEY (id),
    CONSTRAINT pedidos_numero_pedido_UN UNIQUE (numero_pedido)
) ENGINE = InnoDB;

ALTER TABLE pedidos
ADD CONSTRAINT chk_pedidos_estado
  CHECK (estado IN ('PENDIENTE','CONFIRMADO','EN_PREPARACION','ENVIADO','ENTREGADO','CANCELADO'));

/* ============================================================
   3. Tabla items_pedido
   ============================================================ */
CREATE TABLE items_pedido (
    id               BIGINT        NOT NULL AUTO_INCREMENT,
    pedido_id        BIGINT        NOT NULL,
    producto_id      BIGINT        NOT NULL,
    nombre_producto  VARCHAR(150)  NULL,
    cantidad         INT           NOT NULL,
    precio_unitario  DECIMAL(10,2) NOT NULL,
    subtotal         DECIMAL(10,2) NULL,
    CONSTRAINT items_pedido_PK PRIMARY KEY (id),
    CONSTRAINT items_pedido_pedido_FK FOREIGN KEY (pedido_id)
        REFERENCES pedidos (id) ON DELETE CASCADE
) ENGINE = InnoDB;

/* ============================================================
   ¡Todo listo!
   ============================================================ */
