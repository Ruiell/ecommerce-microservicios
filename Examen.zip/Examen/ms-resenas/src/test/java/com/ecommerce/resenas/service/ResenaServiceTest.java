package com.ecommerce.resenas.service;

import com.ecommerce.resenas.config.UsuarioFeignClient;
import com.ecommerce.resenas.dto.ResenaDTO;
import com.ecommerce.resenas.exception.RecursoNoEncontradoException;
import com.ecommerce.resenas.exception.ResenaExistenteException;
import com.ecommerce.resenas.model.Resena;
import com.ecommerce.resenas.repository.ResenaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ResenaServiceTest {

    @Mock
    private ResenaRepository resenaRepository;
    @Mock
    private UsuarioFeignClient usuarioFeignClient;

    @InjectMocks
    private ResenaService resenaService;

    private Resena crearResenaDePrueba() {
        Resena r = new Resena();
        r.setId(1L);
        r.setProductoId(10L);
        r.setUsuarioId(5L);
        r.setCalificacion(5);
        r.setComentario("Excelente producto");
        r.setNombreUsuario("Javier Barrios");
        return r;
    }

    @Test
    void testCrearResena() {
        when(resenaRepository.existsByProductoIdAndUsuarioId(10L, 5L)).thenReturn(false);
        when(usuarioFeignClient.obtenerUsuario(5L)).thenReturn(Map.of("nombre", "Javier", "apellido", "Barrios"));
        when(resenaRepository.save(any(Resena.class))).thenReturn(crearResenaDePrueba());

        ResenaDTO.Request request = new ResenaDTO.Request();
        request.setProductoId(10L);
        request.setUsuarioId(5L);
        request.setCalificacion(5);
        request.setComentario("Excelente producto");

        ResenaDTO.Response respuesta = resenaService.crearResena(request);

        assertNotNull(respuesta);
        assertEquals(5, respuesta.getCalificacion());
    }

    @Test
    void testCrearResena_YaExiste() {
        when(resenaRepository.existsByProductoIdAndUsuarioId(10L, 5L)).thenReturn(true);

        ResenaDTO.Request request = new ResenaDTO.Request();
        request.setProductoId(10L);
        request.setUsuarioId(5L);
        request.setCalificacion(4);

        assertThrows(ResenaExistenteException.class, () -> resenaService.crearResena(request));
    }

    @Test
    void testListarPorProducto() {
        when(resenaRepository.findByProductoId(10L)).thenReturn(List.of(crearResenaDePrueba()));

        List<ResenaDTO.Response> resultado = resenaService.listarPorProducto(10L);

        assertEquals(1, resultado.size());
    }

    @Test
    void testObtenerPromedio() {
        when(resenaRepository.promedioCalificacionPorProducto(10L)).thenReturn(4.5);
        when(resenaRepository.countByProductoId(10L)).thenReturn(2L);

        ResenaDTO.PromedioResponse resultado = resenaService.obtenerPromedio(10L);

        assertEquals(4.5, resultado.getPromedioCalificacion());
        assertEquals(2L, resultado.getTotalResenas());
    }

    @Test
    void testEliminarResena_NoEncontrada() {
        when(resenaRepository.existsById(99L)).thenReturn(false);

        assertThrows(RecursoNoEncontradoException.class, () -> resenaService.eliminarResena(99L));
    }

    @Test
    void testExisteResena() {
        when(resenaRepository.existsById(1L)).thenReturn(true);

        assertTrue(resenaService.existeResena(1L));
    }

    @Test
    void testListarPorUsuario() {
        when(resenaRepository.findByUsuarioId(5L)).thenReturn(List.of(crearResenaDePrueba()));

        List<ResenaDTO.Response> resultado = resenaService.listarPorUsuario(5L);

        assertEquals(1, resultado.size());
    }

    @Test
    void testListarPorCalificacion() {
        when(resenaRepository.findByCalificacion(5)).thenReturn(List.of(crearResenaDePrueba()));

        List<ResenaDTO.Response> resultado = resenaService.listarPorCalificacion(5);

        assertEquals(1, resultado.size());
    }
}
