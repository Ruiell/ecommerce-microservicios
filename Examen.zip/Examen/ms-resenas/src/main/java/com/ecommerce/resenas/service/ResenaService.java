package com.ecommerce.resenas.service;
import com.ecommerce.resenas.config.UsuarioFeignClient;
import com.ecommerce.resenas.dto.ResenaDTO;
import com.ecommerce.resenas.exception.*;
import com.ecommerce.resenas.model.Resena;
import com.ecommerce.resenas.repository.ResenaRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor
public class ResenaService {
    private static final Logger log = LoggerFactory.getLogger(ResenaService.class);
    private final ResenaRepository resenaRepository;
    private final UsuarioFeignClient usuarioFeignClient;

    @Transactional
    public ResenaDTO.Response crearResena(ResenaDTO.Request request) {
        log.info("Creando reseña productoId={} usuarioId={}", request.getProductoId(), request.getUsuarioId());

        // Regla de negocio: un usuario solo puede reseñar un producto una vez
        if (resenaRepository.existsByProductoIdAndUsuarioId(request.getProductoId(), request.getUsuarioId())) {
            throw new ResenaExistenteException("El usuario ya reseñó este producto");
        }

        String nombreUsuario = "Usuario";
        try {
            var usuario = usuarioFeignClient.obtenerUsuario(request.getUsuarioId());
            nombreUsuario = usuario.get("nombre") + " " + usuario.get("apellido");
        } catch (Exception e) {
            log.warn("No se pudo obtener nombre de usuario: {}", e.getMessage());
        }

        Resena resena = new Resena();
        resena.setProductoId(request.getProductoId()); resena.setUsuarioId(request.getUsuarioId());
        resena.setCalificacion(request.getCalificacion()); resena.setComentario(request.getComentario());
        resena.setNombreUsuario(nombreUsuario);
        Resena guardada = resenaRepository.save(resena);
        log.info("Reseña creada ID: {}", guardada.getId());
        return mapear(guardada);
    }

    @Transactional(readOnly = true)
    public List<ResenaDTO.Response> listarPorProducto(Long productoId) {
        log.info("Listando reseñas del producto: {}", productoId);
        return resenaRepository.findByProductoId(productoId).stream().map(this::mapear).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ResenaDTO.PromedioResponse obtenerPromedio(Long productoId) {
        log.info("Calculando promedio para productoId: {}", productoId);
        Double promedio = resenaRepository.promedioCalificacionPorProducto(productoId);
        Long total = resenaRepository.countByProductoId(productoId);
        ResenaDTO.PromedioResponse r = new ResenaDTO.PromedioResponse();
        r.setProductoId(productoId); r.setPromedioCalificacion(promedio != null ? promedio : 0.0);
        r.setTotalResenas(total); return r;
    }

    @Transactional
    public void eliminarResena(Long id) {
        log.info("Eliminando reseña ID: {}", id);
        if (!resenaRepository.existsById(id)) {
            throw new RecursoNoEncontradoException("Reseña no encontrada: " + id);
        }
        resenaRepository.deleteById(id);
        log.info("Reseña eliminada: {}", id);
    }

    private ResenaDTO.Response mapear(Resena r) {
        ResenaDTO.Response res = new ResenaDTO.Response();
        res.setId(r.getId()); res.setProductoId(r.getProductoId()); res.setUsuarioId(r.getUsuarioId());
        res.setCalificacion(r.getCalificacion()); res.setComentario(r.getComentario());
        res.setNombreUsuario(r.getNombreUsuario()); res.setFechaCreacion(r.getFechaCreacion());
        return res;
    }

    /**
     * Verifica si una reseña existe (usado por otros microservicios, mismo patrón
     * que ProductoService.existeProducto / UsuarioService.existeUsuario)
     */
    public boolean existeResena(Long id) {
        return resenaRepository.existsById(id);
    }

    // ===== Reportes con HATEOAS (mismo patrón que PagoService/PedidoService) =====

    // 1. Obtener todas las reseñas de un usuario
    @Transactional(readOnly = true)
    public List<ResenaDTO.Response> listarPorUsuario(Long usuarioId) {
        return resenaRepository.findByUsuarioId(usuarioId).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 2. Obtener todas las reseñas con una calificación específica (1 a 5)
    @Transactional(readOnly = true)
    public List<ResenaDTO.Response> listarPorCalificacion(Integer calificacion) {
        return resenaRepository.findByCalificacion(calificacion).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 3. Obtener todas las reseñas creadas en una fecha específica (entre el inicio y el fin de ese día)
    @Transactional(readOnly = true)
    public List<ResenaDTO.Response> listarPorFecha(LocalDate fecha) {
        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.atTime(LocalTime.MAX);
        return resenaRepository.findByFechaCreacionBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }

    // 4. Obtener todas las reseñas creadas entre dos fechas
    @Transactional(readOnly = true)
    public List<ResenaDTO.Response> listarEntreFechas(LocalDateTime inicio, LocalDateTime fin) {
        return resenaRepository.findByFechaCreacionBetween(inicio, fin).stream().map(this::mapear).collect(Collectors.toList());
    }
}
