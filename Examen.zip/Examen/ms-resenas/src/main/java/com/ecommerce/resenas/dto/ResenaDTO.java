package com.ecommerce.resenas.dto;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

public class ResenaDTO {
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Request {
        @NotNull private Long productoId;
        @NotNull private Long usuarioId;
        @NotNull @Min(1) @Max(5) private Integer calificacion;
        @Size(max = 1000) private String comentario;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id; private Long productoId; private Long usuarioId;
        private Integer calificacion; private String comentario;
        private String nombreUsuario; private LocalDateTime fechaCreacion;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class PromedioResponse {
        private Long productoId; private Double promedioCalificacion; private Long totalResenas;
    }
}
