package com.ecommerce.resenas;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
/** Microservicio de Reseñas - Puerto: 8089 */
@SpringBootApplication @EnableFeignClients
public class MsResenasApplication {
    public static void main(String[] args) { SpringApplication.run(MsResenasApplication.class, args); }
}
