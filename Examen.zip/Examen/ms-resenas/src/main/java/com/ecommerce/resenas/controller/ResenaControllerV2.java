package com.ecommerce.resenas.controller;

import com.ecommerce.resenas.assemblers.ResenaModelAssembler;
import com.ecommerce.resenas.dto.ResenaDTO;
import com.ecommerce.resenas.service.ResenaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Versión con HATEOAS de la API de reseñas.
 * Las respuestas incluyen enlaces de navegación (resenasDelProducto, promedioDelProducto, resenasDelUsuario).
 * Para la versión sin HATEOAS usar /api/resenas (ResenaController).
 */
@RestController
@RequestMapping("/api/v2/resenas")
@Tag(name = "Reseñas (HATEOAS)", description = "Operaciones sobre reseñas con enlaces HATEOAS")
public class ResenaControllerV2 {

    @Autowired
    private ResenaService resenaService;

    @Autowired
    private ResenaModelAssembler assembler;

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear una reseña (HATEOAS)")
    public ResponseEntity<EntityModel<ResenaDTO.Response>> crear(@Valid @RequestBody ResenaDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(resenaService.crearResena(request)));
    }

    @GetMapping(value = "/producto/{productoId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar reseñas de un producto (HATEOAS)")
    public CollectionModel<EntityModel<ResenaDTO.Response>> listarPorProducto(@PathVariable Long productoId) {
        List<EntityModel<ResenaDTO.Response>> resenas = resenaService.listarPorProducto(productoId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(resenas, linkTo(methodOn(ResenaControllerV2.class).listarPorProducto(productoId)).withSelfRel());
    }

    @GetMapping(value = "/producto/{productoId}/promedio", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener el promedio de calificación de un producto (HATEOAS)")
    public EntityModel<ResenaDTO.PromedioResponse> promedio(@PathVariable Long productoId) {
        ResenaDTO.PromedioResponse promedio = resenaService.obtenerPromedio(productoId);
        return EntityModel.of(promedio,
                linkTo(methodOn(ResenaControllerV2.class).promedio(productoId)).withSelfRel(),
                linkTo(methodOn(ResenaControllerV2.class).listarPorProducto(productoId)).withRel("resenasDelProducto"));
    }

    // ===== Reportes con HATEOAS (ver ResenaService) =====

    // 1. Obtener todas las reseñas de un usuario
    @GetMapping(value = "/usuario/{usuarioId}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar reseñas de un usuario (HATEOAS)")
    public CollectionModel<EntityModel<ResenaDTO.Response>> listarPorUsuario(@PathVariable Long usuarioId) {
        List<EntityModel<ResenaDTO.Response>> resenas = resenaService.listarPorUsuario(usuarioId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(resenas, linkTo(methodOn(ResenaControllerV2.class).listarPorUsuario(usuarioId)).withSelfRel());
    }

    // 2. Obtener todas las reseñas con una calificación específica (1 a 5)
    @GetMapping(value = "/calificacion/{calificacion}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar reseñas por calificación (HATEOAS)")
    public CollectionModel<EntityModel<ResenaDTO.Response>> listarPorCalificacion(@PathVariable Integer calificacion) {
        List<EntityModel<ResenaDTO.Response>> resenas = resenaService.listarPorCalificacion(calificacion).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(resenas, linkTo(methodOn(ResenaControllerV2.class).listarPorCalificacion(calificacion)).withSelfRel());
    }

    // 3. Obtener todas las reseñas creadas en una fecha específica (ej: /api/v2/resenas/fecha/2026-06-26)
    @GetMapping(value = "/fecha/{fecha}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar reseñas creadas en una fecha específica (HATEOAS)")
    public CollectionModel<EntityModel<ResenaDTO.Response>> listarPorFecha(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        List<EntityModel<ResenaDTO.Response>> resenas = resenaService.listarPorFecha(fecha).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(resenas, linkTo(methodOn(ResenaControllerV2.class).listarPorFecha(fecha)).withSelfRel());
    }

    // 4. Obtener todas las reseñas creadas entre dos fechas
    @GetMapping(value = "/rango", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar reseñas creadas entre dos fechas (HATEOAS)")
    public CollectionModel<EntityModel<ResenaDTO.Response>> listarEntreFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        List<EntityModel<ResenaDTO.Response>> resenas = resenaService.listarEntreFechas(inicio, fin).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(resenas, linkTo(methodOn(ResenaControllerV2.class).listarEntreFechas(inicio, fin)).withSelfRel());
    }
}
