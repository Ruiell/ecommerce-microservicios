package com.ecommerce.resenas.exception;
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String m) { super(m); }
}
