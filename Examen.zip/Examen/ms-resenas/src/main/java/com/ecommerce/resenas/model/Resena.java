package com.ecommerce.resenas.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name = "resenas") @Data @NoArgsConstructor @AllArgsConstructor
public class Resena {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "producto_id", nullable = false) private Long productoId;
    @Column(name = "usuario_id", nullable = false) private Long usuarioId;
    @Min(1) @Max(5) @Column(nullable = false) private Integer calificacion;
    @Column(length = 1000) private String comentario;
    @Column(name = "nombre_usuario", length = 100) private String nombreUsuario;
    @Column(name = "fecha_creacion", updatable = false) private LocalDateTime fechaCreacion;
    @PrePersist protected void onCreate() { fechaCreacion = LocalDateTime.now(); }
}
