package com.ecommerce.resenas.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecommerce.resenas.controller.ResenaControllerV2;
import com.ecommerce.resenas.dto.ResenaDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class ResenaModelAssembler implements RepresentationModelAssembler<ResenaDTO.Response, EntityModel<ResenaDTO.Response>> {

    @Override
    public EntityModel<ResenaDTO.Response> toModel(ResenaDTO.Response resena) {
        return EntityModel.of(resena,
                linkTo(methodOn(ResenaControllerV2.class).listarPorProducto(resena.getProductoId())).withRel("resenasDelProducto"),
                linkTo(methodOn(ResenaControllerV2.class).promedio(resena.getProductoId())).withRel("promedioDelProducto"),
                linkTo(methodOn(ResenaControllerV2.class).listarPorUsuario(resena.getUsuarioId())).withRel("resenasDelUsuario"));
    }
}
