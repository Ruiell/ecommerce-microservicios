package com.ecommerce.resenas.repository;
import com.ecommerce.resenas.model.Resena;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
@Repository
public interface ResenaRepository extends JpaRepository<Resena, Long> {
    List<Resena> findByProductoId(Long productoId);
    List<Resena> findByUsuarioId(Long usuarioId);
    boolean existsByProductoIdAndUsuarioId(Long productoId, Long usuarioId);
    @Query("SELECT AVG(r.calificacion) FROM Resena r WHERE r.productoId = :productoId")
    Double promedioCalificacionPorProducto(Long productoId);
    @Query("SELECT COUNT(r) FROM Resena r WHERE r.productoId = :productoId")
    Long countByProductoId(Long productoId);

    // Métodos personalizados para los reportes con HATEOAS (ResenaControllerV2)
    List<Resena> findByCalificacion(Integer calificacion);
    List<Resena> findByFechaCreacionBetween(LocalDateTime inicio, LocalDateTime fin);
}
