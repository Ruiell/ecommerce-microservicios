package com.ecommerce.resenas.exception;
public class ResenaExistenteException extends RuntimeException {
    public ResenaExistenteException(String m) { super(m); }
}
