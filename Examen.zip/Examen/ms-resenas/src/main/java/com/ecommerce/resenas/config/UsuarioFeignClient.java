package com.ecommerce.resenas.config;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@FeignClient(name = "ms-usuarios-resenas", url = "${microservices.usuarios.url}")
public interface UsuarioFeignClient {
    @GetMapping("/api/usuarios/{id}")
    Map<String,Object> obtenerUsuario(@PathVariable Long id);
}
