package com.ecommerce.resenas;

import com.ecommerce.resenas.model.Resena;
import com.ecommerce.resenas.repository.ResenaRepository;
import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

@Profile({"dev", "render", "aiven"})
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private ResenaRepository resenaRepository;

    @Override
    public void run(String... args) throws Exception {
        if (resenaRepository.count() > 0) {
            return;
        }

        Faker faker = new Faker();
        Random random = new Random();
        Set<String> combinacionesUsadas = new HashSet<>();

        int creadas = 0;
        while (creadas < 40) {
            long productoId = faker.number().numberBetween(1, 31);
            long usuarioId = faker.number().numberBetween(1, 21);
            String clave = productoId + "-" + usuarioId;

            if (combinacionesUsadas.contains(clave)) {
                continue;
            }
            combinacionesUsadas.add(clave);

            Resena resena = new Resena();
            resena.setProductoId(productoId);
            resena.setUsuarioId(usuarioId);
            resena.setCalificacion(1 + random.nextInt(5));
            resena.setComentario(faker.lorem().sentence(15));
            resena.setNombreUsuario(faker.name().fullName());

            resenaRepository.save(resena);
            creadas++;
        }

        System.out.println(">> DataLoader: 40 resenas de prueba cargadas en ms-resenas (perfil dev).");
    }
}
