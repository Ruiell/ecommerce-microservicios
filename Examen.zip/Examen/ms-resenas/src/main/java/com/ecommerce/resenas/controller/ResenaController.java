package com.ecommerce.resenas.controller;
import com.ecommerce.resenas.dto.ResenaDTO;
import com.ecommerce.resenas.service.ResenaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/resenas") @RequiredArgsConstructor
public class ResenaController {
    private static final Logger log = LoggerFactory.getLogger(ResenaController.class);
    private final ResenaService resenaService;

    @PostMapping
    public ResponseEntity<ResenaDTO.Response> crear(@Valid @RequestBody ResenaDTO.Request request) {
        log.info("POST /api/resenas"); return ResponseEntity.status(HttpStatus.CREATED).body(resenaService.crearResena(request));
    }
    @GetMapping("/producto/{productoId}")
    public ResponseEntity<List<ResenaDTO.Response>> listarPorProducto(@PathVariable Long productoId) {
        log.info("GET /api/resenas/producto/{}", productoId);
        return ResponseEntity.ok(resenaService.listarPorProducto(productoId));
    }
    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<ResenaDTO.Response>> listarPorUsuario(@PathVariable Long usuarioId) {
        log.info("GET /api/resenas/usuario/{}", usuarioId);
        return ResponseEntity.ok(resenaService.listarPorUsuario(usuarioId));
    }
    @GetMapping("/producto/{productoId}/promedio")
    public ResponseEntity<ResenaDTO.PromedioResponse> promedio(@PathVariable Long productoId) {
        log.info("GET /api/resenas/producto/{}/promedio", productoId);
        return ResponseEntity.ok(resenaService.obtenerPromedio(productoId));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String,String>> eliminar(@PathVariable Long id) {
        log.info("DELETE /api/resenas/{}", id);
        resenaService.eliminarResena(id);
        return ResponseEntity.ok(Map.of("mensaje", "Reseña eliminada exitosamente"));
    }
    @GetMapping("/{id}/existe")
    public ResponseEntity<Map<String,Boolean>> existe(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("existe", resenaService.existeResena(id)));
    }
}
