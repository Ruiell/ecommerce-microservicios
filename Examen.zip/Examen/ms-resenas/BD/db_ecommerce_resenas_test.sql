/* ============================================================
   1. Crear base de datos y seleccionar esquema
   ============================================================ */
CREATE DATABASE IF NOT EXISTS ecommerce_resenas_test
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE ecommerce_resenas_test;

/* ============================================================
   2. Tabla resenas
   ============================================================ */
CREATE TABLE resenas (
    id                BIGINT       NOT NULL AUTO_INCREMENT,
    producto_id       BIGINT       NOT NULL,
    usuario_id        BIGINT       NOT NULL,
    calificacion      INT          NOT NULL,
    comentario        VARCHAR(1000) NULL,
    nombre_usuario    VARCHAR(100) NULL,
    fecha_creacion    DATETIME     NOT NULL,
    CONSTRAINT resenas_PK PRIMARY KEY (id),
    CONSTRAINT resenas_producto_usuario_UN UNIQUE (producto_id, usuario_id),
    CONSTRAINT chk_resenas_calificacion CHECK (calificacion BETWEEN 1 AND 5)
) ENGINE = InnoDB;

/* ============================================================
   ¡Todo listo!
   ============================================================ */
